CREATE TABLE "announcements" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"category" text DEFAULT 'General' NOT NULL,
	"is_published" boolean DEFAULT true NOT NULL,
	"published_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "application_events" (
	"id" serial PRIMARY KEY,
	"application_id" integer NOT NULL,
	"status" text NOT NULL,
	"note" text,
	"actor_type" text DEFAULT 'system' NOT NULL,
	"actor_name" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "applications" (
	"id" serial PRIMARY KEY,
	"reference" text NOT NULL,
	"user_id" integer NOT NULL,
	"type" text NOT NULL,
	"applicant_name" text NOT NULL,
	"details" text NOT NULL,
	"ward" text,
	"document_url" text,
	"document_name" text,
	"filed_by_name" text,
	"status" text DEFAULT 'Submitted' NOT NULL,
	"admin_remark" text,
	"assigned_to" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"decided_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "complaint_events" (
	"id" serial PRIMARY KEY,
	"complaint_id" integer NOT NULL,
	"status" text NOT NULL,
	"note" text,
	"actor_type" text DEFAULT 'system' NOT NULL,
	"actor_name" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "complaints" (
	"id" serial PRIMARY KEY,
	"reference" text NOT NULL,
	"user_id" integer NOT NULL,
	"service_slug" text,
	"service_name" text NOT NULL,
	"title" text NOT NULL,
	"description" text NOT NULL,
	"area" text NOT NULL,
	"ward" text,
	"landmark" text,
	"contact_phone" text,
	"photo_url" text,
	"filed_by_name" text,
	"status" text DEFAULT 'Submitted' NOT NULL,
	"admin_remark" text,
	"assigned_to" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY,
	"user_id" integer NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"type" text DEFAULT 'system' NOT NULL,
	"link" text,
	"is_read" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" serial PRIMARY KEY,
	"receipt_no" text NOT NULL,
	"user_id" integer NOT NULL,
	"property_id" integer NOT NULL,
	"amount" integer NOT NULL,
	"method" text NOT NULL,
	"status" text DEFAULT 'Success' NOT NULL,
	"paid_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "properties" (
	"id" serial PRIMARY KEY,
	"property_code" text NOT NULL,
	"user_id" integer NOT NULL,
	"owner_name" text NOT NULL,
	"address" text NOT NULL,
	"ward" text,
	"assessment_year" text NOT NULL,
	"assessment_amount" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "service_categories" (
	"id" serial PRIMARY KEY,
	"slug" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"icon" text DEFAULT 'Landmark' NOT NULL,
	"accent" text DEFAULT 'blue' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "services" (
	"id" serial PRIMARY KEY,
	"slug" text NOT NULL,
	"name" text NOT NULL,
	"category_slug" text NOT NULL,
	"summary" text NOT NULL,
	"description" text NOT NULL,
	"requirements" jsonb DEFAULT '[]' NOT NULL,
	"procedure" jsonb DEFAULT '[]' NOT NULL,
	"documents" jsonb DEFAULT '[]' NOT NULL,
	"official_portal_url" text,
	"handling_mode" text DEFAULT 'redirect' NOT NULL,
	"is_complaint_type" boolean DEFAULT false NOT NULL,
	"office" text,
	"disclaimer" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" serial PRIMARY KEY,
	"token" text NOT NULL,
	"user_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "support_tickets" (
	"id" serial PRIMARY KEY,
	"reference" text NOT NULL,
	"user_id" integer,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"topic" text NOT NULL,
	"message" text NOT NULL,
	"status" text DEFAULT 'Open' NOT NULL,
	"admin_reply" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"phone" text,
	"password_hash" text NOT NULL,
	"role" text DEFAULT 'citizen' NOT NULL,
	"ward" text,
	"address" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "announcements_published_idx" ON "announcements" ("is_published");--> statement-breakpoint
CREATE INDEX "application_events_application_idx" ON "application_events" ("application_id");--> statement-breakpoint
CREATE UNIQUE INDEX "applications_reference_unique" ON "applications" ("reference");--> statement-breakpoint
CREATE INDEX "applications_user_idx" ON "applications" ("user_id");--> statement-breakpoint
CREATE INDEX "applications_status_idx" ON "applications" ("status");--> statement-breakpoint
CREATE INDEX "complaint_events_complaint_idx" ON "complaint_events" ("complaint_id");--> statement-breakpoint
CREATE UNIQUE INDEX "complaints_reference_unique" ON "complaints" ("reference");--> statement-breakpoint
CREATE INDEX "complaints_user_idx" ON "complaints" ("user_id");--> statement-breakpoint
CREATE INDEX "complaints_status_idx" ON "complaints" ("status");--> statement-breakpoint
CREATE INDEX "notifications_user_idx" ON "notifications" ("user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "payments_receipt_unique" ON "payments" ("receipt_no");--> statement-breakpoint
CREATE INDEX "payments_user_idx" ON "payments" ("user_id");--> statement-breakpoint
CREATE INDEX "payments_property_idx" ON "payments" ("property_id");--> statement-breakpoint
CREATE UNIQUE INDEX "properties_code_unique" ON "properties" ("property_code");--> statement-breakpoint
CREATE INDEX "properties_user_idx" ON "properties" ("user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "service_categories_slug_unique" ON "service_categories" ("slug");--> statement-breakpoint
CREATE UNIQUE INDEX "services_slug_unique" ON "services" ("slug");--> statement-breakpoint
CREATE INDEX "services_category_idx" ON "services" ("category_slug");--> statement-breakpoint
CREATE UNIQUE INDEX "sessions_token_unique" ON "sessions" ("token");--> statement-breakpoint
CREATE INDEX "sessions_user_idx" ON "sessions" ("user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "support_tickets_reference_unique" ON "support_tickets" ("reference");--> statement-breakpoint
CREATE INDEX "support_tickets_user_idx" ON "support_tickets" ("user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "users_email_unique" ON "users" ("email");--> statement-breakpoint
CREATE INDEX "users_role_idx" ON "users" ("role");--> statement-breakpoint
ALTER TABLE "application_events" ADD CONSTRAINT "application_events_application_id_applications_id_fkey" FOREIGN KEY ("application_id") REFERENCES "applications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "applications" ADD CONSTRAINT "applications_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "complaint_events" ADD CONSTRAINT "complaint_events_complaint_id_complaints_id_fkey" FOREIGN KEY ("complaint_id") REFERENCES "complaints"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "complaints" ADD CONSTRAINT "complaints_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_property_id_properties_id_fkey" FOREIGN KEY ("property_id") REFERENCES "properties"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "properties" ADD CONSTRAINT "properties_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "support_tickets" ADD CONSTRAINT "support_tickets_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL;