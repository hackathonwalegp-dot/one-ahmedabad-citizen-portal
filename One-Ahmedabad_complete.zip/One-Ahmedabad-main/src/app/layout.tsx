import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Header } from "@/components/site/header";
import { Footer } from "@/components/site/footer";
import { LocaleProvider } from "@/components/site/locale-provider";
import { AssistantWidget } from "@/components/assistant/assistant-widget";

export const metadata: Metadata = {
  title: {
    default: "One Ahmedabad — Unified Digital Citizen Services Platform",
    template: "%s · One Ahmedabad",
  },
  description:
    "One Ahmedabad is a unified digital citizen services platform prototype for the Ahmedabad Municipal Corporation: discover municipal services, register and track civic complaints, and reach official AMC portals in one place.",
  keywords: [
    "One Ahmedabad",
    "AMC",
    "Ahmedabad Municipal Corporation",
    "digital citizen services",
    "civic complaints",
    "municipal services",
  ],
  openGraph: {
    title: "One Ahmedabad — Unified Digital Citizen Services Platform",
    description:
      "Discover municipal services, track complaints end-to-end and reach official AMC portals — built for the Ahmedabad Municipal Corporation problem statement.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0b1d35",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-ink-800 antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-ink-950 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
        >
          Skip to main content
        </a>
        <LocaleProvider>
          <div className="flex min-h-screen flex-col">
            <Header />
            <main id="main-content" className="flex-1">
              {children}
            </main>
            <Footer />
            <AssistantWidget />
          </div>
        </LocaleProvider>
      </body>
    </html>
  );
}
