import { HomeExperience } from "@/components/home/home-experience";
import {
  getPublishedAnnouncements,
  getServiceCategories,
  getServices,
} from "@/lib/data";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

const POPULAR_SLUGS = [
  "property-tax-information",
  "water-connection-information",
  "birth-registration-certificate",
  "garbage-collection-complaint",
  "potholes-damaged-roads",
  "building-permission-information",
];

export default async function HomePage() {
  await ensureSeedData();

  const [categories, allServices, announcements, allAnnouncements] = await Promise.all([
    getServiceCategories(),
    getServices(),
    getPublishedAnnouncements(3),
    getPublishedAnnouncements(),
  ]);

  const popular = POPULAR_SLUGS
    .map((slug) => allServices.find((service) => service.slug === slug))
    .filter((service): service is (typeof allServices)[number] => Boolean(service))
    .slice(0, 6)
    .map((service) => ({
      slug: service.slug,
      name: service.name,
      summary: service.summary,
      handlingMode: service.handlingMode,
      categorySlug: service.categorySlug,
      categoryName: service.categoryName,
      categoryIcon: service.categoryIcon,
      accent: service.accent,
    }));

  const categoryCards = categories.map((category) => ({
    slug: category.slug,
    name: category.name,
    description: category.description ?? "",
    icon: category.icon,
    accent: category.accent,
    serviceCount: allServices.filter((service) => service.categorySlug === category.slug).length,
  }));

  const complaintTypes = allServices.filter((service) => service.isComplaintType).length;
  const announcementCards = announcements.map((item) => ({
    id: item.id,
    title: item.title,
    body: item.body,
    category: item.category,
    publishedAt: item.publishedAt.toISOString(),
  }));

  return (
    <HomeExperience
      stats={{ services: allServices.length, categories: categories.length, complaintTypes }}
      categories={categoryCards}
      services={popular}
      announcements={announcementCards}
      announcementTotal={allAnnouncements.length}
    />
  );
}
