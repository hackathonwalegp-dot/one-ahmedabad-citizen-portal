import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { ComplaintForm } from "@/components/complaints/complaint-form";
import { PageHeader } from "@/components/ui/page-header";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getServices } from "@/lib/data";

export const metadata: Metadata = { title: "Register a complaint for a citizen" };
export const dynamic = "force-dynamic";

export default async function AssistComplaintPage({
  searchParams,
}: {
  searchParams: Promise<{ citizen?: string }>;
}) {
  const { citizen: param } = await searchParams;
  const id = Number(param ?? 0);
  if (!id) notFound();
  const rows = await db.select().from(users).where(and(eq(users.id, id), eq(users.role, "citizen"))).limit(1);
  const citizen = rows[0];
  if (!citizen) notFound();

  const services = (await getServices()).filter((service) => service.isComplaintType);

  return (
    <div>
      <Link href={`/centre/assist?citizen=${citizen.id}`} className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-orange-700">
        <ArrowLeft className="h-4 w-4" /> Back to {citizen.name}
      </Link>
      <div className="mt-4">
        <PageHeader eyebrow="SERVICE CENTRE" title="Register a complaint" description={`Filing for ${citizen.name}. Use the details the citizen gives you at the desk.`} />
      </div>
      <ComplaintForm
        onBehalfOf={{ id: citizen.id, name: citizen.name }}
        categories={services.map((service) => ({
          slug: service.slug,
          name: service.name,
          summary: service.summary,
          categoryName: service.categoryName,
          categoryIcon: service.categoryIcon,
          accent: service.accent,
        }))}
      />
    </div>
  );
}
