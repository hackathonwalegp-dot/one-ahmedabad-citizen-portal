import type { Metadata } from "next";
import Link from "next/link";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { ClipboardList, FilePlus2, Search, UserRound } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { db } from "@/db";
import { users } from "@/db/schema";

export const metadata: Metadata = { title: "Assist a citizen" };
export const dynamic = "force-dynamic";

export default async function AssistPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; citizen?: string }>;
}) {
  const { q = "", citizen: citizenParam } = await searchParams;
  const citizenId = Number(citizenParam ?? 0);

  if (citizenId) {
    const rows = await db.select().from(users).where(and(eq(users.id, citizenId), eq(users.role, "citizen"))).limit(1);
    const citizen = rows[0];
    if (citizen) {
      return (
        <div className="space-y-6">
          <PageHeader eyebrow="SERVICE CENTRE" title={`Assisting ${citizen.name}`} description="Choose what to file. The citizen sees it in their own account and receives a notification." />
          <div className="flex items-center gap-4 rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <span className="grid h-12 w-12 place-items-center bg-brand-50 text-brand-700"><UserRound className="h-6 w-6" /></span>
            <div className="min-w-0 text-sm">
              <p className="font-bold text-ink-900">{citizen.name}</p>
              <p className="text-xs text-ink-500">{citizen.phone ?? "No mobile"} · {citizen.ward ?? "Ward not set"}</p>
            </div>
            <Link href="/centre/assist" className="ah-text-link ml-auto text-xs">Change citizen</Link>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Link href={`/centre/assist/complaint?citizen=${citizen.id}`} className="card-hover rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-6 shadow-soft">
              <span className="grid h-11 w-11 place-items-center bg-orange-50 text-orange-700"><ClipboardList className="h-5 w-5" /></span>
              <h2 className="mt-4 text-base font-bold text-ink-900">Register a complaint</h2>
              <p className="mt-1.5 text-xs leading-relaxed text-ink-500">Water, roads, lights, garbage and drainage issues with an optional photo.</p>
            </Link>
            <Link href={`/centre/assist/application?citizen=${citizen.id}`} className="card-hover rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-6 shadow-soft">
              <span className="grid h-11 w-11 place-items-center bg-orange-50 text-orange-700"><FilePlus2 className="h-5 w-5" /></span>
              <h2 className="mt-4 text-base font-bold text-ink-900">Apply for a certificate or permit</h2>
              <p className="mt-1.5 text-xs leading-relaxed text-ink-500">Birth, death, trade licence and permit requests with a scanned document.</p>
            </Link>
          </div>
        </div>
      );
    }
  }

  const pattern = `%${q.trim()}%`;
  const list = await db
    .select({ id: users.id, name: users.name, email: users.email, phone: users.phone, ward: users.ward })
    .from(users)
    .where(q.trim() ? and(eq(users.role, "citizen"), or(ilike(users.name, pattern), ilike(users.email, pattern), ilike(users.phone, pattern))) : eq(users.role, "citizen"))
    .orderBy(desc(users.createdAt))
    .limit(20);

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="SERVICE CENTRE" title="Assist a citizen" description="Find the citizen by name, mobile number or email. If they have no account yet, register them first." action={<Link href="/centre/citizens" className="ah-button-primary">Register a citizen</Link>} />
      <form className="flex gap-3 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft" role="search">
        <label className="relative flex-1">
          <span className="sr-only">Search citizens</span>
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input name="q" defaultValue={q} placeholder="Name, mobile or email" className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100" />
        </label>
        <button type="submit" className="ah-button-primary">Search</button>
      </form>
      {list.length === 0 ? (
        <EmptyState title="No citizens found" body="Try another spelling or register the citizen." />
      ) : (
        <ul className="divide-y divide-ink-100 rounded-2xl border border-ink-100 bg-white shadow-soft">
          {list.map((citizen) => (
            <li key={citizen.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <div className="min-w-0">
                <p className="text-sm font-bold text-ink-900">{citizen.name}</p>
                <p className="text-xs text-ink-500">{citizen.phone ?? "No mobile"} · {citizen.email.endsWith(".invalid") ? "No email on file" : citizen.email} · {citizen.ward ?? "Ward not set"}</p>
              </div>
              <Link href={`/centre/assist?citizen=${citizen.id}`} className="ah-text-link text-sm">Assist</Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
