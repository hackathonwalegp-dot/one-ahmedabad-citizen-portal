import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { ApplicationForm } from "@/components/applications/application-form";
import { PageHeader } from "@/components/ui/page-header";
import { db } from "@/db";
import { users } from "@/db/schema";

export const metadata: Metadata = { title: "Apply for a citizen" };
export const dynamic = "force-dynamic";

export default async function AssistApplicationPage({
  searchParams,
}: {
  searchParams: Promise<{ citizen?: string }>;
}) {
  const { citizen: param } = await searchParams;
  const id = Number(param ?? 0);
  if (!id) notFound();
  const rows = await db.select().from(users).where(and(eq(users.id, id), eq(users.role, "citizen"))).limit(1);
  const citizen = rows[0];
  if (!citizen) notFound();

  return (
    <div>
      <Link href={`/centre/assist?citizen=${citizen.id}`} className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-orange-700">
        <ArrowLeft className="h-4 w-4" /> Back to {citizen.name}
      </Link>
      <div className="mt-4">
        <PageHeader eyebrow="SERVICE CENTRE" title="Apply for a certificate or permit" description={`Filing for ${citizen.name}. Scan or photograph the supporting document if the citizen has one.`} />
      </div>
      <ApplicationForm onBehalfOf={{ id: citizen.id, name: citizen.name }} defaultName={citizen.name} defaultWard={citizen.ward ?? ""} />
    </div>
  );
}
