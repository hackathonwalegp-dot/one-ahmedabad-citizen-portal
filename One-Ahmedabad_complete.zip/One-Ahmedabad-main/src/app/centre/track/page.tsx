import type { Metadata } from "next";
import Link from "next/link";
import { desc, ilike, or } from "drizzle-orm";
import { Search } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { applications, complaints } from "@/db/schema";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Search requests" };
export const dynamic = "force-dynamic";

export default async function CentreTrackPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const term = q.trim();
  const pattern = `%${term}%`;

  const [complaintRows, applicationRows] = term
    ? await Promise.all([
        db.select().from(complaints).where(or(ilike(complaints.reference, pattern), ilike(complaints.title, pattern), ilike(complaints.area, pattern), ilike(complaints.ward, pattern))).orderBy(desc(complaints.createdAt)).limit(25),
        db.select().from(applications).where(or(ilike(applications.reference, pattern), ilike(applications.applicantName, pattern), ilike(applications.type, pattern), ilike(applications.ward, pattern))).orderBy(desc(applications.createdAt)).limit(25),
      ])
    : [[], []];

  const results = [
    ...complaintRows.map((item) => ({ reference: item.reference, kind: "Complaint", title: item.title, status: item.status, at: item.createdAt })),
    ...applicationRows.map((item) => ({ reference: item.reference, kind: "Application", title: `${item.type} for ${item.applicantName}`, status: item.status, at: item.createdAt })),
  ].sort((a, b) => b.at.getTime() - a.at.getTime());

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="SERVICE CENTRE" title="Search requests" description="Find a complaint or application by reference number, title, applicant, area or ward." />
      <form className="flex gap-3 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft" role="search">
        <label className="relative flex-1">
          <span className="sr-only">Search requests</span>
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input name="q" defaultValue={q} placeholder="e.g. AMC-2026-123456 or Navrangpura" className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100" />
        </label>
        <button type="submit" className="ah-button-primary">Search</button>
      </form>

      {!term ? (
        <EmptyState title="Type something to search" body="Results include both complaints and applications." />
      ) : results.length === 0 ? (
        <EmptyState title="Nothing found" body="Check the reference number or try a shorter search." />
      ) : (
        <ul className="divide-y divide-ink-100 rounded-2xl border border-ink-100 bg-white shadow-soft">
          {results.map((item) => (
            <li key={item.reference}>
              <Link href={`/centre/requests/${item.reference}`} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 transition hover:bg-ink-50/60">
                <div className="min-w-0">
                  <p className="font-mono text-xs font-semibold text-brand-700">{item.reference} <span className="ml-2 rounded-full bg-ink-50 px-2 py-0.5 font-sans text-[10px] font-semibold uppercase tracking-wide text-ink-500">{item.kind}</span></p>
                  <p className="mt-0.5 truncate text-sm font-semibold text-ink-900">{item.title}</p>
                  <p className="text-[11px] text-ink-400">{formatDateTime(item.at)}</p>
                </div>
                <StatusBadge status={item.status} />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
