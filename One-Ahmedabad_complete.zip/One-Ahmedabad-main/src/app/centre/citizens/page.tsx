import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { CitizenForm } from "@/components/centre/citizen-form";
import { PageHeader } from "@/components/ui/page-header";
import { db } from "@/db";
import { users } from "@/db/schema";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Register a citizen" };
export const dynamic = "force-dynamic";

export default async function CentreCitizensPage() {
  const recent = await db
    .select({ id: users.id, name: users.name, email: users.email, phone: users.phone, ward: users.ward, createdAt: users.createdAt })
    .from(users)
    .where(eq(users.role, "citizen"))
    .orderBy(desc(users.createdAt))
    .limit(6);

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="SERVICE CENTRE" title="Register a citizen" description="Create an account for someone who does not have one yet. You can then file requests for them." />
      <CitizenForm />
      <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        <h2 className="text-base font-bold text-ink-900">Recently registered citizens</h2>
        <ul className="mt-4 divide-y divide-ink-100">
          {recent.map((citizen) => (
            <li key={citizen.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div className="min-w-0">
                <p className="text-sm font-semibold text-ink-900">{citizen.name}</p>
                <p className="text-xs text-ink-500">{citizen.phone ?? "No mobile"} · {citizen.ward ?? "Ward not set"} · joined {formatDate(citizen.createdAt)}</p>
              </div>
              <Link href={`/centre/assist?citizen=${citizen.id}`} className="ah-text-link text-xs">File a request</Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
