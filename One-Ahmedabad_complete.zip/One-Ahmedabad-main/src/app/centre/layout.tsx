import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Building2, ShieldCheck } from "lucide-react";
import { SideNav, type SideNavItem } from "@/components/site/side-nav";
import { T } from "@/components/site/t";
import { getCurrentUser, isStaff, toPublicUser } from "@/lib/auth";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

const ITEMS: SideNavItem[] = [
  { href: "/centre", labelKey: "nav.centreHome", icon: "overview", exact: true },
  { href: "/centre/citizens", labelKey: "nav.centreCitizens", icon: "registerCitizen" },
  { href: "/centre/assist", labelKey: "nav.centreAssist", icon: "assist" },
  { href: "/centre/track", labelKey: "nav.centreTrack", icon: "search" },
];

export default async function CentreLayout({ children }: { children: ReactNode }) {
  await ensureSeedData();
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/centre");
  if (!isStaff(user)) redirect("/dashboard");

  const publicUser = toPublicUser(user);

  return (
    <div className="bg-ink-50/50">
      <div className="container-page flex gap-8 py-6 lg:py-10">
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-40 space-y-6">
            <div className="rounded-2xl border-t-[3px] border-t-orange-500 bg-ink-950 p-5 text-white shadow-lift">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-orange-200">
                <Building2 className="h-3 w-3" /> <T k="side.centreConsole" />
              </span>
              <p className="mt-3 truncate text-sm font-bold">{publicUser.name}</p>
              <p className="truncate text-xs text-ink-400">{publicUser.email}</p>
              <p className="mt-3 text-[11px] leading-relaxed text-ink-400">
                Help citizens who visit in person. Everything you file is recorded under your name.
              </p>
            </div>

            <SideNav items={ITEMS} variant="sidebar" />

            {publicUser.role === "admin" && (
              <Link
                href="/admin"
                className="flex items-center gap-3 rounded-xl bg-ink-900 px-3.5 py-2.5 text-sm font-semibold text-white shadow-soft transition hover:bg-ink-800"
              >
                <ShieldCheck className="h-[18px] w-[18px]" />
                <T k="side.adminConsole" />
              </Link>
            )}
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <div className="-mx-5 mb-5 overflow-x-auto px-5 scroll-slim lg:hidden">
            <SideNav items={ITEMS} variant="pills" />
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
