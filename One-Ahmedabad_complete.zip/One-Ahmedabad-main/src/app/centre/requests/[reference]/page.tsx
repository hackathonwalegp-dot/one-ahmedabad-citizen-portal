import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { Timeline } from "@/components/ui/timeline";
import { db } from "@/db";
import { applicationEvents, applications, complaintEvents, complaints, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Request details" };
export const dynamic = "force-dynamic";

/** Read-only view for service-centre staff. Decisions stay with administrators. */
export default async function CentreRequestPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const staff = await getCurrentUser();
  if (!staff) return null;
  const { reference } = await params;

  const complaintRows = await db.select().from(complaints).where(eq(complaints.reference, reference)).limit(1);
  const complaint = complaintRows[0];
  const application = complaint
    ? undefined
    : (await db.select().from(applications).where(eq(applications.reference, reference)).limit(1))[0];
  if (!complaint && !application) notFound();

  const userId = (complaint ?? application)!.userId;
  const [owner] = await db.select().from(users).where(eq(users.id, userId)).limit(1);

  const events = complaint
    ? await db.select().from(complaintEvents).where(eq(complaintEvents.complaintId, complaint.id)).orderBy(desc(complaintEvents.createdAt))
    : await db.select().from(applicationEvents).where(eq(applicationEvents.applicationId, application!.id)).orderBy(desc(applicationEvents.createdAt));

  const title = complaint ? complaint.title : `${application!.type} for ${application!.applicantName}`;
  const status = (complaint ?? application)!.status;
  const body = complaint ? complaint.description : application!.details;
  const remark = (complaint ?? application)!.adminRemark;
  const rows: [string, string][] = complaint
    ? [["Area", complaint.area], ["Ward", complaint.ward ?? "Not specified"], ["Landmark", complaint.landmark ?? "Not specified"], ["Assigned to", complaint.assignedTo ?? "Awaiting assignment"]]
    : [["Applicant", application!.applicantName], ["Ward", application!.ward ?? "Not specified"], ["Department", application!.assignedTo ?? "Awaiting assignment"], ["Document", application!.documentName ?? "None attached"]];

  return (
    <div>
      <Link href="/centre/track" className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-orange-700">
        <ArrowLeft className="h-4 w-4" /> Back to search
      </Link>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">{reference} · {complaint ? "Complaint" : "Application"}</p>
                <h1 className="mt-1.5 text-xl font-bold tracking-tight text-ink-900 sm:text-2xl">{title}</h1>
                <p className="mt-1.5 text-sm text-ink-500">Received {formatDate((complaint ?? application)!.createdAt)}</p>
              </div>
              <StatusBadge status={status} className="px-3 py-1.5 text-sm" />
            </div>
            <p className="mt-5 whitespace-pre-line text-sm leading-relaxed text-ink-700">{body}</p>
            <dl className="mt-6 grid gap-3 sm:grid-cols-2">
              {rows.map(([label, value]) => (
                <div key={label} className="rounded-xl border border-ink-100 px-4 py-3">
                  <dt className="text-[11px] font-medium uppercase tracking-wide text-ink-400">{label}</dt>
                  <dd className="mt-1 text-xs font-semibold text-ink-800">{value}</dd>
                </div>
              ))}
            </dl>
          </section>
          <Timeline title="History" events={events} />
        </div>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="text-sm font-bold text-ink-900">Citizen</h2>
            {owner ? (
              <dl className="mt-3 space-y-2 text-xs">
                <div className="flex justify-between gap-3"><dt className="text-ink-400">Name</dt><dd className="font-semibold text-ink-800">{owner.name}</dd></div>
                <div className="flex justify-between gap-3"><dt className="text-ink-400">Mobile</dt><dd className="font-semibold text-ink-800">{owner.phone ?? "Not provided"}</dd></div>
                <div className="flex justify-between gap-3"><dt className="text-ink-400">Ward</dt><dd className="font-semibold text-ink-800">{owner.ward ?? "Not set"}</dd></div>
              </dl>
            ) : (
              <p className="mt-2 text-xs text-ink-500">Citizen record unavailable.</p>
            )}
          </div>
          {remark && (
            <div className="rounded-2xl border border-orange-100 bg-orange-50/70 p-5">
              <h2 className="text-sm font-bold text-orange-950">Latest remark</h2>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{remark}</p>
            </div>
          )}
          {staff.role === "admin" && (
            <Link href={complaint ? `/admin/complaints/${reference}` : `/admin/applications/${reference}`} className="block rounded-2xl bg-ink-950 p-4 text-center text-xs font-semibold text-white shadow-soft transition hover:bg-ink-800">
              Open in the admin console
            </Link>
          )}
        </aside>
      </div>
    </div>
  );
}
