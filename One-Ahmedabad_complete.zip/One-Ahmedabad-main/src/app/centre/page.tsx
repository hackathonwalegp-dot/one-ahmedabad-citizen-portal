import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { ArrowRight, HeartHandshake, Search, UserPlus } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { applications, complaints } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Service-centre desk" };
export const dynamic = "force-dynamic";

export default async function CentreHomePage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const [filedComplaints, filedApplications] = await Promise.all([
    db.select().from(complaints).where(eq(complaints.filedByName, user.name)).orderBy(desc(complaints.createdAt)).limit(8),
    db.select().from(applications).where(eq(applications.filedByName, user.name)).orderBy(desc(applications.createdAt)).limit(8),
  ]);

  const recent = [
    ...filedComplaints.map((item) => ({ reference: item.reference, title: item.title, kind: "Complaint", status: item.status, at: item.createdAt })),
    ...filedApplications.map((item) => ({ reference: item.reference, title: `${item.type} for ${item.applicantName}`, kind: "Application", status: item.status, at: item.createdAt })),
  ]
    .sort((a, b) => b.at.getTime() - a.at.getTime())
    .slice(0, 8);

  const tiles = [
    { href: "/centre/citizens", icon: UserPlus, title: "Register a citizen", body: "Create a profile for a visitor and hand over a temporary password." },
    { href: "/centre/assist", icon: HeartHandshake, title: "Assist a citizen", body: "File a complaint or certificate application on their behalf." },
    { href: "/centre/track", icon: Search, title: "Search requests", body: "Find any complaint or application by reference, name or area." },
  ];

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="SERVICE CENTRE" title={`Welcome, ${user.name.split(" ")[0]}`} description="Help citizens who visit in person. Everything you file is recorded under your name and shown in the citizen's own account." />

      <div className="grid gap-4 md:grid-cols-3">
        {tiles.map((tile) => (
          <Link key={tile.href} href={tile.href} className="card-hover flex flex-col rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-5 shadow-soft">
            <span className="grid h-11 w-11 place-items-center bg-orange-50 text-orange-700"><tile.icon className="h-5 w-5" /></span>
            <h2 className="mt-4 text-base font-bold text-ink-900">{tile.title}</h2>
            <p className="mt-1.5 flex-1 text-xs leading-relaxed text-ink-500">{tile.body}</p>
            <span className="ah-text-link mt-4 text-xs">Open <ArrowRight className="h-3.5 w-3.5" /></span>
          </Link>
        ))}
      </div>

      <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        <h2 className="text-base font-bold text-ink-900">Filed by you recently</h2>
        {recent.length === 0 ? (
          <div className="mt-4"><EmptyState title="Nothing filed yet" body="Requests you file for citizens will be listed here." /></div>
        ) : (
          <ul className="mt-4 divide-y divide-ink-100">
            {recent.map((item) => (
              <li key={item.reference}>
                <Link href={`/centre/requests/${item.reference}`} className="flex flex-wrap items-center justify-between gap-3 py-3 transition hover:bg-ink-50/60">
                  <div className="min-w-0">
                    <p className="font-mono text-xs font-semibold text-brand-700">{item.reference} <span className="ml-2 rounded-full bg-ink-50 px-2 py-0.5 font-sans text-[10px] font-semibold uppercase tracking-wide text-ink-500">{item.kind}</span></p>
                    <p className="mt-0.5 truncate text-sm font-semibold text-ink-900">{item.title}</p>
                    <p className="text-[11px] text-ink-400">{formatDateTime(item.at)}</p>
                  </div>
                  <StatusBadge status={item.status} />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
