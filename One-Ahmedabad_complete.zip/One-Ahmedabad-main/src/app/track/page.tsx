import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Search } from "lucide-react";
import { TrackLookup } from "@/components/complaints/track-lookup";

export const metadata: Metadata = {
  title: "Track a request",
  description:
    "Track the status of a One Ahmedabad complaint or certificate application using the reference number and your registered email address.",
};

export const dynamic = "force-dynamic";

export default function TrackPage() {
  return (
    <div className="bg-ink-50/40">
      <section className="border-b border-ink-100 bg-white">
        <div className="container-page py-10 lg:py-14">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand-600">
            Complaint tracking
          </p>
          <h1 className="mt-2 text-[clamp(1.9rem,3.6vw,2.6rem)] font-bold tracking-tight">
            Track a complaint or application with its reference number
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-500">
            Every complaint registered on One Ahmedabad receives a reference number such as
            AMC-2026-482193. Enter it together with the email address you used, to see the current
            status without signing in.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Link
              href="/dashboard/complaints/new"
              className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700"
            >
              <Search className="h-4 w-4" />
              Register a new complaint
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
            >
              Sign in for full history
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <div className="container-page py-8 lg:py-10">
        <TrackLookup />
      </div>
    </div>
  );
}
