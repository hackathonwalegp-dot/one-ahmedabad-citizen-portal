import { getServiceCategories, getServices } from "@/lib/data";
import { ok } from "@/lib/api";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  await ensureSeedData();
  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q") ?? "";
  const category = searchParams.get("category") ?? "";
  const limitParam = Number(searchParams.get("limit"));
  const limit = Number.isFinite(limitParam) && limitParam > 0 ? Math.min(limitParam, 50) : undefined;

  const [services, categories] = await Promise.all([
    getServices({ q, category: category || undefined, limit }),
    getServiceCategories(),
  ]);

  return ok({
    services: services.map((service) => ({
      slug: service.slug,
      name: service.name,
      summary: service.summary,
      categoryName: service.categoryName,
      categorySlug: service.categorySlug,
      categoryIcon: service.categoryIcon,
      accent: service.accent,
      handlingMode: service.handlingMode,
      officialPortalUrl: service.officialPortalUrl,
      office: service.office,
      isActive: service.isActive,
    })),
    categories: categories.map((item) => ({
      slug: item.slug,
      name: item.name,
      description: item.description,
      icon: item.icon,
      accent: item.accent,
    })),
  });
}
