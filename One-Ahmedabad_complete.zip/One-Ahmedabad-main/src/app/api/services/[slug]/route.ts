import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { services } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";

const updateServiceSchema = z.object({
  summary: z.string().trim().min(10, "Summary is too short.").max(400).optional(),
  description: z.string().trim().min(20, "Description is too short.").max(4000).optional(),
  requirements: z.array(z.string().trim().min(1)).max(20).optional(),
  procedure: z.array(z.string().trim().min(1)).max(20).optional(),
  documents: z.array(z.string().trim().min(1)).max(20).optional(),
  office: z.string().trim().max(200).optional().or(z.literal("")),
  disclaimer: z.string().trim().max(400).optional().or(z.literal("")),
  officialPortalUrl: z
    .string()
    .trim()
    .max(300)
    .url("Enter a valid URL.")
    .optional()
    .or(z.literal("")),
  handlingMode: z.enum(["demo", "redirect", "hybrid"]).optional(),
  isActive: z.boolean().optional(),
});

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "admin") return fail("Administrator access required.", 403);

  const { slug } = await params;

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = updateServiceSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const data = parsed.data;

  const update: Partial<typeof services.$inferInsert> = { updatedAt: new Date() };
  if (data.summary !== undefined) update.summary = data.summary;
  if (data.description !== undefined) update.description = data.description;
  if (data.requirements !== undefined) update.requirements = data.requirements;
  if (data.procedure !== undefined) update.procedure = data.procedure;
  if (data.documents !== undefined) update.documents = data.documents;
  if (data.office !== undefined) update.office = data.office || null;
  if (data.disclaimer !== undefined) update.disclaimer = data.disclaimer || null;
  if (data.officialPortalUrl !== undefined) {
    update.officialPortalUrl = data.officialPortalUrl || null;
  }
  if (data.handlingMode !== undefined) update.handlingMode = data.handlingMode;
  if (data.isActive !== undefined) update.isActive = data.isActive;

  const updated = await db
    .update(services)
    .set(update)
    .where(eq(services.slug, slug))
    .returning();

  if (!updated.length) return fail("Service not found.", 404);

  return ok({ service: updated[0], message: "Service information updated." });
}
