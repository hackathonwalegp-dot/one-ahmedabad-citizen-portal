import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { applicationEvents, applications } from "@/db/schema";
import { getCurrentUser, isStaff } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { APPLICATION_STATUSES } from "@/lib/applications";
import { notifyUser } from "@/lib/notify";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ reference: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  const { reference } = await params;

  const rows = await db.select().from(applications).where(eq(applications.reference, reference)).limit(1);
  const application = rows[0];
  if (!application) return fail("No application found with that reference.", 404);
  if (!isStaff(user) && application.userId !== user.id) {
    return fail("You do not have access to this application.", 403);
  }

  const events = await db
    .select()
    .from(applicationEvents)
    .where(eq(applicationEvents.applicationId, application.id))
    .orderBy(desc(applicationEvents.createdAt));

  return ok({ application, events });
}

const updateSchema = z.object({
  status: z.enum(APPLICATION_STATUSES),
  remark: z.string().trim().max(1000, "Remark is too long.").optional().or(z.literal("")),
  assignedTo: z.string().trim().max(120).optional().or(z.literal("")),
});

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ reference: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "admin") return fail("Administrator access required.", 403);
  const { reference } = await params;

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = updateSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const rows = await db.select().from(applications).where(eq(applications.reference, reference)).limit(1);
  const application = rows[0];
  if (!application) return fail("No application found with that reference.", 404);

  const { status, remark, assignedTo } = parsed.data;
  const changed = application.status !== status;
  const decided = status === "Approved" || status === "Rejected";

  const updated = await db
    .update(applications)
    .set({
      status,
      adminRemark: remark || application.adminRemark,
      assignedTo: assignedTo || application.assignedTo,
      decidedAt: decided ? new Date() : null,
      updatedAt: new Date(),
    })
    .where(eq(applications.id, application.id))
    .returning();

  await db.insert(applicationEvents).values({
    applicationId: application.id,
    status,
    note: remark || `Status updated to ${status} by the administrator.`,
    actorType: "admin",
    actorName: user.name,
  });

  if (changed || (remark && remark !== application.adminRemark)) {
    await notifyUser(application.userId, {
      title: changed
        ? `Application ${application.reference} — ${status}`
        : `Update on application ${application.reference}`,
      body:
        remark ||
        `The status of your ${application.type} request moved from ${application.status} to ${status}.`,
      type: "status",
      link: `/dashboard/applications/${application.reference}`,
    });
  }

  return ok({
    application: updated[0],
    message: changed ? `Status updated to ${status}.` : "Remark saved.",
  });
}
