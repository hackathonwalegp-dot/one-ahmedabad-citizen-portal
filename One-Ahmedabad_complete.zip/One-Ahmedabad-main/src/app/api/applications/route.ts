import { and, desc, eq, ilike, or } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { applicationEvents, applications, users } from "@/db/schema";
import { getCurrentUser, isStaff } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { applicationType, APPLICATION_TYPES } from "@/lib/applications";
import { notifyUser } from "@/lib/notify";
import { uniqueReference } from "@/lib/refs";
import { saveUpload } from "@/lib/storage";

export const dynamic = "force-dynamic";

const applicationSchema = z.object({
  type: z.string().trim().refine((value) => APPLICATION_TYPES.some((item) => item.name === value), {
    message: "Select an application type.",
  }),
  applicantName: z.string().trim().min(2, "Enter the applicant's full name.").max(120),
  details: z
    .string()
    .trim()
    .min(15, "Describe the request in at least 15 characters.")
    .max(2000, "Details are too long."),
  ward: z.string().trim().max(80).optional().or(z.literal("")),
  citizenId: z.coerce.number().int().positive().optional(),
});

export async function POST(request: Request) {
  const actor = await getCurrentUser();
  if (!actor) return fail("Please sign in to submit an application.", 401);

  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return fail("Invalid form submission.", 400);
  }

  const citizenIdRaw = formData.get("citizenId");
  const parsed = applicationSchema.safeParse({
    type: formData.get("type") ?? "",
    applicantName: formData.get("applicantName") ?? "",
    details: formData.get("details") ?? "",
    ward: formData.get("ward") ?? "",
    citizenId: citizenIdRaw ? citizenIdRaw : undefined,
  });
  if (!parsed.success) return validationError(parsed.error);
  const data = parsed.data;

  // Staff file on behalf of a citizen; citizens file for themselves.
  let owner = actor;
  let filedByName: string | null = null;
  if (data.citizenId) {
    if (!isStaff(actor)) return fail("Only service-centre staff can file on behalf of a citizen.", 403);
    const target = await db.select().from(users).where(eq(users.id, data.citizenId)).limit(1);
    if (!target[0] || target[0].role !== "citizen") return fail("Citizen account not found.", 404);
    owner = target[0];
    filedByName = actor.name;
  } else if (actor.role !== "citizen") {
    return fail("Choose a citizen account to file this application for.", 422);
  }

  let documentUrl: string | null = null;
  let documentName: string | null = null;
  const file = formData.get("document");
  if (file instanceof File && file.size > 0) {
    const upload = await saveUpload(file, { folder: "applications", allowPdf: true });
    if (!upload.ok) return fail(upload.error, 422);
    documentUrl = `/api/files?key=${encodeURIComponent(upload.key)}`;
    documentName = file.name.slice(0, 120);
  }

  const reference = await uniqueReference("AMC-APP", async (candidate) => {
    const rows = await db
      .select({ id: applications.id })
      .from(applications)
      .where(eq(applications.reference, candidate))
      .limit(1);
    return rows.length > 0;
  });

  const info = applicationType(data.type);
  const inserted = await db
    .insert(applications)
    .values({
      reference,
      userId: owner.id,
      type: data.type,
      applicantName: data.applicantName,
      details: data.details,
      ward: data.ward || owner.ward || null,
      documentUrl,
      documentName,
      filedByName,
      assignedTo: info?.department ?? null,
      status: "Submitted",
    })
    .returning();
  const application = inserted[0];

  await db.insert(applicationEvents).values({
    applicationId: application.id,
    status: "Submitted",
    note: filedByName
      ? `Application filed at a service centre by ${filedByName}.`
      : "Application submitted by the citizen.",
    actorType: filedByName ? "operator" : "citizen",
    actorName: actor.name,
  });

  await notifyUser(owner.id, {
    title: "Application submitted",
    body: `Your ${application.type} request was registered with reference ${application.reference}. You will be notified when its status changes.`,
    type: "application",
    link: `/dashboard/applications/${application.reference}`,
  });

  return ok({ application, reference: application.reference, message: "Application submitted." }, 201);
}

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status") ?? "";
  const type = searchParams.get("type") ?? "";
  const q = searchParams.get("q") ?? "";

  const conditions = [];
  if (!isStaff(user)) conditions.push(eq(applications.userId, user.id));
  if (status && status !== "all") conditions.push(eq(applications.status, status));
  if (type && type !== "all") conditions.push(eq(applications.type, type));
  if (q.trim()) {
    const pattern = `%${q.trim()}%`;
    conditions.push(
      or(
        ilike(applications.reference, pattern),
        ilike(applications.applicantName, pattern),
        ilike(applications.type, pattern),
      )!,
    );
  }

  const rows = await db
    .select()
    .from(applications)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(applications.createdAt));

  return ok({ applications: rows });
}
