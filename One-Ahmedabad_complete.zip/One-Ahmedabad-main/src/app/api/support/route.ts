import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { supportTickets } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { notifyUser } from "@/lib/notify";
import { uniqueReference } from "@/lib/refs";

export const dynamic = "force-dynamic";

export const SUPPORT_TOPICS = [
  "Complaint status",
  "Application or certificate",
  "Property tax simulator",
  "Account or password",
  "Language or accessibility",
  "Something else",
] as const;

const ticketSchema = z.object({
  name: z.string().trim().min(2, "Enter your name.").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  topic: z.enum(SUPPORT_TOPICS),
  message: z
    .string()
    .trim()
    .min(15, "Tell us a little more (at least 15 characters).")
    .max(2000, "Message is too long."),
});

export async function POST(request: Request) {
  const user = await getCurrentUser();

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = ticketSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const reference = await uniqueReference("SUP", async (candidate) => {
    const rows = await db
      .select({ id: supportTickets.id })
      .from(supportTickets)
      .where(eq(supportTickets.reference, candidate))
      .limit(1);
    return rows.length > 0;
  });

  const inserted = await db
    .insert(supportTickets)
    .values({ ...parsed.data, reference, userId: user?.id ?? null })
    .returning();

  if (user) {
    await notifyUser(user.id, {
      title: "Support request received",
      body: `Your request ${reference} about “${parsed.data.topic}” was logged. A reply will appear on the support page.`,
      type: "support",
      link: "/dashboard/support",
    });
  }

  return ok({ ticket: inserted[0], reference, message: "Support request sent." }, 201);
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  const base = db.select().from(supportTickets);
  const rows = await (user.role === "admin"
    ? base.orderBy(desc(supportTickets.createdAt))
    : base.where(eq(supportTickets.userId, user.id)).orderBy(desc(supportTickets.createdAt)));
  return ok({ tickets: rows });
}

const replySchema = z.object({
  reference: z.string().trim().min(6),
  status: z.enum(["Open", "Answered", "Closed"]),
  reply: z.string().trim().max(2000).optional().or(z.literal("")),
});

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "admin") return fail("Administrator access required.", 403);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = replySchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const { reference, status, reply } = parsed.data;

  const rows = await db.select().from(supportTickets).where(eq(supportTickets.reference, reference)).limit(1);
  const ticket = rows[0];
  if (!ticket) return fail("Support request not found.", 404);

  const updated = await db
    .update(supportTickets)
    .set({ status, adminReply: reply || ticket.adminReply, updatedAt: new Date() })
    .where(eq(supportTickets.id, ticket.id))
    .returning();

  if (ticket.userId && reply && reply !== ticket.adminReply) {
    await notifyUser(ticket.userId, {
      title: `Reply to support request ${ticket.reference}`,
      body: reply,
      type: "support",
      link: "/dashboard/support",
    });
  }

  return ok({ ticket: updated[0], message: "Support request updated." });
}
