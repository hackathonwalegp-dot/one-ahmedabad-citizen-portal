import { z } from "zod";
import { answerQuestion, type AssistantReply, type AssistantService } from "@/lib/assistant";
import { fail, ok, validationError } from "@/lib/api";
import { getServices } from "@/lib/data";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

const requestSchema = z.object({
  message: z.string().trim().min(1, "Type a question.").max(600, "Question is too long."),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(2000) }))
    .max(12)
    .optional(),
  locale: z.enum(["en", "gu", "hi"]).optional(),
});

/**
 * Modular assistant endpoint.
 *
 * If an external, OpenAI-compatible provider is configured
 * (AI_ASSISTANT_API_URL + AI_ASSISTANT_API_KEY) it is used first, with the
 * service directory injected as grounding context. Otherwise the deterministic
 * rule-based engine answers — the platform therefore works without any
 * external AI dependency.
 */
export async function POST(request: Request) {
  await ensureSeedData();

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = requestSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const { message, history, locale = "en" } = parsed.data;

  const services = await getServices();
  const assistantServices: AssistantService[] = services.map((service) => ({
    slug: service.slug,
    name: service.name,
    summary: service.summary,
    categoryName: service.categoryName,
    categorySlug: service.categorySlug,
    handlingMode: service.handlingMode,
    officialPortalUrl: service.officialPortalUrl,
    isComplaintType: service.isComplaintType,
    procedure: service.procedure,
    requirements: service.requirements,
    documents: service.documents,
    office: service.office,
  }));

  const providerReply = await tryExternalProvider(message, history ?? [], assistantServices, locale);
  if (providerReply) return ok(providerReply);

  const reply: AssistantReply = answerQuestion(message, assistantServices);
  return ok(reply);
}

async function tryExternalProvider(
  message: string,
  history: Array<{ role: "user" | "assistant"; content: string }>,
  services: AssistantService[],
  locale: "en" | "gu" | "hi",
): Promise<AssistantReply | null> {
  const url = process.env.AI_ASSISTANT_API_URL;
  const apiKey = process.env.AI_ASSISTANT_API_KEY;
  if (!url || !apiKey) return null;

  const context = services
    .map(
      (service) =>
        `- ${service.name} [${service.categoryName}] (${service.handlingMode}): ${service.summary} | office: ${service.office ?? "n/a"} | portal: ${service.officialPortalUrl ?? "none"}`,
    )
    .join("\n");

  const systemPrompt = [
    "You are NagarSetu, the multilingual civic-service assistant for the One Ahmedabad hackathon prototype.",
    `Reply in ${locale === "gu" ? "Gujarati" : locale === "hi" ? "Hindi" : "English"}. If the citizen writes in another language, follow the citizen's language.`,
    "Answer only from the service directory facts below. Never invent fees, processing times, eligibility rules, complaint status, government decisions or AMC integrations.",
    "Do not claim to submit complaints, make payments, issue certificates, access personal records or contact AMC unless an actual tool result explicitly confirms that action.",
    "Do not ask for passwords, OTPs, full identity numbers or payment card details. For private application status, direct the citizen to the signed-in dashboard or the secure tracking flow.",
    "If the answer is not in the directory, say so and direct the citizen to the official AMC portal.",
    "Mention that One Ahmedabad is a prototype and not officially connected to AMC.",
    "",
    "Service directory:",
    context,
  ].join("\n");

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 18000);
    let response: Response;
    try {
      response = await fetch(url, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: process.env.AI_ASSISTANT_MODEL ?? "gpt-4o-mini",
        temperature: 0.2,
        messages: [
          { role: "system", content: systemPrompt },
          ...history.map((entry) => ({ role: entry.role, content: entry.content })),
          { role: "user", content: message },
        ],
      }),
      });
    } finally {
      clearTimeout(timeout);
    }

    if (!response.ok) return null;
    const data = await response.json();
    const content: string | undefined = data?.choices?.[0]?.message?.content;
    if (!content) return null;

    const matches = services
      .filter((service) => content.toLowerCase().includes(service.name.toLowerCase()))
      .slice(0, 3)
      .map((service) => ({
        slug: service.slug,
        name: service.name,
        categoryName: service.categoryName,
        summary: service.summary,
        handlingMode: service.handlingMode,
      }));

    return {
      reply: content,
      matches,
      suggestions: ["How do I raise a complaint?", "Where do I apply officially?", "What documents do I need?"],
      source: "directory",
    };
  } catch {
    return null;
  }
}
