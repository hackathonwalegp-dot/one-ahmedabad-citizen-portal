import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureSeedData();
    return Response.json({ ok: true, service: "one-ahmedabad", seeded: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
