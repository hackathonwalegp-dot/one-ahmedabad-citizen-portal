import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt));

  return ok({ notifications: rows });
}

const updateSchema = z.object({
  id: z.number().int().optional(),
  action: z.enum(["markRead", "markAllRead", "markUnread"]),
});

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = updateSchema.safeParse(payload);
  if (!parsed.success) return fail("Invalid request payload.", 422);

  const { id, action } = parsed.data;

  if (action === "markAllRead") {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, user.id));
    return ok({ message: "All notifications marked as read." });
  }

  if (!id) return fail("Notification id is required.", 422);

  const target = await db
    .select()
    .from(notifications)
    .where(and(eq(notifications.id, id), eq(notifications.userId, user.id)))
    .limit(1);
  if (!target.length) return fail("Notification not found.", 404);

  await db
    .update(notifications)
    .set({ isRead: action === "markRead" })
    .where(eq(notifications.id, id));

  return ok({ message: "Notification updated." });
}
