import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { announcements, notifications, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select()
    .from(announcements)
    .where(eq(announcements.isPublished, true))
    .orderBy(desc(announcements.publishedAt));
  return ok({ announcements: rows });
}

const createSchema = z.object({
  title: z.string().trim().min(8, "Give the announcement a clear title.").max(160),
  body: z.string().trim().min(30, "Write at least 30 characters of detail.").max(4000),
  category: z.string().trim().min(2, "Add a category.").max(60),
  notifyCitizens: z.boolean().optional(),
});

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "admin") return fail("Administrator access required.", 403);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = createSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const { title, body, category, notifyCitizens } = parsed.data;

  const inserted = await db
    .insert(announcements)
    .values({
      title,
      body,
      category,
      isPublished: true,
      createdBy: user.name,
    })
    .returning();

  if (notifyCitizens !== false) {
    const citizens = await db.select({ id: users.id }).from(users);
    if (citizens.length) {
      await db.insert(notifications).values(
        citizens.map((citizen) => ({
          userId: citizen.id,
          title: `Announcement: ${title}`,
          body: body.slice(0, 240),
          type: "announcement",
          link: "/announcements",
        })),
      );
    }
  }

  return ok({ announcement: inserted[0], message: "Announcement published." }, 201);
}
