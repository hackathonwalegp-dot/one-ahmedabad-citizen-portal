import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword, SESSION_COOKIE, toPublicUser } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { ensureSeedData } from "@/lib/seed";

const registerSchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name.").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  phone: z
    .string()
    .trim()
    .max(20, "Phone number is too long.")
    .optional()
    .or(z.literal("")),
  ward: z.string().trim().max(60).optional().or(z.literal("")),
  address: z.string().trim().max(240).optional().or(z.literal("")),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters.")
    .max(120, "Password is too long.")
    .regex(/[A-Za-z]/, "Password must contain at least one letter.")
    .regex(/[0-9]/, "Password must contain at least one number."),
});

export async function POST(request: Request) {
  await ensureSeedData();

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = registerSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const { name, email, phone, ward, address, password } = parsed.data;

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) {
    return fail("An account with this email already exists. Try signing in instead.", 409);
  }

  const inserted = await db
    .insert(users)
    .values({
      name,
      email,
      phone: phone || null,
      ward: ward || null,
      address: address || null,
      passwordHash: hashPassword(password),
      role: "citizen",
    })
    .returning();

  const user = inserted[0];
  const token = await createSession(user.id);

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 14,
  });

  return ok({ user: toPublicUser(user), message: "Account created successfully." }, 201);
}
