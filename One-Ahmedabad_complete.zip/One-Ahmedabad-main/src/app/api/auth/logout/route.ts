import { cookies } from "next/headers";
import { destroySession, getSessionToken, SESSION_COOKIE } from "@/lib/auth";
import { ok } from "@/lib/api";

export async function POST() {
  const token = await getSessionToken();
  if (token) await destroySession(token);

  const store = await cookies();
  store.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });

  return ok({ message: "Signed out." });
}
