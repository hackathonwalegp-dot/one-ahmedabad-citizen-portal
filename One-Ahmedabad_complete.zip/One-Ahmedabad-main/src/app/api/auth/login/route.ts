import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, SESSION_COOKIE, toPublicUser, verifyPassword, homeFor } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { ensureSeedData } from "@/lib/seed";

const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  password: z.string().min(1, "Enter your password."),
});

export async function POST(request: Request) {
  await ensureSeedData();

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = loginSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const { email, password } = parsed.data;

  const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const user = rows[0];

  if (!user || !verifyPassword(password, user.passwordHash)) {
    return fail("Incorrect email or password.", 401);
  }

  const token = await createSession(user.id);
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 14,
  });

  return ok({
    user: toPublicUser(user),
    redirectTo: homeFor(user.role),
  });
}
