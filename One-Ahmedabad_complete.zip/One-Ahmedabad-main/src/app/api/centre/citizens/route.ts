import { and, desc, eq, ilike, or } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, hashPassword, isStaff } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { temporaryPassword } from "@/lib/refs";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (!isStaff(user)) return fail("Staff access required.", 403);

  const q = new URL(request.url).searchParams.get("q") ?? "";
  const conditions = [eq(users.role, "citizen")];
  if (q.trim()) {
    const pattern = `%${q.trim()}%`;
    conditions.push(or(ilike(users.name, pattern), ilike(users.email, pattern), ilike(users.phone, pattern))!);
  }

  const rows = await db
    .select({ id: users.id, name: users.name, email: users.email, phone: users.phone, ward: users.ward })
    .from(users)
    .where(and(...conditions))
    .orderBy(desc(users.createdAt))
    .limit(50);
  return ok({ citizens: rows });
}

const citizenSchema = z
  .object({
    name: z.string().trim().min(2, "Enter the citizen's full name.").max(80),
    phone: z.string().trim().max(20).optional().or(z.literal("")),
    email: z.string().trim().toLowerCase().email("Enter a valid email address.").optional().or(z.literal("")),
    ward: z.string().trim().max(60).optional().or(z.literal("")),
    address: z.string().trim().max(240).optional().or(z.literal("")),
  })
  .refine((value) => Boolean(value.phone || value.email), {
    message: "Enter a mobile number or an email address.",
    path: ["phone"],
  });

/**
 * Creates a citizen profile at a service centre. A temporary password is
 * returned once so the operator can hand it over; only its hash is stored.
 */
export async function POST(request: Request) {
  const staff = await getCurrentUser();
  if (!staff) return fail("Please sign in to continue.", 401);
  if (!isStaff(staff)) return fail("Staff access required.", 403);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = citizenSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const { name, phone, email, ward, address } = parsed.data;

  const digits = (phone ?? "").replace(/\D/g, "");
  const loginEmail = email || `${digits}@assisted.one-ahmedabad.invalid`;

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, loginEmail)).limit(1);
  if (existing.length) return fail("A citizen with this email or mobile number already exists.", 409);

  const password = temporaryPassword();
  const [created] = await db
    .insert(users)
    .values({
      name,
      email: loginEmail,
      phone: phone || null,
      ward: ward || null,
      address: address || null,
      passwordHash: hashPassword(password),
      role: "citizen",
    })
    .returning();
  const { id, name: createdName, email: createdEmail, phone: createdPhone, ward: createdWard } = created;

  return ok(
    {
      citizen: { id, name: createdName, email: createdEmail, phone: createdPhone, ward: createdWard },
      temporaryPassword: password,
      message: "Citizen profile created. Share the temporary password in person and ask the citizen to change it.",
    },
    201,
  );
}
