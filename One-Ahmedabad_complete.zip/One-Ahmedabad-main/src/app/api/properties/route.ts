import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { properties } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { currentAssessmentYear, demoAssessment, propertyCode } from "@/lib/tax";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  const rows = await db
    .select()
    .from(properties)
    .where(eq(properties.userId, user.id))
    .orderBy(desc(properties.createdAt));
  return ok({ properties: rows });
}

const propertySchema = z.object({
  ownerName: z.string().trim().min(2, "Enter the owner's name.").max(120),
  address: z.string().trim().min(8, "Enter the full property address.").max(240),
  ward: z.string().trim().max(80).optional().or(z.literal("")),
});

/**
 * Registers a property for the signed-in citizen and attaches an ILLUSTRATIVE
 * assessment. No AMC property-tax record is read or verified.
 */
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "citizen") return fail("Only citizen accounts can add a property.", 403);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = propertySchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const { ownerName, address, ward } = parsed.data;

  let code = propertyCode();
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const clash = await db
      .select({ id: properties.id })
      .from(properties)
      .where(eq(properties.propertyCode, code))
      .limit(1);
    if (!clash.length) break;
    code = propertyCode();
  }

  const inserted = await db
    .insert(properties)
    .values({
      propertyCode: code,
      userId: user.id,
      ownerName,
      address,
      ward: ward || user.ward || null,
      assessmentYear: currentAssessmentYear(),
      assessmentAmount: demoAssessment(address, ward || user.ward || null),
    })
    .returning();

  return ok({ property: inserted[0], message: "Property added with an illustrative assessment." }, 201);
}
