import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { applications, complaints, users } from "@/db/schema";
import { fail, ok, validationError } from "@/lib/api";
import { getStatusMeta } from "@/lib/complaints";
import { applicationStatusDescription, isApplicationStatus } from "@/lib/applications";

const trackSchema = z.object({
  reference: z.string().trim().min(6, "Enter the reference number.").max(40),
  email: z.string().trim().toLowerCase().email("Enter the email used for the complaint."),
});

/**
 * Public tracking: a reference number alone is not enough, the registered
 * email must match as well, so complaint details are never exposed publicly.
 */
export async function POST(request: Request) {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = trackSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);

  const { reference, email } = parsed.data;

  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.reference, reference.toUpperCase()))
    .limit(1);
  const complaint = rows[0];

  // Not a complaint? The same reference box also tracks certificate applications.
  if (!complaint) {
    const appRows = await db
      .select()
      .from(applications)
      .where(eq(applications.reference, reference.toUpperCase()))
      .limit(1);
    const application = appRows[0];
    if (!application) return fail("No request found with that reference number.", 404);

    const appOwner = await db
      .select({ email: users.email })
      .from(users)
      .where(eq(users.id, application.userId))
      .limit(1);
    if (!appOwner[0] || appOwner[0].email.toLowerCase() !== email) {
      return fail("The reference number and email do not match our records.", 404);
    }

    return ok({
      kind: "application",
      complaint: {
        reference: application.reference,
        title: `${application.type} application`,
        serviceName: application.type,
        area: application.applicantName,
        ward: application.ward,
        status: application.status,
        statusDescription: isApplicationStatus(application.status)
          ? applicationStatusDescription[application.status]
          : "",
        createdAt: application.createdAt,
        updatedAt: application.updatedAt,
        resolvedAt: application.decidedAt,
        adminRemark: application.adminRemark,
      },
    });
  }

  const owner = await db.select({ email: users.email }).from(users).where(eq(users.id, complaint.userId)).limit(1);
  if (!owner[0] || owner[0].email.toLowerCase() !== email) {
    return fail("The reference number and email do not match our records.", 404);
  }

  const meta = getStatusMeta(complaint.status);

  return ok({
    kind: "complaint",
    complaint: {
      reference: complaint.reference,
      title: complaint.title,
      serviceName: complaint.serviceName,
      area: complaint.area,
      ward: complaint.ward,
      status: complaint.status,
      statusDescription: meta.description,
      createdAt: complaint.createdAt,
      updatedAt: complaint.updatedAt,
      resolvedAt: complaint.resolvedAt,
      adminRemark: complaint.adminRemark,
    },
  });
}
