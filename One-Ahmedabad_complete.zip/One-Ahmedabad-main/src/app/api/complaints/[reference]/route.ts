import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { complaintEvents, complaints, notifications } from "@/db/schema";
import { getCurrentUser, isStaff } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { COMPLAINT_STATUSES, isComplaintStatus } from "@/lib/complaints";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ reference: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  const { reference } = await params;

  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.reference, reference))
    .limit(1);

  const complaint = rows[0];
  if (!complaint) return fail("No complaint found with that reference.", 404);

  if (!isStaff(user) && complaint.userId !== user.id) {
    return fail("You do not have access to this complaint.", 403);
  }

  const events = await db
    .select()
    .from(complaintEvents)
    .where(eq(complaintEvents.complaintId, complaint.id))
    .orderBy(desc(complaintEvents.createdAt));

  return ok({ complaint, events });
}

const updateSchema = z.object({
  status: z.enum(COMPLAINT_STATUSES),
  remark: z
    .string()
    .trim()
    .max(1000, "Remark is too long.")
    .optional()
    .or(z.literal("")),
  assignedTo: z
    .string()
    .trim()
    .max(120, "Department name is too long.")
    .optional()
    .or(z.literal("")),
});

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ reference: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "admin") return fail("Administrator access required.", 403);

  const { reference } = await params;

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = updateSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  if (!isComplaintStatus(parsed.data.status)) return fail("Unknown status.", 422);

  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.reference, reference))
    .limit(1);
  const complaint = rows[0];
  if (!complaint) return fail("No complaint found with that reference.", 404);

  const { status, remark, assignedTo } = parsed.data;
  const changed = complaint.status !== status;

  const updated = await db
    .update(complaints)
    .set({
      status,
      adminRemark: remark || complaint.adminRemark,
      assignedTo: assignedTo || complaint.assignedTo,
      resolvedAt: status === "Resolved" ? new Date() : complaint.resolvedAt,
      updatedAt: new Date(),
    })
    .where(eq(complaints.id, complaint.id))
    .returning();

  await db.insert(complaintEvents).values({
    complaintId: complaint.id,
    status,
    note: remark || `Status updated to ${status} by the administrator.`,
    actorType: "admin",
    actorName: user.name,
  });

  if (changed) {
    await db.insert(notifications).values({
      userId: complaint.userId,
      title: `Complaint ${complaint.reference} — ${status}`,
      body:
        remark ||
        `The status of “${complaint.title}” moved from ${complaint.status} to ${status}.`,
      type: "status",
      link: `/dashboard/complaints/${complaint.reference}`,
    });
  } else if (remark && remark !== complaint.adminRemark) {
    await db.insert(notifications).values({
      userId: complaint.userId,
      title: `Administrative update on ${complaint.reference}`,
      body: remark,
      type: "status",
      link: `/dashboard/complaints/${complaint.reference}`,
    });
  }

  return ok({
    complaint: updated[0],
    message: changed ? `Status updated to ${status}.` : "Remark saved.",
  });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ reference: string }> },
) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "admin") return fail("Administrator access required.", 403);

  const { reference } = await params;
  await db
    .delete(complaints)
    .where(and(eq(complaints.reference, reference)));
  return ok({ message: "Complaint removed." });
}
