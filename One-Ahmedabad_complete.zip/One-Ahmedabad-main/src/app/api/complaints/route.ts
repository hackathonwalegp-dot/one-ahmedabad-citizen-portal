import { and, desc, eq, ilike, or } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { complaintEvents, complaints, notifications, users } from "@/db/schema";
import { getCurrentUser, isStaff } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { getServiceBySlug } from "@/lib/data";
import { generateReference } from "@/lib/seed";
import { saveUpload } from "@/lib/storage";

const complaintSchema = z.object({
  category: z.string().trim().min(3, "Select a complaint category."),
  title: z
    .string()
    .trim()
    .min(8, "Give the complaint a clear title (at least 8 characters).")
    .max(120, "Title is too long."),
  description: z
    .string()
    .trim()
    .min(25, "Describe the issue in at least 25 characters.")
    .max(2000, "Description is too long."),
  area: z.string().trim().min(3, "Enter the area, street or society.").max(160),
  ward: z.string().trim().max(80).optional().or(z.literal("")),
  landmark: z.string().trim().max(160).optional().or(z.literal("")),
  contactPhone: z
    .string()
    .trim()
    .max(20, "Phone number is too long.")
    .optional()
    .or(z.literal("")),
});

export async function POST(request: Request) {
  const actor = await getCurrentUser();
  if (!actor) return fail("Please sign in to submit a complaint.", 401);

  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return fail("Invalid form submission.", 400);
  }

  // Staff can file on behalf of a citizen; citizens always file for themselves.
  const citizenIdRaw = Number(formData.get("citizenId") ?? 0);
  let user = actor;
  let filedByName: string | null = null;
  if (citizenIdRaw) {
    if (!isStaff(actor)) return fail("Only service-centre staff can file on behalf of a citizen.", 403);
    const target = await db.select().from(users).where(eq(users.id, citizenIdRaw)).limit(1);
    if (!target[0] || target[0].role !== "citizen") return fail("Citizen account not found.", 404);
    user = target[0];
    filedByName = actor.name;
  } else if (actor.role !== "citizen") {
    return fail("Choose a citizen account to file this complaint for.", 422);
  }

  const parsed = complaintSchema.safeParse({
    category: formData.get("category") ?? "",
    title: formData.get("title") ?? "",
    description: formData.get("description") ?? "",
    area: formData.get("area") ?? "",
    ward: formData.get("ward") ?? "",
    landmark: formData.get("landmark") ?? "",
    contactPhone: formData.get("contactPhone") ?? "",
  });
  if (!parsed.success) return validationError(parsed.error);

  const data = parsed.data;
  const service = await getServiceBySlug(data.category);
  if (!service) return fail("That complaint category is not available.", 422);

  let photoUrl: string | null = null;
  const file = formData.get("photo");
  if (file instanceof File && file.size > 0) {
    const upload = await saveUpload(file);
    if (!upload.ok) return fail(upload.error, 422);
    photoUrl = `/api/files?key=${encodeURIComponent(upload.key)}`;
  }

  const reference = await generateReference();

  const inserted = await db
    .insert(complaints)
    .values({
      reference,
      userId: user.id,
      serviceSlug: service.slug,
      serviceName: service.name,
      title: data.title,
      description: data.description,
      area: data.area,
      ward: data.ward || null,
      landmark: data.landmark || null,
      contactPhone: data.contactPhone || user.phone || null,
      photoUrl,
      filedByName,
      status: "Submitted",
    })
    .returning();

  const complaint = inserted[0];

  await db.insert(complaintEvents).values({
    complaintId: complaint.id,
    status: "Submitted",
    note: filedByName
      ? `Complaint filed at a service centre by ${filedByName} and sent to the ward queue.`
      : "Complaint registered by the citizen and sent to the ward queue.",
    actorType: filedByName ? "operator" : "citizen",
    actorName: actor.name,
  });

  await db.insert(notifications).values({
    userId: user.id,
    title: "Complaint submitted successfully",
    body: `Your complaint “${complaint.title}” was registered with reference ${complaint.reference}. You will be notified at every status change.`,
    type: "complaint",
    link: `/dashboard/complaints/${complaint.reference}`,
  });

  return ok(
    {
      complaint,
      reference: complaint.reference,
      message: "Complaint registered successfully.",
    },
    201,
  );
}

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status") ?? "";
  const category = searchParams.get("category") ?? "";
  const q = searchParams.get("q") ?? "";

  const conditions = [];
  if (!isStaff(user)) conditions.push(eq(complaints.userId, user.id));
  if (status && status !== "all") conditions.push(eq(complaints.status, status));
  if (category && category !== "all") conditions.push(eq(complaints.serviceSlug, category));
  if (q.trim()) {
    const pattern = `%${q.trim()}%`;
    conditions.push(
      or(
        ilike(complaints.reference, pattern),
        ilike(complaints.title, pattern),
        ilike(complaints.area, pattern),
      )!,
    );
  }

  const rows = await db
    .select()
    .from(complaints)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(complaints.createdAt));

  return ok({ complaints: rows });
}
