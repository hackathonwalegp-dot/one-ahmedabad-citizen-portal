import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, hashPassword, toPublicUser, verifyPassword } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";

const profileSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name.").max(80).optional(),
  phone: z.string().trim().max(20).optional().or(z.literal("")),
  ward: z.string().trim().max(60).optional().or(z.literal("")),
  address: z.string().trim().max(240).optional().or(z.literal("")),
  currentPassword: z.string().optional().or(z.literal("")),
  newPassword: z
    .string()
    .min(8, "New password must be at least 8 characters.")
    .max(120)
    .regex(/[A-Za-z]/, "Password must contain at least one letter.")
    .regex(/[0-9]/, "Password must contain at least one number.")
    .optional()
    .or(z.literal("")),
});

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }

  const parsed = profileSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const data = parsed.data;

  const update: Partial<typeof users.$inferInsert> = {};
  if (data.name !== undefined) update.name = data.name;
  if (data.phone !== undefined) update.phone = data.phone || null;
  if (data.ward !== undefined) update.ward = data.ward || null;
  if (data.address !== undefined) update.address = data.address || null;

  if (data.newPassword) {
    if (!data.currentPassword) {
      return fail("Enter your current password to set a new one.", 422);
    }
    if (!verifyPassword(data.currentPassword, user.passwordHash)) {
      return fail("Your current password is incorrect.", 401);
    }
    update.passwordHash = hashPassword(data.newPassword);
  }

  if (!Object.keys(update).length) {
    return fail("Nothing to update.");
  }

  const updated = await db
    .update(users)
    .set(update)
    .where(eq(users.id, user.id))
    .returning();

  return ok({ user: toPublicUser(updated[0]), message: "Profile updated." });
}
