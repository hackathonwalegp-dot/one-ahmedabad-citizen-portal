import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, hashPassword } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";

const operatorSchema = z.object({
  name: z.string().trim().min(2, "Enter the operator's name.").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  phone: z.string().trim().max(20).optional().or(z.literal("")),
  ward: z.string().trim().max(60).optional().or(z.literal("")),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters.")
    .max(120)
    .regex(/[A-Za-z]/, "Password must contain at least one letter.")
    .regex(/[0-9]/, "Password must contain at least one number."),
});

/** Administrators provision service-centre operator accounts. */
export async function POST(request: Request) {
  const admin = await getCurrentUser();
  if (!admin) return fail("Please sign in to continue.", 401);
  if (admin.role !== "admin") return fail("Administrator access required.", 403);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = operatorSchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const { name, email, phone, ward, password } = parsed.data;

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return fail("An account with this email already exists.", 409);

  const [created] = await db
    .insert(users)
    .values({
      name,
      email,
      phone: phone || null,
      ward: ward || null,
      passwordHash: hashPassword(password),
      role: "operator",
    })
    .returning();

  const operator = { id: created.id, name: created.name, email: created.email };
  return ok({ operator, message: "Service-centre operator account created." }, 201);
}
