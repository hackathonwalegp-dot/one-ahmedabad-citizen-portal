import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { payments, properties, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { fail, ok, validationError } from "@/lib/api";
import { getPropertySummaries } from "@/lib/data";
import { notifyUser } from "@/lib/notify";
import { uniqueReference } from "@/lib/refs";
import { formatRupees, PAYMENT_METHODS } from "@/lib/money";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);

  const base = db
    .select({ payment: payments, property: properties, payer: users.name })
    .from(payments)
    .innerJoin(properties, eq(properties.id, payments.propertyId))
    .innerJoin(users, eq(users.id, payments.userId));

  const rows = await (user.role === "admin"
    ? base.orderBy(desc(payments.paidAt))
    : base.where(eq(payments.userId, user.id)).orderBy(desc(payments.paidAt)));

  return ok({ payments: rows });
}

const paySchema = z.object({
  propertyId: z.coerce.number().int().positive("Select a property."),
  amount: z.coerce.number().int("Enter a whole-rupee amount.").positive("Enter an amount above zero."),
  method: z.enum(PAYMENT_METHODS),
});

/** Simulated payment: records a receipt only. No money is moved. */
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return fail("Please sign in to continue.", 401);
  if (user.role !== "citizen") return fail("Only citizen accounts can make a demo payment.", 403);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return fail("Invalid request body.", 400);
  }
  const parsed = paySchema.safeParse(payload);
  if (!parsed.success) return validationError(parsed.error);
  const { propertyId, amount, method } = parsed.data;

  const summaries = await getPropertySummaries(user.id);
  const property = summaries.find((item) => item.id === propertyId);
  if (!property) return fail("Property not found.", 404);
  if (property.outstanding <= 0) return fail("This property has no outstanding balance.", 422);
  if (amount > property.outstanding) {
    return fail(`The amount cannot exceed the outstanding balance of ${formatRupees(property.outstanding)}.`, 422);
  }

  const receiptNo = await uniqueReference("RCPT", async (candidate) => {
    const rows = await db
      .select({ id: payments.id })
      .from(payments)
      .where(eq(payments.receiptNo, candidate))
      .limit(1);
    return rows.length > 0;
  });

  const inserted = await db
    .insert(payments)
    .values({ receiptNo, userId: user.id, propertyId, amount, method, status: "Success" })
    .returning();

  await notifyUser(user.id, {
    title: "Demo payment recorded",
    body: `${formatRupees(amount)} was recorded against ${property.propertyCode} (receipt ${receiptNo}). No real money was transferred.`,
    type: "payment",
    link: `/dashboard/payments/${receiptNo}`,
  });

  return ok({ payment: inserted[0], receiptNo, message: "Demo payment recorded." }, 201);
}
