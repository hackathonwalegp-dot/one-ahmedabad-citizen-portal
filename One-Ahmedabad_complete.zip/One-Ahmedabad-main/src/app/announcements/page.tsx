import type { Metadata } from "next";
import Link from "next/link";
import { CalendarDays, Megaphone, ShieldCheck } from "lucide-react";
import { getPublishedAnnouncements } from "@/lib/data";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Announcements",
  description:
    "Latest civic announcements published by the One Ahmedabad administrator for residents of Ahmedabad.",
};

export const dynamic = "force-dynamic";

export default async function AnnouncementsPage() {
  const announcements = await getPublishedAnnouncements();

  return (
    <div className="bg-ink-50/40">
      <section className="border-b border-ink-100 bg-white">
        <div className="container-page py-10 lg:py-14">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand-600">
            Civic updates
          </p>
          <h1 className="mt-2 text-[clamp(1.9rem,3.6vw,2.6rem)] font-bold tracking-tight">
            Announcements
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-500">
            Notices published from the administrator console. Signed-in citizens also receive these
            as in-app notifications.
          </p>
        </div>
      </section>

      <div className="container-page py-8 lg:py-10">
        {announcements.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-ink-200 bg-white px-6 py-16 text-center">
            <Megaphone className="mx-auto h-7 w-7 text-ink-300" />
            <p className="mt-3 text-sm font-semibold text-ink-900">No announcements yet</p>
            <p className="mt-1.5 text-xs text-ink-500">
              Published notices from the admin console will appear here.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {announcements.map((item) => (
              <article
                key={item.id}
                className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft transition hover:border-brand-200 hover:shadow-card"
              >
                <div className="flex flex-wrap items-center gap-3">
                  <span className="rounded-full bg-brand-50 px-2.5 py-1 text-[11px] font-semibold text-brand-700 ring-1 ring-brand-100">
                    {item.category}
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-ink-400">
                    <CalendarDays className="h-3.5 w-3.5" />
                    {formatDate(item.publishedAt)}
                  </span>
                </div>
                <h2 className="mt-3 text-base font-bold leading-snug text-ink-900">{item.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-ink-600">{item.body}</p>
                {item.createdBy && (
                  <p className="mt-4 border-t border-ink-100 pt-3 text-[11px] text-ink-400">
                    Published by {item.createdBy}
                  </p>
                )}
              </article>
            ))}
          </div>
        )}

        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
          <div className="flex items-start gap-3">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
            <p className="max-w-xl text-xs leading-relaxed text-ink-500">
              Announcements on this page are published by the demo administrator to demonstrate the
              notification workflow. They are not official AMC circulars.
            </p>
          </div>
          <Link
            href="/dashboard/notifications"
            className="rounded-xl border border-ink-200 px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
          >
            Open my notifications
          </Link>
        </div>
      </div>
    </div>
  );
}
