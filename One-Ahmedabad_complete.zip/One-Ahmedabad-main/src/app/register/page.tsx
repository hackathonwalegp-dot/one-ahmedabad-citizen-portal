import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth/auth-forms";
import { getCurrentUser, homeFor } from "@/lib/auth";
import { ensureSeedData } from "@/lib/seed";

export const metadata: Metadata = {
  title: "Create a citizen account",
  description:
    "Register for a One Ahmedabad citizen account to raise complaints, track status and receive notifications.",
};

export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  await ensureSeedData();
  const user = await getCurrentUser();
  if (user) redirect(homeFor(user.role));

  return (
    <div className="container-page py-14 lg:py-20">
      <AuthForm mode="register" />
    </div>
  );
}
