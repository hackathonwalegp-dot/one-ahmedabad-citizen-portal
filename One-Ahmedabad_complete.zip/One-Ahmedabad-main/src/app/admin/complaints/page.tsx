import type { Metadata } from "next";
import { AdminComplaintList } from "@/components/admin/admin-complaint-list";
import { getServices } from "@/lib/data";

export const metadata: Metadata = { title: "Complaint queue" };
export const dynamic = "force-dynamic";

export default async function AdminComplaintsPage() {
  const services = await getServices();

  return (
    <div>
      <div className="mb-7">
        <h1 className="text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
          Complaint queue
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Every complaint raised by citizens. Search by reference, area or ward, filter by status or
          service, then open a complaint to update its status and add a remark.
        </p>
      </div>

      <AdminComplaintList
        categories={services.map((service) => ({ slug: service.slug, name: service.name }))}
      />
    </div>
  );
}
