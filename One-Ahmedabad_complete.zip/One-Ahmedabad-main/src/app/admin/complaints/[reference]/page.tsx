import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import {
  ArrowLeft,
  CalendarDays,
  Camera,
  Clock3,
  Mail,
  MapPin,
  MessageSquare,
  Phone,
  User,
} from "lucide-react";
import { ComplaintAdminPanel } from "@/components/admin/complaint-admin-panel";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { complaintEvents, complaints, users } from "@/db/schema";
import { statusMeta, type ComplaintStatus } from "@/lib/complaints";
import { formatDate, formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Manage complaint" };
export const dynamic = "force-dynamic";

export default async function AdminComplaintDetailPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const { reference } = await params;
  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.reference, reference))
    .limit(1);
  const complaint = rows[0];
  if (!complaint) notFound();

  const [events, citizen] = await Promise.all([
    db
      .select()
      .from(complaintEvents)
      .where(eq(complaintEvents.complaintId, complaint.id))
      .orderBy(desc(complaintEvents.createdAt)),
    db.select().from(users).where(eq(users.id, complaint.userId)).limit(1),
  ]);

  const meta = statusMeta[complaint.status as ComplaintStatus] ?? statusMeta.Submitted;

  return (
    <div>
      <Link
        href="/admin/complaints"
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-brand-700"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to the complaint queue
      </Link>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">
                  {complaint.reference}
                </p>
                <h1 className="mt-1.5 text-xl font-bold tracking-tight text-ink-900 sm:text-2xl">
                  {complaint.title}
                </h1>
                <p className="mt-1.5 text-sm text-ink-500">
                  {complaint.serviceName} · raised {formatDate(complaint.createdAt)}
                </p>
              </div>
              <StatusBadge status={complaint.status} className="px-3 py-1.5 text-sm" />
            </div>

            <p className="mt-4 rounded-xl bg-ink-50 px-4 py-3 text-xs leading-relaxed text-ink-600">
              {meta.description}
            </p>

            <h2 className="mt-6 text-sm font-bold text-ink-900">Citizen description</h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-ink-700">
              {complaint.description}
            </p>

            {complaint.photoUrl && (
              <div className="mt-5">
                <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-ink-400">
                  <Camera className="h-3.5 w-3.5" /> Attached photograph
                </p>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={complaint.photoUrl}
                  alt={`Photograph attached to complaint ${complaint.reference}`}
                  className="mt-2 max-h-96 w-full rounded-2xl border border-ink-100 object-cover"
                />
              </div>
            )}

            <dl className="mt-6 grid gap-3 sm:grid-cols-3">
              {[
                { icon: MapPin, label: "Area", value: complaint.area },
                { icon: MapPin, label: "Ward", value: complaint.ward ?? "Not specified" },
                { icon: MapPin, label: "Landmark", value: complaint.landmark ?? "Not specified" },
                { icon: Phone, label: "Contact", value: complaint.contactPhone ?? "Not provided" },
                { icon: Clock3, label: "Raised", value: formatDateTime(complaint.createdAt) },
                { icon: Clock3, label: "Updated", value: formatDateTime(complaint.updatedAt) },
              ].map((row) => (
                <div key={row.label} className="rounded-xl border border-ink-100 px-4 py-3">
                  <dt className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-ink-400">
                    <row.icon className="h-3 w-3" />
                    {row.label}
                  </dt>
                  <dd className="mt-1 text-xs font-semibold text-ink-800">{row.value}</dd>
                </div>
              ))}
            </dl>
          </section>

          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <Clock3 className="h-4.5 w-4.5 text-brand-600" />
              Complaint history
            </h2>
            <ol className="mt-5 space-y-5">
              {events.map((event, index) => {
                const eventMeta = statusMeta[event.status as ComplaintStatus] ?? statusMeta.Submitted;
                return (
                  <li key={event.id} className="relative flex gap-4 pl-1">
                    {index < events.length - 1 && (
                      <span className="absolute left-[13px] top-7 h-full w-px bg-ink-100" />
                    )}
                    <span
                      className={`relative z-10 mt-1 h-3 w-3 shrink-0 rounded-full ring-4 ring-white ${eventMeta.dot}`}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-bold text-ink-900">{eventMeta.label}</p>
                        <span className="text-[11px] text-ink-400">{formatDateTime(event.createdAt)}</span>
                        <span className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-ink-500">
                          {event.actorType === "admin"
                              ? "Administrator"
                              : event.actorType === "citizen"
                                ? "Citizen"
                                : event.actorType === "operator"
                                  ? "Service centre"
                                  : "System"}
                        </span>
                      </div>
                      {event.note && (
                        <p className="mt-1.5 text-sm leading-relaxed text-ink-600">{event.note}</p>
                      )}
                      {event.actorName && (
                        <p className="mt-1 text-[11px] text-ink-400">by {event.actorName}</p>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          </section>
        </div>

        <aside className="space-y-4">
          <ComplaintAdminPanel
            reference={complaint.reference}
            currentStatus={complaint.status}
            currentRemark={complaint.adminRemark}
            currentAssignee={complaint.assignedTo}
          />

          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
              <User className="h-4 w-4 text-brand-600" /> Citizen
            </h2>
            {citizen[0] ? (
              <dl className="mt-3 space-y-3 text-sm">
                <div className="flex items-center justify-between gap-3">
                  <dt className="text-xs text-ink-400">Name</dt>
                  <dd className="text-xs font-semibold text-ink-800">{citizen[0].name}</dd>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <dt className="flex items-center gap-1 text-xs text-ink-400">
                    <Mail className="h-3 w-3" /> Email
                  </dt>
                  <dd className="truncate text-xs font-semibold text-ink-800">
                    {citizen[0].email}
                  </dd>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <dt className="flex items-center gap-1 text-xs text-ink-400">
                    <Phone className="h-3 w-3" /> Phone
                  </dt>
                  <dd className="text-xs font-semibold text-ink-800">
                    {citizen[0].phone ?? "Not provided"}
                  </dd>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <dt className="flex items-center gap-1 text-xs text-ink-400">
                    <CalendarDays className="h-3 w-3" /> Member since
                  </dt>
                  <dd className="text-xs font-semibold text-ink-800">
                    {formatDate(citizen[0].createdAt)}
                  </dd>
                </div>
              </dl>
            ) : (
              <p className="mt-3 text-xs text-ink-500">Citizen record unavailable.</p>
            )}
          </div>

          {complaint.adminRemark && (
            <div className="rounded-2xl border border-brand-100 bg-brand-50/60 p-5">
              <h2 className="flex items-center gap-2 text-sm font-bold text-brand-900">
                <MessageSquare className="h-4 w-4" /> Current remark
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{complaint.adminRemark}</p>
            </div>
          )}

          <Link
            href={`/dashboard/complaints/${complaint.reference}`}
            className="block rounded-2xl border border-ink-100 bg-white p-4 text-center text-xs font-semibold text-ink-600 shadow-soft transition hover:border-brand-300 hover:text-brand-700"
          >
            Open the citizen-facing tracking view
          </Link>
        </aside>
      </div>
    </div>
  );
}
