import type { Metadata } from "next";
import { Building2 } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { getDepartmentWorkload } from "@/lib/data";
import { DEPARTMENTS } from "@/lib/departments";

export const metadata: Metadata = { title: "Department overview" };
export const dynamic = "force-dynamic";

export default async function AdminDepartmentsPage() {
  const workload = await getDepartmentWorkload();
  const rows = new Map(workload.map((item) => [item.department, item]));
  const names: string[] = [...DEPARTMENTS];
  for (const item of workload) if (!names.includes(item.department)) names.push(item.department);

  return (
    <div>
      <PageHeader
        eyebrow="ADMINISTRATION"
        title="Department overview"
        description="Open and closed work per department across complaints and applications. Assign work from the complaint or application screens."
      />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {names.map((name) => {
          const row = rows.get(name) ?? { department: name, open: 0, closed: 0 };
          const total = row.open + row.closed;
          const share = total ? (row.closed / total) * 100 : 0;
          return (
            <section key={name} className="rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-5 shadow-soft">
              <h2 className="flex items-start gap-2.5 text-sm font-bold text-ink-900">
                <span className="grid h-8 w-8 shrink-0 place-items-center bg-brand-50 text-brand-700"><Building2 className="h-4 w-4" /></span>
                <span className="pt-1">{name}</span>
              </h2>
              <dl className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-ink-50 py-2.5"><dt className="text-[10px] font-semibold uppercase tracking-wide text-ink-400">Open</dt><dd className="mt-0.5 text-lg font-bold tabular-nums text-amber-700">{row.open}</dd></div>
                <div className="rounded-xl bg-ink-50 py-2.5"><dt className="text-[10px] font-semibold uppercase tracking-wide text-ink-400">Closed</dt><dd className="mt-0.5 text-lg font-bold tabular-nums text-emerald-700">{row.closed}</dd></div>
                <div className="rounded-xl bg-ink-50 py-2.5"><dt className="text-[10px] font-semibold uppercase tracking-wide text-ink-400">Total</dt><dd className="mt-0.5 text-lg font-bold tabular-nums text-ink-900">{total}</dd></div>
              </dl>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-ink-100"><div className="h-full rounded-full bg-emerald-500" style={{ width: `${share}%` }} /></div>
              <p className="mt-1.5 text-[11px] text-ink-500">{total ? `${Math.round(share)}% closed` : "No work assigned yet"}</p>
            </section>
          );
        })}
        {rows.has("Unassigned") && (
          <section className="rounded-2xl border border-dashed border-ink-300 bg-white p-5">
            <h2 className="text-sm font-bold text-ink-900">Unassigned</h2>
            <p className="mt-2 text-xs text-ink-500">{rows.get("Unassigned")!.open} open and {rows.get("Unassigned")!.closed} closed items have no department yet.</p>
          </section>
        )}
      </div>
    </div>
  );
}
