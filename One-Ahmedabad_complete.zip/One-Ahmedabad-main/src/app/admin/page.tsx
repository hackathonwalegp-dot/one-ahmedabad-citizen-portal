import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import {
  ArrowRight,
  CheckCircle2,
  ClipboardList,
  Clock3,
  Gauge,
  FileText,
  Inbox,
  LifeBuoy,
  Megaphone,
  WalletCards,
  TriangleAlert,
  Users,
} from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { complaints } from "@/db/schema";
import { StatCard } from "@/components/ui/stat-card";
import { getAdminStats, getPlatformStats } from "@/lib/data";
import { formatRupees } from "@/lib/money";
import { COMPLAINT_STATUSES, statusMeta, type ComplaintStatus } from "@/lib/complaints";
import { formatDateTime, timeAgo } from "@/lib/utils";

export const metadata: Metadata = { title: "Admin console" };
export const dynamic = "force-dynamic";

export default async function AdminOverviewPage() {
  const [stats, platform] = await Promise.all([getAdminStats(), getPlatformStats()]);
  const recent = await db.select().from(complaints).orderBy(desc(complaints.createdAt)).limit(6);

  const total = Math.max(stats.total, 1);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
            Administrator overview
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
            Monitor every complaint submitted by citizens, keep the service directory accurate and
            publish announcements to the community.
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <Link
            href="/admin/complaints"
            className="inline-flex items-center gap-2 rounded-xl bg-ink-950 px-4 py-2.5 text-sm font-semibold text-white shadow-soft transition hover:bg-ink-800"
          >
            <ClipboardList className="h-4 w-4" />
            Manage complaints
          </Link>
          <Link
            href="/admin/announcements"
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700"
          >
            <Megaphone className="h-4 w-4" />
            Publish announcement
          </Link>
        </div>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Platform activity">
        <StatCard label="Applications pending" value={platform.applicationPending} note={`${platform.applicationTotal} received in total`} icon={<FileText className="h-[18px] w-[18px]" />} tone="orange" />
        <StatCard label="Demo payments" value={formatRupees(platform.paymentTotal)} note={`${platform.paymentCount} simulated transactions`} icon={<WalletCards className="h-[18px] w-[18px]" />} tone="green" />
        <StatCard label="Open support requests" value={platform.ticketsOpen} note={`${platform.ticketTotal} in total`} icon={<LifeBuoy className="h-[18px] w-[18px]" />} tone="amber" />
        <StatCard label="Citizens / centre staff" value={`${platform.citizens} / ${platform.operators}`} note="Registered accounts" icon={<Users className="h-[18px] w-[18px]" />} tone="navy" />
      </section>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            label: "Total complaints",
            value: stats.total,
            icon: ClipboardList,
            tone: "bg-brand-50 text-brand-700",
            hint: "All complaints received",
          },
          {
            label: "Open / in progress",
            value: stats.open,
            icon: Clock3,
            tone: "bg-amber-50 text-amber-700",
            hint: "Awaiting resolution",
          },
          {
            label: "Resolved",
            value: stats.resolved,
            icon: CheckCircle2,
            tone: "bg-emerald-50 text-emerald-700",
            hint: "Closed as completed",
          },
          {
            label: "Registered citizens",
            value: stats.citizens,
            icon: Users,
            tone: "bg-brand-50 text-brand-700",
            hint: "Accounts on the platform",
          },
        ].map((card) => (
          <div
            key={card.label}
            className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft"
          >
            <div className="flex items-start justify-between">
              <span className={`grid h-10 w-10 place-items-center rounded-xl ${card.tone}`}>
                <card.icon className="h-5 w-5" />
              </span>
              <span className="text-[11px] text-ink-400">{card.hint}</span>
            </div>
            <p className="mt-4 text-3xl font-bold text-ink-900">{card.value}</p>
            <p className="mt-1 text-xs font-medium text-ink-500">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        {/* Status breakdown */}
        <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <Gauge className="h-4.5 w-4.5 text-brand-600" />
              Complaints by status
            </h2>
            <span className="text-xs text-ink-400">{stats.total} total</span>
          </div>

          <div className="mt-5 flex h-3 overflow-hidden rounded-full bg-ink-100">
            {COMPLAINT_STATUSES.map((status) => {
              const value = stats.byStatus[status] ?? 0;
              if (!value) return null;
              return (
                <span
                  key={status}
                  className={statusMeta[status].bar}
                  style={{ width: `${(value / total) * 100}%` }}
                  title={`${status}: ${value}`}
                />
              );
            })}
          </div>

          <ul className="mt-5 grid gap-2.5 sm:grid-cols-2">
            {COMPLAINT_STATUSES.map((status) => {
              const value = stats.byStatus[status] ?? 0;
              const meta = statusMeta[status as ComplaintStatus];
              return (
                <li
                  key={status}
                  className="flex items-center justify-between gap-3 rounded-xl border border-ink-100 px-3.5 py-2.5"
                >
                  <span className="flex items-center gap-2 text-xs font-semibold text-ink-700">
                    <span className={`h-2 w-2 rounded-full ${meta.dot}`} />
                    {meta.label}
                  </span>
                  <span className="text-xs font-bold text-ink-900">{value}</span>
                </li>
              );
            })}
          </ul>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-ink-50 px-4 py-3">
              <p className="text-[11px] font-medium uppercase tracking-wide text-ink-400">
                Services listed
              </p>
              <p className="mt-1 text-lg font-bold text-ink-900">{stats.services}</p>
            </div>
            <div className="rounded-xl bg-ink-50 px-4 py-3">
              <p className="text-[11px] font-medium uppercase tracking-wide text-ink-400">
                Announcements
              </p>
              <p className="mt-1 text-lg font-bold text-ink-900">{stats.announcements}</p>
            </div>
            <div className="rounded-xl bg-ink-50 px-4 py-3">
              <p className="text-[11px] font-medium uppercase tracking-wide text-ink-400">
                Rejected
              </p>
              <p className="mt-1 text-lg font-bold text-ink-900">{stats.rejected}</p>
            </div>
          </div>
        </section>

        {/* Recent complaints */}
        <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <Inbox className="h-4.5 w-4.5 text-brand-600" />
              Latest complaints
            </h2>
            <Link
              href="/admin/complaints"
              className="text-xs font-semibold text-brand-700 hover:text-brand-800"
            >
              View all
            </Link>
          </div>

          {recent.length === 0 ? (
            <p className="mt-4 rounded-xl border border-dashed border-ink-200 bg-ink-50/60 px-4 py-8 text-center text-xs text-ink-500">
              No complaints have been submitted yet.
            </p>
          ) : (
            <ul className="mt-4 space-y-3">
              {recent.map((complaint) => (
                <li key={complaint.id}>
                  <Link
                    href={`/admin/complaints/${complaint.reference}`}
                    className="group block rounded-xl border border-ink-100 p-3.5 transition hover:border-brand-200 hover:bg-brand-50/30"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-ink-900">
                          {complaint.title}
                        </p>
                        <p className="mt-1 font-mono text-[11px] text-brand-700">
                          {complaint.reference}
                        </p>
                      </div>
                      <StatusBadge status={complaint.status} />
                    </div>
                    <p className="mt-2 flex flex-wrap items-center gap-x-2 text-[11px] text-ink-500">
                      <span>{complaint.serviceName}</span>
                      <span className="text-ink-200">•</span>
                      <span>{complaint.area}</span>
                      <span className="text-ink-200">•</span>
                      <span>{timeAgo(complaint.createdAt)}</span>
                    </p>
                  </Link>
                </li>
              ))}
            </ul>
          )}

          <Link
            href="/admin/complaints"
            className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 hover:text-brand-800"
          >
            Open the complaint queue <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </section>
      </div>

      <section className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
        <h2 className="flex items-center gap-2 text-sm font-bold text-amber-900">
          <TriangleAlert className="h-4 w-4" />
          Prototype administration notice
        </h2>
        <p className="mt-2 text-xs leading-relaxed text-amber-900/80">
          Every action in this console changes the demo database only. Status updates and remarks are
          delivered to the citizen dashboard and in-app notifications so the full workflow can be
          demonstrated end-to-end. No AMC system, official register or payment gateway is involved.
        </p>
      </section>
    </div>
  );
}
