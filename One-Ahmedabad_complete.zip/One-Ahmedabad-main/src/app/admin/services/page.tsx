import type { Metadata } from "next";
import { Info } from "lucide-react";
import { ServiceManager } from "@/components/admin/service-manager";
import { getServices } from "@/lib/data";

export const metadata: Metadata = { title: "Manage service information" };
export const dynamic = "force-dynamic";

export default async function AdminServicesPage() {
  const services = await getServices();

  return (
    <div>
      <div className="mb-7">
        <h1 className="text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
          Service information
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Keep the service directory accurate — update summaries, procedures, requirements, the
          responsible office and the official portal link. Changes appear immediately on the public
          pages and in the AI assistant.
        </p>
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-ink-50 px-3 py-1.5 text-[11px] font-medium text-ink-500">
          <Info className="h-3.5 w-3.5 text-brand-600" />
          Do not publish fees, processing timelines or eligibility rules that AMC has not notified.
        </p>
      </div>

      <ServiceManager
        services={services.map((service) => ({
          slug: service.slug,
          name: service.name,
          categorySlug: service.categorySlug,
          categoryName: service.categoryName,
          categoryIcon: service.categoryIcon,
          accent: service.accent,
          summary: service.summary,
          description: service.description,
          requirements: service.requirements,
          procedure: service.procedure,
          documents: service.documents,
          office: service.office,
          disclaimer: service.disclaimer,
          officialPortalUrl: service.officialPortalUrl,
          handlingMode: service.handlingMode,
          isActive: service.isActive,
        }))}
      />
    </div>
  );
}
