import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { BarChart3, ShieldCheck } from "lucide-react";
import { SideNav, type SideNavItem } from "@/components/site/side-nav";
import { T } from "@/components/site/t";
import { getCurrentUser, toPublicUser } from "@/lib/auth";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

const ITEMS: SideNavItem[] = [
  { href: "/admin", labelKey: "nav.overview", icon: "overview", exact: true },
  { href: "/admin/complaints", labelKey: "nav.adminComplaints", icon: "complaints" },
  { href: "/admin/applications", labelKey: "nav.adminApplications", icon: "applications" },
  { href: "/admin/payments", labelKey: "nav.adminPayments", icon: "payments" },
  { href: "/admin/citizens", labelKey: "nav.adminCitizens", icon: "citizens" },
  { href: "/admin/departments", labelKey: "nav.adminDepartments", icon: "departments" },
  { href: "/admin/reports", labelKey: "nav.adminReports", icon: "reports" },
  { href: "/admin/support", labelKey: "nav.adminSupport", icon: "support" },
  { href: "/admin/services", labelKey: "nav.adminServices", icon: "services" },
  { href: "/admin/announcements", labelKey: "nav.adminAnnouncements", icon: "announcements" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  await ensureSeedData();
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role === "operator") redirect("/centre");
  if (user.role !== "admin") redirect("/dashboard");

  const publicUser = toPublicUser(user);

  return (
    <div className="bg-ink-50/50">
      <div className="container-page flex gap-8 py-6 lg:py-10">
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-40 space-y-6">
            <div className="rounded-2xl border-t-[3px] border-t-orange-500 bg-ink-950 p-5 text-white shadow-lift">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-orange-200">
                <ShieldCheck className="h-3 w-3" /> <T k="side.adminConsole" />
              </span>
              <p className="mt-3 truncate text-sm font-bold">{publicUser.name}</p>
              <p className="truncate text-xs text-ink-400">{publicUser.email}</p>
              <p className="mt-3 text-[11px] leading-relaxed text-ink-400">
                Prototype administration. Sample data only, no AMC system is connected.
              </p>
            </div>

            <SideNav items={ITEMS} variant="sidebar" />

            <Link
              href="/dashboard"
              className="flex items-center gap-3 rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-orange-300 hover:text-orange-700"
            >
              <BarChart3 className="h-[18px] w-[18px] text-ink-400" />
              <T k="side.citizenDashboard" />
            </Link>
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <div className="-mx-5 mb-5 overflow-x-auto px-5 scroll-slim lg:hidden">
            <SideNav items={ITEMS} variant="pills" />
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
