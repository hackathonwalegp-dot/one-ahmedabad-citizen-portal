import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { CreditCard, ShieldAlert } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatCard } from "@/components/ui/stat-card";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { payments, properties, users } from "@/db/schema";
import { formatRupees } from "@/lib/money";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Demo transactions" };
export const dynamic = "force-dynamic";

export default async function AdminPaymentsPage() {
  const rows = await db
    .select({ payment: payments, property: properties, payer: users.name, payerEmail: users.email })
    .from(payments)
    .innerJoin(properties, eq(properties.id, payments.propertyId))
    .innerJoin(users, eq(users.id, payments.userId))
    .orderBy(desc(payments.paidAt))
    .limit(300);

  const total = rows.reduce((sum, row) => sum + row.payment.amount, 0);

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="ADMINISTRATION" title="Demo transactions" description="Every simulated property-tax payment recorded in the prototype." />

      <div className="flex items-start gap-3 rounded-2xl border border-orange-100 bg-orange-50/70 p-4 text-xs leading-relaxed text-orange-950">
        <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-orange-700" />
        <p>These records are simulated. No payment gateway is connected and no funds were collected.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Simulated amount" value={formatRupees(total)} icon={<CreditCard className="h-[18px] w-[18px]" />} tone="green" />
        <StatCard label="Transactions" value={rows.length} icon={<CreditCard className="h-[18px] w-[18px]" />} tone="navy" />
        <StatCard label="Average" value={formatRupees(rows.length ? Math.round(total / rows.length) : 0)} icon={<CreditCard className="h-[18px] w-[18px]" />} tone="orange" />
      </div>

      {rows.length === 0 ? (
        <EmptyState title="No demo payments yet" />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-ink-100 bg-white shadow-soft">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50/60 text-[11px] uppercase tracking-wide text-ink-400">
                <th className="px-5 py-3 font-semibold">Receipt</th>
                <th className="px-3 py-3 font-semibold">Citizen</th>
                <th className="px-3 py-3 font-semibold">Property</th>
                <th className="px-3 py-3 font-semibold">Method</th>
                <th className="px-3 py-3 text-right font-semibold">Amount</th>
                <th className="px-5 py-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ payment, property, payer, payerEmail }) => (
                <tr key={payment.id} className="border-b border-ink-50 last:border-0">
                  <td className="px-5 py-3.5"><span className="font-mono text-xs font-semibold text-brand-700">{payment.receiptNo}</span><span className="block text-[11px] text-ink-400">{formatDateTime(payment.paidAt)}</span></td>
                  <td className="px-3 py-3.5 text-ink-700">{payer}<span className="block text-[11px] text-ink-400">{payerEmail}</span></td>
                  <td className="px-3 py-3.5 text-xs text-ink-600">{property.propertyCode}<span className="block text-[11px] text-ink-400">{property.ward ?? "—"}</span></td>
                  <td className="px-3 py-3.5 text-xs text-ink-600">{payment.method}</td>
                  <td className="px-3 py-3.5 text-right font-bold tabular-nums text-ink-900">{formatRupees(payment.amount)}</td>
                  <td className="px-5 py-3.5"><StatusBadge status={payment.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
