import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { ArrowLeft, FileText, Mail, MapPin, Phone, User } from "lucide-react";
import { ApplicationAdminPanel } from "@/components/admin/application-admin-panel";
import { StatusBadge } from "@/components/ui/status-badge";
import { Timeline } from "@/components/ui/timeline";
import { db } from "@/db";
import { applicationEvents, applications, users } from "@/db/schema";
import { applicationStatusDescription, isApplicationStatus } from "@/lib/applications";
import { formatDate, formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Review application" };
export const dynamic = "force-dynamic";

export default async function AdminApplicationDetailPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const { reference } = await params;
  const rows = await db.select().from(applications).where(eq(applications.reference, reference)).limit(1);
  const application = rows[0];
  if (!application) notFound();

  const [events, citizen] = await Promise.all([
    db.select().from(applicationEvents).where(eq(applicationEvents.applicationId, application.id)).orderBy(desc(applicationEvents.createdAt)),
    db.select().from(users).where(eq(users.id, application.userId)).limit(1),
  ]);

  return (
    <div>
      <Link href="/admin/applications" className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-orange-700">
        <ArrowLeft className="h-4 w-4" /> Back to applications
      </Link>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">{application.reference}</p>
                <h1 className="mt-1.5 text-xl font-bold tracking-tight text-ink-900 sm:text-2xl">{application.type}</h1>
                <p className="mt-1.5 text-sm text-ink-500">Received {formatDate(application.createdAt)}</p>
              </div>
              <StatusBadge status={application.status} className="px-3 py-1.5 text-sm" />
            </div>
            <p className="mt-4 rounded-xl bg-ink-50 px-4 py-3 text-xs leading-relaxed text-ink-600">
              {isApplicationStatus(application.status) ? applicationStatusDescription[application.status] : ""}
            </p>

            <h2 className="mt-6 text-sm font-bold text-ink-900">Request details</h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-ink-700">{application.details}</p>

            {application.documentUrl ? (
              <a href={application.documentUrl} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-xl border border-ink-200 px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-orange-300 hover:text-orange-700">
                <FileText className="h-4 w-4" /> {application.documentName ?? "Supporting document"}
              </a>
            ) : (
              <p className="mt-5 text-xs text-ink-500">No supporting document was attached.</p>
            )}

            <dl className="mt-6 grid gap-3 sm:grid-cols-3">
              {[
                { icon: User, label: "Applicant", value: application.applicantName },
                { icon: MapPin, label: "Ward", value: application.ward ?? "Not specified" },
                { icon: FileText, label: "Updated", value: formatDateTime(application.updatedAt) },
              ].map((row) => (
                <div key={row.label} className="rounded-xl border border-ink-100 px-4 py-3">
                  <dt className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-ink-400"><row.icon className="h-3 w-3" /> {row.label}</dt>
                  <dd className="mt-1 text-xs font-semibold text-ink-800">{row.value}</dd>
                </div>
              ))}
            </dl>
            {application.filedByName && <p className="mt-4 text-xs text-ink-500">Filed at a service centre by {application.filedByName}.</p>}
          </section>

          <Timeline title="Application history" events={events} />
        </div>

        <aside className="space-y-4">
          <ApplicationAdminPanel
            reference={application.reference}
            currentStatus={application.status}
            currentRemark={application.adminRemark}
            currentAssignee={application.assignedTo}
          />
          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900"><User className="h-4 w-4 text-orange-600" /> Citizen account</h2>
            {citizen[0] ? (
              <dl className="mt-3 space-y-3 text-xs">
                <div className="flex items-center justify-between gap-3"><dt className="text-ink-400">Name</dt><dd className="font-semibold text-ink-800">{citizen[0].name}</dd></div>
                <div className="flex items-center justify-between gap-3"><dt className="flex items-center gap-1 text-ink-400"><Mail className="h-3 w-3" /> Email</dt><dd className="truncate font-semibold text-ink-800">{citizen[0].email}</dd></div>
                <div className="flex items-center justify-between gap-3"><dt className="flex items-center gap-1 text-ink-400"><Phone className="h-3 w-3" /> Phone</dt><dd className="font-semibold text-ink-800">{citizen[0].phone ?? "Not provided"}</dd></div>
              </dl>
            ) : (
              <p className="mt-3 text-xs text-ink-500">Citizen record unavailable.</p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
