import type { Metadata } from "next";
import Link from "next/link";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { Search } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { applications } from "@/db/schema";
import { APPLICATION_STATUSES, APPLICATION_TYPES } from "@/lib/applications";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Application approvals" };
export const dynamic = "force-dynamic";

export default async function AdminApplicationsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string; type?: string }>;
}) {
  const { q = "", status = "all", type = "all" } = await searchParams;

  const conditions = [];
  if (status !== "all") conditions.push(eq(applications.status, status));
  if (type !== "all") conditions.push(eq(applications.type, type));
  if (q.trim()) {
    const pattern = `%${q.trim()}%`;
    conditions.push(
      or(ilike(applications.reference, pattern), ilike(applications.applicantName, pattern), ilike(applications.ward, pattern))!,
    );
  }

  const rows = await db
    .select()
    .from(applications)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(applications.createdAt))
    .limit(200);

  const select =
    "rounded-xl border border-ink-200 bg-white px-3 py-2.5 text-sm text-ink-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

  return (
    <div>
      <PageHeader
        eyebrow="ADMINISTRATION"
        title="Application approvals"
        description="Certificate and permit requests from citizens and service centres. Open one to approve, reject or move it to review."
      />

      <form className="mb-5 flex flex-wrap items-center gap-3 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft" role="search">
        <label className="relative min-w-[220px] flex-1">
          <span className="sr-only">Search applications</span>
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input name="q" defaultValue={q} placeholder="Reference, applicant or ward" className={`${select} w-full pl-9`} />
        </label>
        <select name="status" defaultValue={status} aria-label="Filter by status" className={select}>
          <option value="all">All statuses</option>
          {APPLICATION_STATUSES.map((item) => (<option key={item}>{item}</option>))}
        </select>
        <select name="type" defaultValue={type} aria-label="Filter by type" className={select}>
          <option value="all">All types</option>
          {APPLICATION_TYPES.map((item) => (<option key={item.name}>{item.name}</option>))}
        </select>
        <button type="submit" className="ah-button-primary">Apply filters</button>
      </form>

      {rows.length === 0 ? (
        <EmptyState title="No matching applications" body="Change the filters or wait for citizens to submit requests." />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-ink-100 bg-white shadow-soft">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50/60 text-[11px] uppercase tracking-wide text-ink-400">
                <th className="px-5 py-3 font-semibold">Reference</th>
                <th className="px-3 py-3 font-semibold">Type</th>
                <th className="px-3 py-3 font-semibold">Applicant</th>
                <th className="px-3 py-3 font-semibold">Department</th>
                <th className="px-3 py-3 font-semibold">Status</th>
                <th className="px-5 py-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((item) => (
                <tr key={item.id} className="border-b border-ink-50 last:border-0">
                  <td className="px-5 py-3.5">
                    <span className="font-mono text-xs font-semibold text-brand-700">{item.reference}</span>
                    <span className="block text-[11px] text-ink-400">{formatDate(item.createdAt)}</span>
                  </td>
                  <td className="px-3 py-3.5 text-ink-700">{item.type}</td>
                  <td className="px-3 py-3.5 text-ink-700">{item.applicantName}<span className="block text-[11px] text-ink-400">{item.ward ?? "—"}</span></td>
                  <td className="px-3 py-3.5 text-xs text-ink-600">{item.assignedTo ?? "—"}</td>
                  <td className="px-3 py-3.5"><StatusBadge status={item.status} /></td>
                  <td className="px-5 py-3.5 text-right">
                    <Link href={`/admin/applications/${item.reference}`} className="text-sm font-bold text-brand-700 hover:text-orange-700">Review</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
