import type { Metadata } from "next";
import { BarList, ColumnChart, Donut } from "@/components/ui/charts";
import { PageHeader } from "@/components/ui/page-header";
import {
  getAdminStats,
  getApplicationsByType,
  getComplaintsByService,
  getMonthlyActivity,
  getPlatformStats,
} from "@/lib/data";

export const metadata: Metadata = { title: "Reports and analytics" };
export const dynamic = "force-dynamic";

export default async function AdminReportsPage() {
  const [stats, platform, monthly, byService, byType] = await Promise.all([
    getAdminStats(),
    getPlatformStats(),
    getMonthlyActivity(6),
    getComplaintsByService(8),
    getApplicationsByType(),
  ]);

  const resolved = stats.resolved;
  const rejected = stats.rejected;
  const open = stats.open;
  const resolutionRate = stats.total ? Math.round((resolved / stats.total) * 100) : 0;

  const card = "rounded-2xl border border-ink-100 bg-white p-6 shadow-soft";

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="ADMINISTRATION" title="Reports & analytics" description="How many requests arrive, what they are about and how quickly they are closed." />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Complaints received", value: stats.total },
          { label: "Resolution rate", value: `${resolutionRate}%` },
          { label: "Applications received", value: platform.applicationTotal },
          { label: "Awaiting a decision", value: platform.applicationPending },
        ].map((item) => (
          <div key={item.label} className="rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-5 shadow-soft">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-400">{item.label}</p>
            <p className="mt-2 text-3xl font-bold tabular-nums text-ink-900">{item.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className={card}>
          <h2 className="text-base font-bold text-ink-900">Monthly requests</h2>
          <p className="mt-1 text-xs text-ink-500">Complaints and applications created in the last six months.</p>
          <div className="mt-4"><ColumnChart data={monthly.map((m) => ({ label: m.label, a: m.complaints, b: m.applications }))} /></div>
        </section>
        <section className={card}>
          <h2 className="text-base font-bold text-ink-900">Complaint outcome</h2>
          <p className="mt-1 text-xs text-ink-500">Where every complaint stands today.</p>
          <div className="mt-5">
            <Donut
              centre={String(stats.total)}
              parts={[
                { label: "Open", value: open, color: "#d97706" },
                { label: "Resolved", value: resolved, color: "#16a34a" },
                { label: "Rejected", value: rejected, color: "#e11d48" },
              ]}
            />
          </div>
        </section>
        <section className={card}>
          <h2 className="text-base font-bold text-ink-900">Top complaint categories</h2>
          <div className="mt-5"><BarList items={byService.map((row) => ({ label: row.name, value: row.value }))} tone="bg-orange-500" /></div>
        </section>
        <section className={card}>
          <h2 className="text-base font-bold text-ink-900">Applications by type</h2>
          <div className="mt-5"><BarList items={byType.map((row) => ({ label: row.name, value: row.value }))} /></div>
          <div className="mt-6 border-t border-ink-100 pt-5">
            <Donut
              centre={String(platform.applicationTotal)}
              parts={[
                { label: "Submitted", value: platform.applicationsByStatus.Submitted ?? 0, color: "#94a3b8" },
                { label: "Under review", value: platform.applicationsByStatus["Under Review"] ?? 0, color: "#0ea5e9" },
                { label: "Approved", value: platform.applicationsByStatus.Approved ?? 0, color: "#16a34a" },
                { label: "Rejected", value: platform.applicationsByStatus.Rejected ?? 0, color: "#e11d48" },
              ]}
            />
          </div>
        </section>
      </div>
    </div>
  );
}
