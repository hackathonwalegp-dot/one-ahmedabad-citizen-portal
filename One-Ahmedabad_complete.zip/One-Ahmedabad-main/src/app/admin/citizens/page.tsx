import type { Metadata } from "next";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { Search } from "lucide-react";
import { OperatorForm } from "@/components/admin/operator-form";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { db } from "@/db";
import { users } from "@/db/schema";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Citizens and staff" };
export const dynamic = "force-dynamic";

const ROLE_LABEL: Record<string, string> = { citizen: "Citizen", operator: "Service centre", admin: "Administrator" };
const ROLE_TONE: Record<string, string> = {
  citizen: "bg-slate-100 text-slate-700 ring-slate-200",
  operator: "bg-orange-50 text-orange-800 ring-orange-200",
  admin: "bg-brand-50 text-brand-700 ring-brand-200",
};

export default async function AdminCitizensPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; role?: string }>;
}) {
  const { q = "", role = "all" } = await searchParams;

  const conditions = [];
  if (role !== "all") conditions.push(eq(users.role, role));
  if (q.trim()) {
    const pattern = `%${q.trim()}%`;
    conditions.push(or(ilike(users.name, pattern), ilike(users.email, pattern), ilike(users.phone, pattern))!);
  }

  const rows = await db
    .select({ id: users.id, name: users.name, email: users.email, phone: users.phone, ward: users.ward, role: users.role, createdAt: users.createdAt })
    .from(users)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(users.createdAt))
    .limit(300);

  const select =
    "rounded-xl border border-ink-200 bg-white px-3 py-2.5 text-sm text-ink-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="ADMINISTRATION" title="Citizens & staff" description="Registered accounts. Create service-centre operator accounts here." />

      <form className="flex flex-wrap items-center gap-3 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft" role="search">
        <label className="relative min-w-[220px] flex-1">
          <span className="sr-only">Search accounts</span>
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input name="q" defaultValue={q} placeholder="Name, email or mobile" className={`${select} w-full pl-9`} />
        </label>
        <select name="role" defaultValue={role} aria-label="Filter by role" className={select}>
          <option value="all">All roles</option>
          <option value="citizen">Citizens</option>
          <option value="operator">Service centre</option>
          <option value="admin">Administrators</option>
        </select>
        <button type="submit" className="ah-button-primary">Apply filters</button>
      </form>

      {rows.length === 0 ? (
        <EmptyState title="No matching accounts" />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-ink-100 bg-white shadow-soft">
          <table className="w-full min-w-[680px] text-left text-sm">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50/60 text-[11px] uppercase tracking-wide text-ink-400">
                <th className="px-5 py-3 font-semibold">Name</th>
                <th className="px-3 py-3 font-semibold">Contact</th>
                <th className="px-3 py-3 font-semibold">Ward</th>
                <th className="px-3 py-3 font-semibold">Role</th>
                <th className="px-5 py-3 font-semibold">Joined</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-b border-ink-50 last:border-0">
                  <td className="px-5 py-3.5 font-semibold text-ink-900">{row.name}</td>
                  <td className="px-3 py-3.5 text-xs text-ink-600">{row.email}<span className="block text-[11px] text-ink-400">{row.phone ?? "No mobile"}</span></td>
                  <td className="px-3 py-3.5 text-xs text-ink-600">{row.ward ?? "—"}</td>
                  <td className="px-3 py-3.5">
                    <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${ROLE_TONE[row.role] ?? ROLE_TONE.citizen}`}>{ROLE_LABEL[row.role] ?? row.role}</span>
                  </td>
                  <td className="px-5 py-3.5 text-xs text-ink-600">{formatDate(row.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <OperatorForm />
    </div>
  );
}
