import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { announcements } from "@/db/schema";
import { AnnouncementManager } from "@/components/admin/announcement-manager";

export const metadata: Metadata = { title: "Publish announcements" };
export const dynamic = "force-dynamic";

export default async function AdminAnnouncementsPage() {
  const rows = await db.select().from(announcements).orderBy(desc(announcements.publishedAt));

  return (
    <div>
      <div className="mb-7">
        <h1 className="text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
          Announcements
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Publish a civic notice to all residents. Every published announcement is pushed to signed-in
          citizens as an in-app notification and appears on the public announcements page.
        </p>
      </div>

      <AnnouncementManager
        initialAnnouncements={rows.map((item) => ({
          id: item.id,
          title: item.title,
          body: item.body,
          category: item.category,
          publishedAt: item.publishedAt.toISOString(),
          createdBy: item.createdBy,
        }))}
      />
    </div>
  );
}
