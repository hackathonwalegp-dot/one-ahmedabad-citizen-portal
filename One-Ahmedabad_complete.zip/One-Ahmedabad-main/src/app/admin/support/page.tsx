import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { SupportPanel } from "@/components/admin/support-panel";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { supportTickets } from "@/db/schema";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Support desk" };
export const dynamic = "force-dynamic";

export default async function AdminSupportPage() {
  const tickets = await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt)).limit(200);

  return (
    <div>
      <PageHeader eyebrow="ADMINISTRATION" title="Support desk" description="Requests sent from the help page. A reply is shown to the citizen and sent as a notification." />
      {tickets.length === 0 ? (
        <EmptyState title="No support requests yet" />
      ) : (
        <ul className="space-y-4">
          {tickets.map((ticket) => (
            <li key={ticket.id} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">{ticket.reference}</p>
                  <p className="mt-0.5 text-sm font-bold text-ink-900">{ticket.topic}</p>
                  <p className="mt-0.5 text-xs text-ink-500">{ticket.name} · {ticket.email} · {formatDateTime(ticket.createdAt)}</p>
                </div>
                <StatusBadge status={ticket.status} />
              </div>
              <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-ink-700">{ticket.message}</p>
              <SupportPanel reference={ticket.reference} status={ticket.status} reply={ticket.adminReply} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
