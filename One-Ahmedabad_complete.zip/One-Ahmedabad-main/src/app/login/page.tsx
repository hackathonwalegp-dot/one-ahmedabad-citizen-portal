import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth/auth-forms";
import { getCurrentUser, homeFor } from "@/lib/auth";
import { ensureSeedData } from "@/lib/seed";

export const metadata: Metadata = {
  title: "Sign in",
  description: "Sign in to your One Ahmedabad citizen account to track complaints and notifications.",
};

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  await ensureSeedData();
  const user = await getCurrentUser();
  if (user) redirect(homeFor(user.role));

  return (
    <div className="container-page py-14 lg:py-20">
      <AuthForm mode="login" />
    </div>
  );
}
