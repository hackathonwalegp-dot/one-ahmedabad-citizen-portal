import type { Metadata } from "next";
import Link from "next/link";
import { BookOpen, Compass, MessageCircle, ShieldCheck } from "lucide-react";
import { AssistantChat } from "@/components/assistant/assistant-chat";

export const metadata: Metadata = {
  title: "NagarSetu AI assistant",
  description:
    "Get guidance on which municipal service applies to your situation, with the procedure and official portal link.",
};

export const dynamic = "force-dynamic";

export default function AssistantPage() {
  return (
    <div className="bg-ink-50/40">
      <section className="border-b border-ink-100 bg-white">
        <div className="container-page py-10 lg:py-14">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-100 bg-brand-50 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-brand-700">
            <MessageCircle className="h-3.5 w-3.5" />
            NagarSetu AI assistant
          </span>
          <h1 className="mt-3 text-[clamp(1.9rem,3.6vw,2.6rem)] font-bold tracking-tight">
            Ask NagarSetu in your own words
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-500">
            NagarSetu helps citizens discover the right municipal service, understand the next
            step and navigate this prototype in English, Gujarati or Hindi. With a provider API
            configured, it can respond conversationally using the service directory as its reference.
          </p>
        </div>
      </section>

      <div className="container-page grid gap-6 py-8 lg:grid-cols-[1.6fr_1fr] lg:py-10">
        <AssistantChat />

        <aside className="space-y-4">
          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
              <ShieldCheck className="h-4 w-4 text-brand-600" />
              What the assistant will not do
            </h2>
            <ul className="mt-3 space-y-2.5 text-xs leading-relaxed text-ink-600">
              {[
                "Quote fees, processing times or eligibility rules — AMC publishes those officially.",
                "Claim that One Ahmedabad is connected to an AMC system.",
                "Accept payments or promise government certificates.",
              ].map((item) => (
                <li key={item} className="flex gap-2">
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-brand-500" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
              <Compass className="h-4 w-4 text-brand-600" />
              Popular journeys
            </h2>
            <ul className="mt-3 space-y-2">
              {[
                { href: "/dashboard/complaints/new", label: "Register a civic complaint" },
                { href: "/services?category=civic-services", label: "Civic complaint types" },
                { href: "/services?category=certificates", label: "Certificates guidance" },
                { href: "/services?category=property-taxes", label: "Property and tax help" },
                { href: "/track", label: "Track an existing complaint" },
              ].map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-xs font-semibold text-ink-600 transition hover:bg-ink-50 hover:text-brand-700"
                  >
                    {item.label}
                    <span aria-hidden="true">→</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
              <BookOpen className="h-4 w-4 text-brand-600" />
              How it works
            </h2>
            <ol className="mt-3 space-y-2.5 text-xs leading-relaxed text-ink-600">
              {[
                "Your question is matched against the service directory in the database.",
                "The answer quotes the stored procedure, requirements and responsible desk.",
                "You get direct links to the service page and the official portal.",
              ].map((step, index) => (
                <li key={step} className="flex gap-2">
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-brand-50 text-[10px] font-bold text-brand-700">
                    {index + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
        </aside>
      </div>
    </div>
  );
}
