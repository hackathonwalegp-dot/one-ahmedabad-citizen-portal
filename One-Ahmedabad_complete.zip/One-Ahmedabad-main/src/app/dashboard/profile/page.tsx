import type { Metadata } from "next";
import { User } from "lucide-react";
import { ProfileForm } from "@/components/dashboard/profile-form";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Profile settings" };
export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const user = await getCurrentUser();
  if (!user) return null;

  return (
    <div>
      <div className="mb-7">
        <h1 className="flex items-center gap-2.5 text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
          <User className="h-6 w-6 text-brand-600" />
          Profile settings
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Keep your contact details current so ward teams can reach you, and manage your password.
        </p>
      </div>

      <ProfileForm
        user={{
          name: user.name,
          email: user.email,
          phone: user.phone,
          ward: user.ward,
          address: user.address,
        }}
      />
    </div>
  );
}
