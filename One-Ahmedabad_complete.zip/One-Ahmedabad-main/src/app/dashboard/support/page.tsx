import type { Metadata } from "next";
import { eq, desc } from "drizzle-orm";
import { ChevronDown, MessageSquareReply } from "lucide-react";
import { SupportForm } from "@/components/support/support-form";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { supportTickets } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Help & support" };
export const dynamic = "force-dynamic";

const FAQ = [
  {
    q: "How do I follow a complaint or application?",
    a: "Open My complaints or My applications. Each record has a timeline. You can also use the Track page with the reference number and your registered email.",
  },
  {
    q: "Does a complaint here reach AMC?",
    a: "No. This is an independent prototype. Complaints are stored in its own database and are not forwarded to AMC. For an official grievance use the AMC portals linked in the footer.",
  },
  {
    q: "Is the property tax payment real?",
    a: "No. The simulator records a demo receipt marked DEMO. No payment gateway is connected and no money moves.",
  },
  {
    q: "I visited a service centre. How do I sign in?",
    a: "The operator gives you a sign-in email and a temporary password. Sign in and change the password from Profile settings.",
  },
];

export default async function SupportPage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const tickets = await db
    .select()
    .from(supportTickets)
    .where(eq(supportTickets.userId, user.id))
    .orderBy(desc(supportTickets.createdAt));

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="HELP DESK" title="Help & support" description="Common answers first. If you still need help, send a request and the reply will appear here." />

      <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <section className="space-y-3">
          {FAQ.map((item) => (
            <details key={item.q} className="group rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-bold text-ink-900">
                {item.q}
                <ChevronDown className="h-4 w-4 shrink-0 text-ink-400 transition group-open:rotate-180" />
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-ink-600">{item.a}</p>
            </details>
          ))}
        </section>
        <SupportForm defaultName={user.name} defaultEmail={user.email.endsWith(".invalid") ? "" : user.email} />
      </div>

      {tickets.length > 0 && (
        <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
          <h2 className="text-base font-bold text-ink-900">Your requests</h2>
          <ul className="mt-4 divide-y divide-ink-100">
            {tickets.map((ticket) => (
              <li key={ticket.id} className="py-4 first:pt-0 last:pb-0">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-bold text-ink-900">{ticket.topic} <span className="ml-2 font-mono text-xs font-semibold text-brand-700">{ticket.reference}</span></p>
                  <StatusBadge status={ticket.status} />
                </div>
                <p className="mt-1 text-[11px] text-ink-400">{formatDateTime(ticket.createdAt)}</p>
                <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-ink-600">{ticket.message}</p>
                {ticket.adminReply && (
                  <div className="mt-3 rounded-xl border border-orange-100 bg-orange-50/70 p-4">
                    <p className="flex items-center gap-1.5 text-xs font-bold text-orange-900"><MessageSquareReply className="h-3.5 w-3.5" /> Support desk reply</p>
                    <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed text-ink-700">{ticket.adminReply}</p>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
