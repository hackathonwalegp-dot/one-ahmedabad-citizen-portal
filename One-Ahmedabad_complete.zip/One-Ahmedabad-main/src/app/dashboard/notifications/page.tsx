import type { Metadata } from "next";
import { Bell } from "lucide-react";
import { NotificationInbox } from "@/components/dashboard/notification-inbox";
import { getCurrentUser } from "@/lib/auth";
import { getNotifications } from "@/lib/data";

export const metadata: Metadata = { title: "Notifications" };
export const dynamic = "force-dynamic";

export default async function NotificationsPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  const items = await getNotifications(user.id);

  return (
    <div>
      <div className="mb-7">
        <h1 className="flex items-center gap-2.5 text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
          <Bell className="h-6 w-6 text-brand-600" />
          Notifications
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Complaint submissions, status changes, administrative remarks and announcements are
          delivered here as soon as they happen.
        </p>
      </div>

      <NotificationInbox
        initialItems={items.map((item) => ({
          id: item.id,
          title: item.title,
          body: item.body,
          type: item.type,
          link: item.link,
          isRead: item.isRead,
          createdAt: item.createdAt.toISOString(),
        }))}
      />
    </div>
  );
}
