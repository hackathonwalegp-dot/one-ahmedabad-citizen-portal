import type { Metadata } from "next";
import { ApplicationForm } from "@/components/applications/application-form";
import { PageHeader } from "@/components/ui/page-header";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Apply for a certificate or permit" };
export const dynamic = "force-dynamic";

export default async function NewApplicationPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null;
  const { type } = await searchParams;

  return (
    <div>
      <PageHeader
        eyebrow="NEW REQUEST"
        title="Apply for a certificate or permit"
        description="Fill in the request, attach a document if you have one, and keep the reference number to follow the decision."
      />
      <ApplicationForm initialType={type} defaultName={user.name} defaultWard={user.ward ?? ""} />
    </div>
  );
}
