import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { ArrowLeft, FileText, MapPin, UserRound } from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { Timeline } from "@/components/ui/timeline";
import { db } from "@/db";
import { applicationEvents, applications } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { applicationStatusDescription, isApplicationStatus } from "@/lib/applications";
import { formatDate, formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Application details" };
export const dynamic = "force-dynamic";

export default async function ApplicationDetailPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null;
  const { reference } = await params;

  const rows = await db
    .select()
    .from(applications)
    .where(and(eq(applications.reference, reference), eq(applications.userId, user.id)))
    .limit(1);
  const application = rows[0];
  if (!application) notFound();

  const events = await db
    .select()
    .from(applicationEvents)
    .where(eq(applicationEvents.applicationId, application.id))
    .orderBy(desc(applicationEvents.createdAt));

  return (
    <div>
      <Link href="/dashboard/applications" className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-orange-700">
        <ArrowLeft className="h-4 w-4" /> Back to my applications
      </Link>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">{application.reference}</p>
                <h1 className="mt-1.5 text-xl font-bold tracking-tight text-ink-900 sm:text-2xl">{application.type}</h1>
                <p className="mt-1.5 text-sm text-ink-500">Sent {formatDate(application.createdAt)}</p>
              </div>
              <StatusBadge status={application.status} className="px-3 py-1.5 text-sm" />
            </div>
            <p className="mt-4 rounded-xl bg-ink-50 px-4 py-3 text-xs leading-relaxed text-ink-600">
              {isApplicationStatus(application.status) ? applicationStatusDescription[application.status] : ""}
            </p>

            <h2 className="mt-6 text-sm font-bold text-ink-900">Your request</h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-ink-700">{application.details}</p>

            {application.documentUrl && (
              <a href={application.documentUrl} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-xl border border-ink-200 px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-orange-300 hover:text-orange-700">
                <FileText className="h-4 w-4" /> {application.documentName ?? "Supporting document"}
              </a>
            )}

            <dl className="mt-6 grid gap-3 sm:grid-cols-3">
              {[
                { icon: UserRound, label: "Applicant", value: application.applicantName },
                { icon: MapPin, label: "Ward", value: application.ward ?? "Not specified" },
                { icon: FileText, label: "Department", value: application.assignedTo ?? "Awaiting assignment" },
              ].map((row) => (
                <div key={row.label} className="rounded-xl border border-ink-100 px-4 py-3">
                  <dt className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-ink-400"><row.icon className="h-3 w-3" /> {row.label}</dt>
                  <dd className="mt-1 text-xs font-semibold text-ink-800">{row.value}</dd>
                </div>
              ))}
            </dl>
            {application.filedByName && (
              <p className="mt-4 text-xs text-ink-500">Filed at a service centre by {application.filedByName} on {formatDateTime(application.createdAt)}.</p>
            )}
          </section>

          <Timeline title="Application history" events={events} />
        </div>

        <aside className="space-y-4">
          {application.adminRemark && (
            <div className="rounded-2xl border border-orange-100 bg-orange-50/70 p-5">
              <h2 className="text-sm font-bold text-orange-950">Remark from the reviewing officer</h2>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{application.adminRemark}</p>
            </div>
          )}
          <div className="rounded-2xl border border-ink-100 bg-white p-5 text-xs leading-relaxed text-ink-600 shadow-soft">
            <p className="font-bold text-ink-900">Prototype notice</p>
            <p className="mt-1.5">An approval here does not issue a real certificate or licence. Check the official AMC portal for real documents.</p>
          </div>
          <Link href="/dashboard/support" className="block rounded-2xl border border-ink-100 bg-white p-4 text-center text-xs font-semibold text-ink-600 shadow-soft transition hover:border-orange-300 hover:text-orange-700">
            Need help with this application?
          </Link>
        </aside>
      </div>
    </div>
  );
}
