import type { Metadata } from "next";
import Link from "next/link";
import { FilePlus2, FileText } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { getCurrentUser } from "@/lib/auth";
import { getCitizenApplications } from "@/lib/data";
import { APPLICATION_STATUSES } from "@/lib/applications";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "My applications" };
export const dynamic = "force-dynamic";

export default async function ApplicationsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null;
  const { status } = await searchParams;

  const all = await getCitizenApplications(user.id);
  const list = status && status !== "all" ? all.filter((item) => item.status === status) : all;

  return (
    <div>
      <PageHeader
        eyebrow="CERTIFICATES & PERMITS"
        title="My applications"
        description="Every certificate or permit request you have sent through this prototype, with its current status and history."
        action={
          <Link href="/dashboard/applications/new" className="ah-button-primary">
            <FilePlus2 className="h-4 w-4" /> New application
          </Link>
        }
      />

      <div className="mb-5 flex flex-wrap gap-2">
        {["all", ...APPLICATION_STATUSES].map((item) => {
          const active = (status ?? "all") === item;
          return (
            <Link
              key={item}
              href={item === "all" ? "/dashboard/applications" : `/dashboard/applications?status=${encodeURIComponent(item)}`}
              className={
                "rounded-full border px-4 py-1.5 text-xs font-semibold " +
                (active ? "border-orange-500 bg-orange-50 text-orange-700" : "border-ink-200 bg-white text-ink-600 hover:border-orange-300")
              }
            >
              {item === "all" ? "All" : item}
            </Link>
          );
        })}
      </div>

      {list.length === 0 ? (
        <EmptyState
          title={all.length === 0 ? "No applications yet" : "No applications with this status"}
          body="Start a birth or death certificate, trade licence or municipal permit request. You can attach one supporting document."
          action={<Link href="/dashboard/applications/new" className="ah-button-primary">Start an application</Link>}
        />
      ) : (
        <ul className="space-y-3">
          {list.map((item) => (
            <li key={item.id}>
              <Link
                href={`/dashboard/applications/${item.reference}`}
                className="card-hover flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-ink-100 bg-white p-5 shadow-soft"
              >
                <div className="flex min-w-0 items-start gap-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center bg-brand-50 text-brand-700"><FileText className="h-5 w-5" /></span>
                  <div className="min-w-0">
                    <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">{item.reference}</p>
                    <p className="mt-0.5 truncate text-sm font-bold text-ink-900">{item.type} for {item.applicantName}</p>
                    <p className="mt-0.5 text-xs text-ink-500">
                      Sent {formatDate(item.createdAt)}{item.assignedTo ? ` · ${item.assignedTo}` : ""}{item.filedByName ? ` · filed by ${item.filedByName}` : ""}
                    </p>
                  </div>
                </div>
                <StatusBadge status={item.status} />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
