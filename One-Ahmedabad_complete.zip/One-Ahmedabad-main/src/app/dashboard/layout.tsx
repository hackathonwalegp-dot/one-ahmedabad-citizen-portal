import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { MessageSquare, ShieldCheck, User } from "lucide-react";
import { SideNav, type SideNavItem } from "@/components/site/side-nav";
import { T } from "@/components/site/t";
import { getCurrentUser, toPublicUser } from "@/lib/auth";
import { getUnreadNotificationCount } from "@/lib/data";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  await ensureSeedData();
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard");
  if (user.role === "operator") redirect("/centre");

  const publicUser = toPublicUser(user);
  const unread = await getUnreadNotificationCount(user.id);

  const items: SideNavItem[] = [
    { href: "/dashboard", labelKey: "nav.overview", icon: "overview", exact: true },
    { href: "/dashboard/complaints", labelKey: "nav.complaints", icon: "complaints" },
    { href: "/dashboard/complaints/new", labelKey: "nav.newComplaint", icon: "newComplaint" },
    { href: "/dashboard/applications", labelKey: "nav.applications", icon: "applications" },
    { href: "/dashboard/applications/new", labelKey: "nav.newApplication", icon: "newApplication" },
    { href: "/dashboard/payments", labelKey: "nav.payments", icon: "payments" },
    { href: "/dashboard/notifications", labelKey: "nav.notifications", icon: "notifications", badge: unread },
    { href: "/dashboard/support", labelKey: "nav.support", icon: "support" },
    { href: "/dashboard/profile", labelKey: "nav.profile", icon: "profile" },
  ];

  return (
    <div className="bg-ink-50/50">
      <div className="container-page flex gap-8 py-6 lg:py-10">
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-40 space-y-6">
            <div className="rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-4 shadow-soft">
              <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-ink-400">
                <T k="side.signedInAs" />
              </p>
              <p className="mt-1.5 truncate text-sm font-bold text-ink-900">{publicUser.name}</p>
              <p className="truncate text-xs text-ink-500">{publicUser.email}</p>
              <span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-brand-50 px-2.5 py-1 text-[11px] font-semibold text-brand-700 ring-1 ring-brand-100">
                {publicUser.role === "admin" ? <ShieldCheck className="h-3 w-3" /> : <User className="h-3 w-3" />}
                <T k={publicUser.role === "admin" ? "role.admin" : "role.citizen"} />
              </span>
            </div>

            <SideNav items={items} variant="sidebar" />

            <div className="rounded-2xl border border-brand-100 bg-brand-50/70 p-4">
              <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-brand-800">
                <MessageSquare className="h-3.5 w-3.5" /> <T k="side.guideTitle" />
              </p>
              <p className="mt-2 text-xs leading-relaxed text-ink-600">
                <T k="side.guideBody" />
              </p>
              <Link
                href="/assistant"
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 hover:text-orange-600"
              >
                <T k="side.guideLink" />
              </Link>
            </div>

            {publicUser.role === "admin" && (
              <Link
                href="/admin"
                className="flex items-center gap-3 rounded-xl bg-ink-900 px-3.5 py-2.5 text-sm font-semibold text-white shadow-soft transition hover:bg-ink-800"
              >
                <ShieldCheck className="h-[18px] w-[18px]" />
                <T k="side.adminConsole" />
              </Link>
            )}
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <div className="-mx-5 mb-5 overflow-x-auto px-5 scroll-slim lg:hidden">
            <SideNav items={items} variant="pills" />
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
