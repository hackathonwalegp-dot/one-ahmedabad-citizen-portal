import type { Metadata } from "next";
import Link from "next/link";
import { Receipt, ShieldAlert } from "lucide-react";
import { AddPropertyForm, PropertyList } from "@/components/payments/payment-panel";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { getCurrentUser } from "@/lib/auth";
import { getCitizenPayments, getPropertySummaries } from "@/lib/data";
import { formatRupees } from "@/lib/money";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Property tax simulator" };
export const dynamic = "force-dynamic";

export default async function PaymentsPage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const [properties, history] = await Promise.all([getPropertySummaries(user.id), getCitizenPayments(user.id)]);
  const isCitizen = user.role === "citizen";

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="PROPERTY TAX SIMULATOR"
        title="Property tax & payments"
        description="Add a property, see an illustrative assessment and try a demo payment. A DEMO receipt can be printed or saved as PDF from your browser."
        action={isCitizen ? <AddPropertyForm defaultOwner={user.name} defaultWard={user.ward ?? ""} /> : undefined}
      />

      <div className="flex items-start gap-3 rounded-2xl border border-orange-100 bg-orange-50/70 p-4 text-xs leading-relaxed text-orange-950">
        <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-orange-700" />
        <p>
          <b>Simulation only.</b> Assessments are illustrative, not AMC records. No payment gateway is connected and no money moves. For real property tax use the{" "}
          <Link href="/services/tax-payment-portal" className="font-bold underline underline-offset-2">official payment portal guidance</Link>.
        </p>
      </div>

      {properties.length === 0 ? (
        <EmptyState title="No properties added" body="Add a property to see an illustrative assessment for this assessment year." />
      ) : (
        <PropertyList properties={properties} />
      )}

      <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
          <Receipt className="h-[18px] w-[18px] text-orange-600" /> Payment history
        </h2>
        {history.length === 0 ? (
          <p className="mt-3 text-sm text-ink-500">No demo payments yet.</p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead>
                <tr className="border-b border-ink-100 text-[11px] uppercase tracking-wide text-ink-400">
                  <th className="py-2 pr-4 font-semibold">Receipt</th>
                  <th className="py-2 pr-4 font-semibold">Property</th>
                  <th className="py-2 pr-4 font-semibold">Method</th>
                  <th className="py-2 pr-4 text-right font-semibold">Amount</th>
                  <th className="py-2 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map(({ payment, property }) => (
                  <tr key={payment.id} className="border-b border-ink-50 last:border-0">
                    <td className="py-3 pr-4">
                      <Link href={`/dashboard/payments/${payment.receiptNo}`} className="font-mono text-xs font-semibold text-brand-700 hover:text-orange-700">{payment.receiptNo}</Link>
                      <span className="block text-[11px] text-ink-400">{formatDateTime(payment.paidAt)}</span>
                    </td>
                    <td className="py-3 pr-4 text-xs text-ink-600">{property.propertyCode}</td>
                    <td className="py-3 pr-4 text-xs text-ink-600">{payment.method}</td>
                    <td className="py-3 pr-4 text-right font-bold tabular-nums text-ink-900">{formatRupees(payment.amount)}</td>
                    <td className="py-3"><StatusBadge status={payment.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
