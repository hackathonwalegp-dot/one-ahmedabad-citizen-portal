import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { PrintButton } from "@/components/payments/print-button";
import { db } from "@/db";
import { payments, properties, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatRupees } from "@/lib/money";
import { formatDateTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Demo receipt" };
export const dynamic = "force-dynamic";

export default async function ReceiptPage({ params }: { params: Promise<{ receipt: string }> }) {
  const user = await getCurrentUser();
  if (!user) return null;
  const { receipt } = await params;

  const rows = await db
    .select({ payment: payments, property: properties, payer: users.name })
    .from(payments)
    .innerJoin(properties, eq(properties.id, payments.propertyId))
    .innerJoin(users, eq(users.id, payments.userId))
    .where(and(eq(payments.receiptNo, receipt), eq(payments.userId, user.id)))
    .limit(1);
  const row = rows[0];
  if (!row) notFound();

  const { payment, property, payer } = row;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <Link href="/dashboard/payments" className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-orange-700">
          <ArrowLeft className="h-4 w-4" /> Back to payments
        </Link>
        <PrintButton />
      </div>

      <article className="relative mx-auto max-w-2xl overflow-hidden border border-ink-200 bg-white p-8 shadow-soft">
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <span className="-rotate-[24deg] select-none text-[88px] font-black tracking-widest text-ink-100/80">DEMO</span>
        </div>
        <div className="relative">
          <div className="flex items-start justify-between gap-4 border-b-2 border-orange-500 pb-5">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-orange-700">One Ahmedabad</p>
              <h1 className="mt-1 text-2xl font-bold text-ink-900">Property tax simulator receipt</h1>
            </div>
            <span className="border border-rose-300 bg-rose-50 px-3 py-1 text-xs font-bold uppercase tracking-wide text-rose-700">Not a valid receipt</span>
          </div>

          <dl className="mt-6 grid gap-x-8 gap-y-4 sm:grid-cols-2">
            {[
              ["Receipt number", payment.receiptNo],
              ["Date and time", formatDateTime(payment.paidAt)],
              ["Paid by", payer],
              ["Payment method", payment.method],
              ["Property code", property.propertyCode],
              ["Assessment year", property.assessmentYear],
              ["Property address", property.address],
              ["Ward", property.ward ?? "Not specified"],
            ].map(([label, value]) => (
              <div key={label}>
                <dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">{label}</dt>
                <dd className="mt-0.5 text-sm font-semibold text-ink-900">{value}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-8 flex items-center justify-between bg-ink-950 px-5 py-4 text-white">
            <span className="text-sm font-semibold">Amount recorded in the simulator</span>
            <span className="text-2xl font-bold tabular-nums">{formatRupees(payment.amount)}</span>
          </div>
          <p className="mt-6 text-[11px] leading-relaxed text-ink-500">
            This document was produced by an independent hackathon prototype. No money was transferred, the assessment is illustrative and the document has no legal or accounting value. Use the official AMC portal for real property tax payments.
          </p>
        </div>
      </article>
    </div>
  );
}
