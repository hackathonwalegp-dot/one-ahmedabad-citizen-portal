import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Info } from "lucide-react";
import { ComplaintForm } from "@/components/complaints/complaint-form";
import { getServices } from "@/lib/data";

export const metadata: Metadata = { title: "Register a complaint" };
export const dynamic = "force-dynamic";

export default async function NewComplaintPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const params = await searchParams;
  const services = await getServices();
  const complaintTypes = services.filter((service) => service.isComplaintType);

  return (
    <div>
      <Link
        href="/dashboard/complaints"
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-brand-700"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to my complaints
      </Link>

      <div className="mt-4 mb-7">
        <h1 className="text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">
          Register a complaint
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Give the exact location, describe what is happening and attach a photograph if you can.
          You will get a unique reference number to track the complaint end-to-end.
        </p>
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-ink-50 px-3 py-1.5 text-[11px] font-medium text-ink-500">
          <Info className="h-3.5 w-3.5 text-brand-600" />
          Prototype workflow — the complaint is stored in this demo database and reviewed by the
          administrator account.
        </p>
      </div>

      <ComplaintForm
        categories={complaintTypes.map((service) => ({
          slug: service.slug,
          name: service.name,
          summary: service.summary,
          categoryName: service.categoryName,
          categoryIcon: service.categoryIcon,
          accent: service.accent,
        }))}
        initialCategory={
          params.category && complaintTypes.some((service) => service.slug === params.category)
            ? params.category
            : undefined
        }
      />
    </div>
  );
}
