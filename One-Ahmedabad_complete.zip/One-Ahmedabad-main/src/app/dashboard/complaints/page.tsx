import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/auth";
import { getCitizenComplaints } from "@/lib/data";
import { ComplaintList } from "@/components/complaints/complaint-list";

export const metadata: Metadata = { title: "My complaints" };
export const dynamic = "force-dynamic";

export default async function MyComplaintsPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  const complaints = await getCitizenComplaints(user.id);

  return (
    <div>
      <div className="mb-7">
        <h1 className="text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">My complaints</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          Every complaint you have raised, with its live status. Open a complaint to see the full
          timeline and administrative remarks.
        </p>
      </div>

      <ComplaintList
        complaints={complaints.map((complaint) => ({
          id: complaint.id,
          reference: complaint.reference,
          title: complaint.title,
          serviceName: complaint.serviceName,
          area: complaint.area,
          ward: complaint.ward,
          status: complaint.status,
          photoUrl: complaint.photoUrl,
          createdAt: complaint.createdAt.toISOString(),
          updatedAt: complaint.updatedAt.toISOString(),
        }))}
      />
    </div>
  );
}
