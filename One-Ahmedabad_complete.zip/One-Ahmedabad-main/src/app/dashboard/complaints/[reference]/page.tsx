import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import {
  ArrowLeft,
  Camera,
  CircleCheck,
  CircleX,
  Clock3,
  MapPin,
  MessageSquare,
  Phone,
  ShieldCheck,
  User,
} from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { db } from "@/db";
import { complaintEvents, complaints } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { STATUS_FLOW, statusMeta, type ComplaintStatus } from "@/lib/complaints";
import { formatDate, formatDateTime } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ reference: string }>;
}): Promise<Metadata> {
  const { reference } = await params;
  return { title: `Complaint ${reference}` };
}

export default async function ComplaintDetailPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null;

  const { reference } = await params;
  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.reference, reference))
    .limit(1);
  const complaint = rows[0];
  if (!complaint) notFound();

  if (user.role !== "admin" && complaint.userId !== user.id) {
    return (
      <div className="rounded-2xl border border-rose-200 bg-rose-50 p-6">
        <h1 className="text-lg font-bold text-rose-800">Access denied</h1>
        <p className="mt-2 text-sm text-rose-700">
          This complaint belongs to another citizen account.
        </p>
        <Link
          href="/dashboard/complaints"
          className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-rose-700"
        >
          <ArrowLeft className="h-4 w-4" /> Back to my complaints
        </Link>
      </div>
    );
  }

  const events = await db
    .select()
    .from(complaintEvents)
    .where(eq(complaintEvents.complaintId, complaint.id))
    .orderBy(desc(complaintEvents.createdAt));

  const meta = statusMeta[complaint.status as ComplaintStatus] ?? statusMeta.Submitted;
  const isRejected = complaint.status === "Rejected";
  const currentStep = STATUS_FLOW.indexOf(complaint.status as ComplaintStatus);

  return (
    <div>
      <Link
        href={user.role === "admin" ? "/admin/complaints" : "/dashboard/complaints"}
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-brand-700"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to complaints
      </Link>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          {/* Summary */}
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">
                  {complaint.reference}
                </p>
                <h1 className="mt-1.5 text-xl font-bold tracking-tight text-ink-900 sm:text-2xl">
                  {complaint.title}
                </h1>
                <p className="mt-1.5 text-sm text-ink-500">{complaint.serviceName}</p>
              </div>
              <StatusBadge status={complaint.status} className="px-3 py-1.5 text-sm" />
            </div>

            {/* Progress */}
            {isRejected ? (
              <div className="mt-6 flex items-start gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3.5">
                <CircleX className="mt-0.5 h-5 w-5 shrink-0 text-rose-600" />
                <div>
                  <p className="text-sm font-semibold text-rose-800">Complaint rejected</p>
                  <p className="mt-1 text-xs leading-relaxed text-rose-700">
                    {complaint.adminRemark ??
                      "The department closed this complaint without action. Please read the remarks below."}
                  </p>
                </div>
              </div>
            ) : (
              <div className="mt-7">
                <ol className="flex items-start">
                  {STATUS_FLOW.map((step, index) => {
                    const done = index <= currentStep;
                    const active = index === currentStep;
                    const stepMeta = statusMeta[step];
                    return (
                      <li key={step} className="relative flex flex-1 flex-col items-center text-center">
                        {index > 0 && (
                          <span
                            className={
                              "absolute right-1/2 top-3.5 h-0.5 w-full " +
                              (index <= currentStep ? stepMeta.bar : "bg-ink-100")
                            }
                          />
                        )}
                        <span
                          className={
                            "relative z-10 grid h-7 w-7 place-items-center rounded-full text-[10px] font-bold ring-4 ring-white " +
                            (done ? stepMeta.bar + " text-white" : "bg-ink-100 text-ink-400")
                          }
                        >
                          {done ? <CircleCheck className="h-4 w-4" /> : index + 1}
                        </span>
                        <span
                          className={
                            "mt-2 text-[10px] font-semibold leading-tight sm:text-[11px] " +
                            (active ? "text-ink-900" : done ? "text-ink-500" : "text-ink-300")
                          }
                        >
                          {stepMeta.label}
                        </span>
                      </li>
                    );
                  })}
                </ol>
                <p className="mt-4 rounded-xl bg-ink-50 px-4 py-3 text-xs leading-relaxed text-ink-600">
                  {meta.description}
                </p>
              </div>
            )}
          </section>

          {/* Description */}
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <h2 className="text-base font-bold text-ink-900">Description</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-ink-700">
              {complaint.description}
            </p>

            {complaint.photoUrl && (
              <div className="mt-5">
                <p className="text-xs font-bold uppercase tracking-wide text-ink-400">
                  Attached photograph
                </p>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={complaint.photoUrl}
                  alt={`Photograph attached to complaint ${complaint.reference}`}
                  className="mt-2 max-h-96 w-full rounded-2xl border border-ink-100 object-cover"
                />
              </div>
            )}
          </section>

          {/* History */}
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <Clock3 className="h-4.5 w-4.5 text-brand-600" />
              Complaint history
            </h2>
            {events.length === 0 ? (
              <p className="mt-3 text-sm text-ink-500">No history recorded yet.</p>
            ) : (
              <ol className="mt-5 space-y-5">
                {events.map((event, index) => {
                  const eventMeta = statusMeta[event.status as ComplaintStatus] ?? statusMeta.Submitted;
                  return (
                    <li key={event.id} className="relative flex gap-4 pl-1">
                      {index < events.length - 1 && (
                        <span className="absolute left-[13px] top-7 h-full w-px bg-ink-100" />
                      )}
                      <span
                        className={
                          "relative z-10 mt-1 h-3 w-3 shrink-0 rounded-full ring-4 ring-white " +
                          eventMeta.dot
                        }
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-bold text-ink-900">{eventMeta.label}</p>
                          <span className="text-[11px] text-ink-400">
                            {formatDateTime(event.createdAt)}
                          </span>
                          <span className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-ink-500">
                            {event.actorType === "admin"
                              ? "Administrator"
                              : event.actorType === "citizen"
                                ? "Citizen"
                                : event.actorType === "operator"
                                  ? "Service centre"
                                  : "System"}
                          </span>
                        </div>
                        {event.note && (
                          <p className="mt-1.5 text-sm leading-relaxed text-ink-600">{event.note}</p>
                        )}
                        {event.actorName && (
                          <p className="mt-1 text-[11px] text-ink-400">by {event.actorName}</p>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ol>
            )}
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="text-sm font-bold text-ink-900">Complaint details</h2>
            <dl className="mt-4 space-y-3.5 text-sm">
              {[
                { icon: MapPin, label: "Area", value: complaint.area },
                { icon: MapPin, label: "Ward", value: complaint.ward ?? "Not specified" },
                { icon: MapPin, label: "Landmark", value: complaint.landmark ?? "Not specified" },
                { icon: Phone, label: "Contact", value: complaint.contactPhone ?? "Not provided" },
                { icon: Camera, label: "Photograph", value: complaint.photoUrl ? "Attached" : "Not attached" },
                { icon: Clock3, label: "Raised on", value: formatDateTime(complaint.createdAt) },
                { icon: Clock3, label: "Last update", value: formatDateTime(complaint.updatedAt) },
              ].map((row) => (
                <div key={row.label} className="flex items-start justify-between gap-4">
                  <dt className="flex items-center gap-1.5 text-xs font-medium text-ink-400">
                    <row.icon className="h-3.5 w-3.5" />
                    {row.label}
                  </dt>
                  <dd className="max-w-[60%] text-right text-xs font-semibold text-ink-800">
                    {row.value}
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          {complaint.assignedTo && (
            <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
              <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
                <User className="h-4 w-4 text-brand-600" /> Assigned to
              </h2>
              <p className="mt-2 text-sm font-semibold text-ink-800">{complaint.assignedTo}</p>
            </div>
          )}

          {complaint.adminRemark && (
            <div className="rounded-2xl border border-brand-100 bg-brand-50/60 p-5">
              <h2 className="flex items-center gap-2 text-sm font-bold text-brand-900">
                <MessageSquare className="h-4 w-4" /> Administrative remark
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{complaint.adminRemark}</p>
            </div>
          )}

          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
              <ShieldCheck className="h-4 w-4 text-brand-600" /> Prototype notice
            </h2>
            <p className="mt-2 text-xs leading-relaxed text-ink-500">
              This reference number and timeline are produced by the One Ahmedabad demo database.
              No AMC system has received this complaint.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
