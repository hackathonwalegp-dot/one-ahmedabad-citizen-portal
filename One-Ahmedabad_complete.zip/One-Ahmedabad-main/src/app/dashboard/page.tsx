import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  Bell,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Clock3,
  Droplets,
  FilePlus2,
  FileText,
  Hammer,
  MessageSquare,
  PlusCircle,
  Trash2,
  TriangleAlert,
  User,
  WalletCards,
} from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { getCurrentUser } from "@/lib/auth";
import {
  getCitizenApplicationStats,
  getCitizenComplaintStats,
  getCitizenComplaints,
  getNotifications,
  getOutstandingTotal,
} from "@/lib/data";
import { formatRupees } from "@/lib/money";
import { formatDate, timeAgo } from "@/lib/utils";

export const metadata: Metadata = { title: "Citizen dashboard" };
export const dynamic = "force-dynamic";

const QUICK_SHORTCUTS = [
  { href: "/dashboard/complaints/new?category=garbage-collection-complaint", label: "Garbage not collected", icon: Trash2 },
  { href: "/dashboard/complaints/new?category=potholes-damaged-roads", label: "Report a pothole", icon: TriangleAlert },
  { href: "/dashboard/complaints/new?category=water-supply-complaint", label: "No water supply", icon: Droplets },
  { href: "/dashboard/complaints/new?category=streetlight-complaint", label: "Streetlight not working", icon: Hammer },
];

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) return null;

  const [stats, complaints, notifications, applicationStats, outstanding] = await Promise.all([
    getCitizenComplaintStats(user.id),
    getCitizenComplaints(user.id),
    getNotifications(user.id, 5),
    getCitizenApplicationStats(user.id),
    getOutstandingTotal(user.id),
  ]);

  const firstName = user.name.split(" ")[0];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const unread = notifications.filter((item) => !item.isRead).length;

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <section className="relative overflow-hidden rounded-3xl bg-ink-950 p-6 shadow-lift sm:p-8">
        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-brand-200">
              {greeting}, {firstName}
            </p>
            <h1 className="mt-2 text-2xl font-bold text-white sm:text-3xl">
              Your civic services, in one place
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-ink-300">
              Track every complaint you have raised, read the latest announcements and jump back
              into the services you use most often.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link
                href="/dashboard/complaints/new"
                className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-ink-950 shadow-soft transition hover:bg-ink-100"
              >
                <PlusCircle className="h-4 w-4" />
                Register a complaint
              </Link>
              <Link
                href="/services"
                className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/5"
              >
                Browse services
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
            {[
              { label: "Total complaints", value: stats.total, tone: "text-white" },
              { label: "Pending", value: stats.pending, tone: "text-amber-300" },
              { label: "In progress", value: stats.inProgress, tone: "text-brand-200" },
              { label: "Resolved", value: stats.resolved, tone: "text-emerald-300" },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 backdrop-blur"
              >
                <p className={`text-2xl font-bold ${item.tone}`}>{item.value}</p>
                <p className="mt-0.5 text-[11px] font-medium uppercase tracking-wide text-ink-400">
                  {item.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Quick actions">
        {[
          {
            href: "/dashboard/complaints/new",
            icon: PlusCircle,
            title: "Register a complaint",
            note: `${stats.pending} pending · ${stats.resolved} resolved`,
          },
          {
            href: "/dashboard/applications/new",
            icon: FilePlus2,
            title: "Apply for a certificate",
            note: `${applicationStats.pending} in review · ${applicationStats.approved} approved`,
          },
          {
            href: "/dashboard/payments",
            icon: WalletCards,
            title: "Property tax simulator",
            note: outstanding > 0 ? `${formatRupees(outstanding)} outstanding (demo)` : "Add a property to begin",
          },
          {
            href: "/dashboard/applications",
            icon: FileText,
            title: "My applications",
            note: `${applicationStats.total} sent so far`,
          },
        ].map((tile) => (
          <Link
            key={tile.title}
            href={tile.href}
            className="card-hover group flex items-start gap-4 rounded-2xl border border-ink-100 border-t-[3px] border-t-orange-500 bg-white p-5 shadow-soft"
          >
            <span className="grid h-11 w-11 shrink-0 place-items-center bg-orange-50 text-orange-700">
              <tile.icon className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="block text-sm font-bold text-ink-900">{tile.title}</span>
              <span className="mt-1 block text-xs text-ink-500">{tile.note}</span>
            </span>
          </Link>
        ))}
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.55fr_1fr]">
        <div className="space-y-6">
          {/* Recent activity */}
          <section className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft sm:p-6">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-ink-900">Recent activity</h2>
                <p className="mt-0.5 text-xs text-ink-500">
                  Your latest complaints and their current status.
                </p>
              </div>
              <Link
                href="/dashboard/complaints"
                className="inline-flex items-center gap-1 text-sm font-semibold text-brand-700 hover:text-brand-800"
              >
                View all <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {complaints.length === 0 ? (
              <div className="mt-5 rounded-xl border border-dashed border-ink-200 bg-ink-50/60 px-5 py-8 text-center">
                <ClipboardList className="mx-auto h-6 w-6 text-ink-300" />
                <p className="mt-3 text-sm font-semibold text-ink-800">No complaints yet</p>
                <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-ink-500">
                  Register a complaint with a photograph and location — you will receive a reference
                  number to track it.
                </p>
                <Link
                  href="/dashboard/complaints/new"
                  className="mt-4 inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2 text-xs font-semibold text-white"
                >
                  <PlusCircle className="h-3.5 w-3.5" /> Register your first complaint
                </Link>
              </div>
            ) : (
              <ul className="mt-4 divide-y divide-ink-100">
                {complaints.slice(0, 5).map((complaint) => (
                  <li key={complaint.id}>
                    <Link
                      href={`/dashboard/complaints/${complaint.reference}`}
                      className="flex flex-col gap-2 py-3.5 transition hover:bg-ink-50/70 sm:flex-row sm:items-center sm:justify-between sm:gap-4 sm:px-2 sm:-mx-2 sm:rounded-xl"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-ink-900">
                          {complaint.title}
                        </p>
                        <p className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-ink-500">
                          <span className="font-mono">{complaint.reference}</span>
                          <span className="text-ink-200">•</span>
                          <span>{complaint.serviceName}</span>
                          <span className="text-ink-200">•</span>
                          <span>{complaint.area}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] text-ink-400">
                          {timeAgo(complaint.createdAt)}
                        </span>
                        <StatusBadge status={complaint.status} />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Quick shortcuts */}
          <section className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft sm:p-6">
            <h2 className="text-base font-bold text-ink-900">Quick service shortcuts</h2>
            <p className="mt-0.5 text-xs text-ink-500">
              Jump straight into the most frequently raised civic complaints.
            </p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {QUICK_SHORTCUTS.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="group flex items-center gap-3 rounded-xl border border-ink-100 bg-ink-50/50 p-3.5 transition hover:border-brand-200 hover:bg-brand-50/50 hover:shadow-soft"
                >
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white text-brand-700 ring-1 ring-ink-100">
                    <item.icon className="h-4.5 w-4.5" />
                  </span>
                  <span className="min-w-0 flex-1 truncate text-sm font-semibold text-ink-800">
                    {item.label}
                  </span>
          <ArrowRight className="h-4 w-4 shrink-0 text-ink-300 transition group-hover:translate-x-0.5 group-hover:text-brand-600" />
                </Link>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          {/* Notifications */}
          <section className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft sm:p-6">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
                <Bell className="h-4.5 w-4.5 text-brand-600" />
                Notifications
                {unread > 0 && (
                  <span className="rounded-full bg-brand-600 px-2 py-0.5 text-[10px] font-bold text-white">
                    {unread} new
                  </span>
                )}
              </h2>
              <Link
                href="/dashboard/notifications"
                className="text-xs font-semibold text-brand-700 hover:text-brand-800"
              >
                Open inbox
              </Link>
            </div>

            {notifications.length === 0 ? (
              <p className="mt-4 rounded-xl border border-dashed border-ink-200 bg-ink-50/60 px-4 py-6 text-center text-xs text-ink-500">
                No notifications yet. You will be alerted when a complaint status changes or an
                announcement is published.
              </p>
            ) : (
              <ul className="mt-4 space-y-2.5">
                {notifications.map((item) => (
                  <li
                    key={item.id}
                    className={
                      "rounded-xl border px-3.5 py-3 " +
                      (item.isRead
                        ? "border-ink-100 bg-white"
                        : "border-brand-100 bg-brand-50/60")
                    }
                  >
                    <div className="flex items-start gap-2.5">
                      {item.type === "status" ? (
                        <Clock3 className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
                      ) : item.type === "announcement" ? (
                        <MessageSquare className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
                      ) : item.type === "complaint" ? (
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                      ) : (
                        <Bell className="mt-0.5 h-4 w-4 shrink-0 text-ink-400" />
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-ink-900">{item.title}</p>
                        <p className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-ink-500">
                          {item.body}
                        </p>
                        <p className="mt-1 text-[10px] text-ink-400">{timeAgo(item.createdAt)}</p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Profile summary */}
          <section className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft sm:p-6">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
                <User className="h-4.5 w-4.5 text-brand-600" /> Profile
              </h2>
              <Link
                href="/dashboard/profile"
                className="text-xs font-semibold text-brand-700 hover:text-brand-800"
              >
                Manage
              </Link>
            </div>
            <dl className="mt-4 space-y-3 text-sm">
              {[
                { label: "Name", value: user.name },
                { label: "Email", value: user.email },
                { label: "Phone", value: user.phone ?? "Not provided" },
                { label: "Ward", value: user.ward ?? "Not provided" },
                { label: "Member since", value: formatDate(user.createdAt) },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between gap-4">
                  <dt className="text-xs font-medium text-ink-400">{row.label}</dt>
                  <dd className="truncate text-xs font-semibold text-ink-800">{row.value}</dd>
                </div>
              ))}
            </dl>
          </section>

          {/* Assistant nudge */}
          <section className="rounded-2xl border border-brand-100 bg-brand-50 p-5 shadow-soft">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-brand-700 ring-1 ring-brand-100">
              <MessageSquare className="h-3 w-3" /> Citizen guide
            </span>
            <p className="mt-3 text-sm font-semibold text-ink-900">
              Which service do I need for this problem?
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-ink-500">
              Describe the issue in plain language and the assistant will point you to the right
              service, procedure or complaint type.
            </p>
            <Link
              href="/assistant"
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-semibold text-white shadow-glow transition hover:bg-brand-700"
            >
              Open citizen guide <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </section>

          <p className="flex items-start gap-2 px-1 text-[11px] leading-relaxed text-ink-400">
            <CalendarDays className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            All data shown here is prototype sample data created in the demo environment.
          </p>
        </div>
      </div>
    </div>
  );
}
