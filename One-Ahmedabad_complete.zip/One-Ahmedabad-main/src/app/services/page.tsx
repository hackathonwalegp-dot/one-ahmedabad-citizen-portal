import type { Metadata } from "next";
import { Info, ShieldCheck } from "lucide-react";
import { ServiceDirectory } from "@/components/services/service-directory";
import { getServiceCategories, getServices } from "@/lib/data";
import { ensureSeedData } from "@/lib/seed";

export const metadata: Metadata = {
  title: "Municipal services directory",
  description:
    "Search and filter Ahmedabad municipal services with requirements, step-by-step procedure and the official portal for each one.",
};

export const dynamic = "force-dynamic";

export default async function ServicesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string }>;
}) {
  await ensureSeedData();
  const params = await searchParams;
  const query = params.q ?? "";
  const category = params.category ?? "all";

  const [categories, services] = await Promise.all([
    getServiceCategories(),
    getServices({ q: query, category }),
  ]);

  return (
    <div className="bg-ink-50/40">
      <section className="border-b border-ink-100 bg-white">
        <div className="container-page py-10 lg:py-14">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand-600">
            Service directory
          </p>
          <h1 className="mt-2 text-[clamp(1.9rem,3.6vw,2.6rem)] font-bold tracking-tight">
            Municipal services for Ahmedabad residents
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-500">
            Property and taxes, water and drainage, certificates, licences and permissions, civic
            complaints and public facilities — each with the documents to carry, the procedure to
            follow and a clear label on where the actual application happens.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-4 text-[11px] font-medium text-ink-500">
            <span className="inline-flex items-center gap-1.5">
              <Info className="h-3.5 w-3.5 text-brand-600" />
              No fees, timelines or eligibility rules are quoted — AMC publishes those officially.
            </span>
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-brand-600" />
              One Ahmedabad never collects payments or issues certificates.
            </span>
          </div>
        </div>
      </section>

      <div className="container-page py-8 lg:py-10">
        <ServiceDirectory
          categories={categories.map((category) => ({
            slug: category.slug,
            name: category.name,
            description: category.description,
            icon: category.icon,
            accent: category.accent,
          }))}
          initialServices={services.map((service) => ({
            slug: service.slug,
            name: service.name,
            summary: service.summary,
            categoryName: service.categoryName,
            categorySlug: service.categorySlug,
            categoryIcon: service.categoryIcon,
            accent: service.accent,
            handlingMode: service.handlingMode,
            officialPortalUrl: service.officialPortalUrl,
          }))}
          initialQuery={query}
          initialCategory={category}
        />
      </div>
    </div>
  );
}
