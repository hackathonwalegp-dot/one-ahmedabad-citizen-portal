import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  CheckCircle2,
  ClipboardCheck,
  ExternalLink,
  FileText,
  Info,
  ListOrdered,
  MessageSquare,
  MapPin,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";
import { accentStyle, CategoryIcon } from "@/components/ui/category-icon";
import { getServiceBySlug, getServices } from "@/lib/data";
import { PROTOTYPE_ACTIONS } from "@/lib/applications";
import { ensureSeedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

function modeLabel(mode: string) {
  if (mode === "demo") return "Handled inside One Ahmedabad";
  if (mode === "hybrid") return "Explained here · applied on the AMC portal";
  return "Redirected to the official AMC / State portal";
}

function modeTone(mode: string) {
  if (mode === "demo") return "bg-emerald-50 text-emerald-700 ring-emerald-200";
  if (mode === "hybrid") return "bg-amber-50 text-amber-800 ring-amber-200";
  return "bg-ink-100 text-ink-600 ring-ink-200";
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const service = await getServiceBySlug(slug);
  if (!service) return { title: "Service not found" };
  return {
    title: service.name,
    description: service.summary,
  };
}

export default async function ServiceDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  await ensureSeedData();
  const { slug } = await params;
  const service = await getServiceBySlug(slug);
  if (!service) notFound();

  const related = (await getServices({ category: service.categorySlug }))
    .filter((item) => item.slug !== service.slug)
    .slice(0, 4);
  const accent = accentStyle(service.accent);

  return (
    <div className="bg-ink-50/40">
      <section className="border-b border-ink-100 bg-white">
        <div className="container-page py-8 lg:py-12">
          <Link
            href="/services"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-500 transition hover:text-brand-700"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to all services
          </Link>

          <div className="mt-6 flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-2xl">
              <div className="flex flex-wrap items-center gap-2.5">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide ring-1 ring-inset ${accent.chip}`}
                >
                  <CategoryIcon name={service.categoryIcon} className="h-3.5 w-3.5" />
                  {service.categoryName}
                </span>
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1 ring-inset ${modeTone(service.handlingMode)}`}
                >
                  {modeLabel(service.handlingMode)}
                </span>
              </div>

              <h1 className="mt-4 text-[clamp(1.85rem,3.4vw,2.5rem)] font-bold tracking-tight">
                {service.name}
              </h1>
              <p className="mt-3 text-[15px] leading-relaxed text-ink-600">{service.description}</p>
            </div>

            <div className="flex shrink-0 flex-col gap-2.5 sm:flex-row lg:flex-col">
              {service.handlingMode === "demo" ? (
                <Link
                  href={`/dashboard/complaints/new?category=${service.slug}`}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700"
                >
                  <ClipboardCheck className="h-4 w-4" />
                  Register this request
                </Link>
              ) : (
                service.officialPortalUrl && (
                  <a
                    href={service.officialPortalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-ink-950 px-5 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-ink-800"
                  >
                    Open official portal
                    <ExternalLink className="h-4 w-4" />
                  </a>
                )
              )}
              {PROTOTYPE_ACTIONS[service.slug] && (
                <Link
                  href={PROTOTYPE_ACTIONS[service.slug].href}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-orange-600 px-5 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-orange-700"
                >
                  <ClipboardCheck className="h-4 w-4" />
                  {PROTOTYPE_ACTIONS[service.slug].label}
                </Link>
              )}
              <Link
                href="/assistant"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-ink-200 bg-white px-5 py-3 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
              >
                <MessageSquare className="h-4 w-4" />
                Open citizen guide
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container-page grid gap-6 py-8 lg:grid-cols-[1.6fr_1fr] lg:py-10">
        <div className="space-y-6">
          {/* Procedure */}
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
              <ListOrdered className="h-5 w-5 text-brand-600" />
              Procedure
            </h2>
            <ol className="mt-5 space-y-4">
              {service.procedure.map((step, index) => (
                <li key={step} className="flex gap-4">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-50 text-sm font-bold text-brand-700 ring-1 ring-brand-100">
                    {index + 1}
                  </span>
                  <p className="pt-1 text-sm leading-relaxed text-ink-700">{step}</p>
                </li>
              ))}
            </ol>
          </section>

          {/* Requirements */}
          <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
              <CheckCircle2 className="h-5 w-5 text-brand-600" />
              Who should apply and what to prepare
            </h2>
            <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
              {service.requirements.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-2.5 rounded-xl bg-ink-50/70 px-3.5 py-3 text-sm text-ink-700"
                >
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" />
                  {item}
                </li>
              ))}
            </ul>
          </section>

          {/* Documents */}
          {service.documents.length > 0 && (
            <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
              <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
                <FileText className="h-5 w-5 text-brand-600" />
                Documents to carry
              </h2>
              <p className="mt-1.5 text-xs text-ink-500">
                Keep originals plus one photocopy of each. The exact list is confirmed by the
                issuing office.
              </p>
              <ul className="mt-4 grid gap-2.5 sm:grid-cols-3">
                {service.documents.map((document) => (
                  <li
                    key={document}
                    className="rounded-xl border border-ink-100 px-3.5 py-3 text-sm font-medium text-ink-700"
                  >
                    {document}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Related */}
          {related.length > 0 && (
            <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
              <h2 className="text-lg font-bold text-ink-900">Related services</h2>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {related.map((item) => (
                  <Link
                    key={item.slug}
                    href={`/services/${item.slug}`}
                    className="group flex items-center justify-between gap-3 rounded-xl border border-ink-100 px-4 py-3 transition hover:border-brand-200 hover:bg-brand-50/40"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-ink-900">
                        {item.name}
                      </span>
                      <span className="block text-[11px] uppercase tracking-wide text-ink-400">
                        {item.categoryName}
                      </span>
                    </span>
                    <ArrowRight className="h-4 w-4 shrink-0 text-ink-300 transition group-hover:translate-x-0.5 group-hover:text-brand-600" />
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="text-sm font-bold text-ink-900">Where to go</h2>
            <p className="mt-2 flex items-start gap-2 text-sm leading-relaxed text-ink-600">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
              {service.office ?? "Ahmedabad Municipal Corporation office"}
            </p>
            {service.officialPortalUrl && (
              <a
                href={service.officialPortalUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-ink-200 px-4 py-2.5 text-xs font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
              >
                <Building2 className="h-3.5 w-3.5" />
                Official AMC portal
                <ExternalLink className="h-3 w-3" />
              </a>
            )}
          </div>

          <div className="rounded-2xl border border-brand-100 bg-brand-50/60 p-5">
            <h2 className="flex items-center gap-2 text-sm font-bold text-brand-900">
              <ShieldCheck className="h-4 w-4" />
              How this service is handled
            </h2>
            <p className="mt-2 text-xs leading-relaxed text-ink-600">{modeLabel(service.handlingMode)}</p>
            <ul className="mt-3 space-y-2 text-xs leading-relaxed text-ink-600">
              <li className="flex gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-brand-500" />
                {service.handlingMode === "demo"
                  ? "You can submit the request here and track it with a reference number."
                  : service.handlingMode === "hybrid"
                    ? "This page explains the process; the formal application is made on the official portal."
                    : "This service is completed on the official AMC or State portal only."}
              </li>
              <li className="flex gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-brand-500" />
                No money is collected on this platform and no government certificate is issued here.
              </li>
            </ul>
          </div>

          {service.disclaimer && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
              <h2 className="flex items-center gap-2 text-sm font-bold text-amber-900">
                <TriangleAlert className="h-4 w-4" />
                Please note
              </h2>
              <p className="mt-2 text-xs leading-relaxed text-amber-900/80">{service.disclaimer}</p>
            </div>
          )}

          <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
            <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
              <Info className="h-4 w-4 text-ink-400" />
              About this directory
            </h2>
            <p className="mt-2 text-xs leading-relaxed text-ink-500">
              Content is compiled from publicly available AMC information for the prototype. Where
              fees, timelines or eligibility vary, the official portal is the final word — always
              confirm before you act.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
