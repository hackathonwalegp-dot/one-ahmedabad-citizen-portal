"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AlertCircle, ArrowRight, CheckCircle2, FileText, LoaderCircle, Trash2, Upload } from "lucide-react";
import { APPLICATION_TYPES } from "@/lib/applications";
import { WARDS } from "@/lib/departments";

const input =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

export function ApplicationForm({
  initialType,
  defaultName,
  defaultWard,
  onBehalfOf,
}: {
  initialType?: string;
  defaultName?: string;
  defaultWard?: string;
  /** Set when a service-centre operator files for a citizen. */
  onBehalfOf?: { id: number; name: string };
}) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState({
    type: APPLICATION_TYPES.some((item) => item.name === initialType) ? (initialType as string) : "",
    applicantName: defaultName ?? "",
    ward: defaultWard ?? "",
    details: "",
  });
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  const info = useMemo(() => APPLICATION_TYPES.find((item) => item.name === form.type), [form.type]);

  function update(key: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
    setFieldErrors((current) => {
      if (!current[key]) return current;
      const next = { ...current };
      delete next[key];
      return next;
    });
  }

  function pickFile(event: React.ChangeEvent<HTMLInputElement>) {
    const picked = event.target.files?.[0];
    if (!picked) return;
    if (picked.size > 5 * 1024 * 1024) {
      setError("The document must be under 5 MB.");
      return;
    }
    setError("");
    setFile(picked);
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setFieldErrors({});
    const body = new FormData();
    body.set("type", form.type);
    body.set("applicantName", form.applicantName);
    body.set("ward", form.ward);
    body.set("details", form.details);
    if (file) body.set("document", file);
    if (onBehalfOf) body.set("citizenId", String(onBehalfOf.id));

    setBusy(true);
    try {
      const response = await fetch("/api/applications", { method: "POST", body });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "We could not submit the application.");
        if (Array.isArray(data.issues)) {
          const map: Record<string, string> = {};
          for (const issue of data.issues) map[issue.path] = issue.message;
          setFieldErrors(map);
        }
        return;
      }
      setDone(data.reference);
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-white p-8 text-center shadow-soft">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-600">
          <CheckCircle2 className="h-7 w-7" />
        </span>
        <h2 className="mt-5 text-xl font-bold text-ink-900">Application submitted</h2>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-ink-500">
          Keep this reference number. It is the only way to find the application later.
        </p>
        <div className="mx-auto mt-5 inline-flex items-center gap-3 rounded-xl bg-ink-950 px-5 py-3.5">
          <span className="text-xs font-medium uppercase tracking-wide text-ink-400">Reference</span>
          <span className="font-mono text-lg font-bold tracking-wide text-white">{done}</span>
        </div>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link
            href={onBehalfOf ? `/centre/requests/${done}` : `/dashboard/applications/${done}`}
            className="ah-button-primary"
          >
            Open this application <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            href={onBehalfOf ? "/centre/assist" : "/dashboard/applications"}
            className="inline-flex min-h-[46px] items-center gap-2 border border-ink-200 px-5 text-sm font-semibold text-ink-700 transition hover:border-orange-300 hover:text-orange-700"
          >
            {onBehalfOf ? "Assist another citizen" : "All my applications"}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-5 rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        {onBehalfOf && (
          <p className="rounded-xl bg-orange-50 px-4 py-3 text-xs font-semibold text-orange-900 ring-1 ring-orange-100">
            Filing on behalf of {onBehalfOf.name}. The citizen is notified in their account.
          </p>
        )}
        {error && (
          <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <div>
          <label htmlFor="type" className="block text-sm font-semibold text-ink-800">Application type</label>
          <select id="type" value={form.type} onChange={(e) => update("type", e.target.value)} className={input}>
            <option value="">Select a type…</option>
            {APPLICATION_TYPES.map((item) => (
              <option key={item.name} value={item.name}>{item.name}</option>
            ))}
          </select>
          {fieldErrors.type && <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.type}</p>}
          {info && <p className="mt-2 rounded-lg bg-ink-50 px-3 py-2 text-xs leading-relaxed text-ink-600">{info.summary}</p>}
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="applicantName" className="block text-sm font-semibold text-ink-800">Applicant name</label>
            <input id="applicantName" value={form.applicantName} onChange={(e) => update("applicantName", e.target.value)} className={input} />
            {fieldErrors.applicantName && <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.applicantName}</p>}
          </div>
          <div>
            <label htmlFor="ward" className="block text-sm font-semibold text-ink-800">Ward / locality</label>
            <select id="ward" value={form.ward} onChange={(e) => update("ward", e.target.value)} className={input}>
              <option value="">Select…</option>
              {WARDS.map((ward) => (
                <option key={ward} value={ward}>{ward}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="details" className="block text-sm font-semibold text-ink-800">Request details</label>
          <textarea
            id="details"
            rows={5}
            value={form.details}
            onChange={(e) => update("details", e.target.value)}
            placeholder="Explain what you need and any registration numbers or dates that help."
            className={`${input} resize-y leading-relaxed`}
          />
          {fieldErrors.details && <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.details}</p>}
        </div>

        <div>
          <p className="text-sm font-semibold text-ink-800">
            Supporting document <span className="font-normal text-ink-400">(optional, PDF or image, up to 5 MB)</span>
          </p>
          <input ref={fileRef} type="file" accept="application/pdf,image/jpeg,image/png,image/webp,image/gif" onChange={pickFile} className="sr-only" id="document" />
          {file ? (
            <div className="mt-2 flex items-center justify-between gap-3 rounded-xl border border-ink-200 bg-ink-50 px-4 py-3">
              <span className="flex min-w-0 items-center gap-2 text-sm text-ink-700">
                <FileText className="h-4 w-4 shrink-0 text-brand-600" />
                <span className="truncate">{file.name}</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  setFile(null);
                  if (fileRef.current) fileRef.current.value = "";
                }}
                className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600"
              >
                <Trash2 className="h-3.5 w-3.5" /> Remove
              </button>
            </div>
          ) : (
            <label htmlFor="document" className="mt-2 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-ink-300 px-4 py-6 text-sm font-semibold text-ink-600 transition hover:border-orange-400 hover:text-orange-700">
              <Upload className="h-4 w-4" /> Choose a file
            </label>
          )}
        </div>

        <button type="submit" disabled={busy} className="ah-button-primary w-full disabled:cursor-not-allowed disabled:opacity-70">
          {busy ? (<><LoaderCircle className="h-4 w-4 animate-spin" /> Submitting…</>) : (<>Submit application <ArrowRight className="h-4 w-4" /></>)}
        </button>
      </div>

      <aside className="space-y-4">
        <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
          <h2 className="text-sm font-bold text-ink-900">Documents usually needed</h2>
          {info ? (
            <ul className="mt-3 space-y-2">
              {info.documents.map((doc) => (
                <li key={doc} className="flex items-start gap-2 text-xs leading-relaxed text-ink-600">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-orange-600" /> {doc}
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-2 text-xs leading-relaxed text-ink-500">Select an application type to see the usual documents.</p>
          )}
        </div>
        <div className="rounded-2xl border border-orange-100 bg-orange-50/70 p-5 text-xs leading-relaxed text-orange-950">
          <p className="font-bold">Prototype notice</p>
          <p className="mt-1.5">
            Applications are stored in this prototype only. No certificate or licence is issued and nothing is forwarded to AMC. Use the official portal for real applications.
          </p>
        </div>
      </aside>
    </form>
  );
}
