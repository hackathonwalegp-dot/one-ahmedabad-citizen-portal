"use client";

import { useMemo, useState } from "react";
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  LoaderCircle,
  Pencil,
  Search,
  TriangleAlert,
} from "lucide-react";
import { accentStyle, CategoryIcon } from "@/components/ui/category-icon";

type ManagedService = {
  slug: string;
  name: string;
  categorySlug: string;
  categoryName: string;
  categoryIcon: string;
  accent: string;
  summary: string;
  description: string;
  requirements: string[];
  procedure: string[];
  documents: string[];
  office: string | null;
  disclaimer: string | null;
  officialPortalUrl: string | null;
  handlingMode: string;
  isActive: boolean;
};

export function ServiceManager({ services }: { services: ManagedService[] }) {
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<Record<string, string | string[] | boolean>>({});

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return services;
    return services.filter(
      (service) =>
        service.name.toLowerCase().includes(term) ||
        service.categoryName.toLowerCase().includes(term) ||
        service.summary.toLowerCase().includes(term),
    );
  }, [services, query]);

  function startEdit(service: ManagedService) {
    setMessage(null);
    setEditing(service.slug);
    setDraft({
      summary: service.summary,
      description: service.description,
      requirements: service.requirements.join("\n"),
      procedure: service.procedure.join("\n"),
      documents: service.documents.join("\n"),
      office: service.office ?? "",
      disclaimer: service.disclaimer ?? "",
      officialPortalUrl: service.officialPortalUrl ?? "",
      handlingMode: service.handlingMode,
      isActive: service.isActive,
    });
  }

  async function save(slug: string) {
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch(`/api/services/${slug}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          summary: draft.summary,
          description: draft.description,
          requirements: toLines(draft.requirements),
          procedure: toLines(draft.procedure),
          documents: toLines(draft.documents),
          office: draft.office,
          disclaimer: draft.disclaimer,
          officialPortalUrl: draft.officialPortalUrl,
          handlingMode: draft.handlingMode,
          isActive: draft.isActive,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "Could not save the service." });
        return;
      }
      setMessage({ type: "ok", text: `“${data.service.name}” updated successfully.` });
      setEditing(null);
    } catch {
      setMessage({ type: "error", text: "Network error — please try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="rounded-2xl border border-ink-100 bg-white p-4 shadow-soft sm:p-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search the service directory"
            aria-label="Search services"
            className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
        </div>
      </div>

      {message && (
        <div
          className={
            "mt-4 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm " +
            (message.type === "ok"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-rose-200 bg-rose-50 text-rose-700")
          }
        >
          {message.type === "ok" ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          ) : (
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
          )}
          {message.text}
        </div>
      )}

      <p className="mt-4 text-xs text-ink-500">
        <span className="font-semibold text-ink-900">{filtered.length}</span> services shown. Edits
        appear immediately on the public service pages and in the AI assistant answers.
      </p>

      <ul className="mt-4 space-y-3">
        {filtered.map((service) => {
          const accent = accentStyle(service.accent);
          const isEditing = editing === service.slug;
          return (
            <li
              key={service.slug}
              className="overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-soft"
            >
              <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
                <div className="flex min-w-0 items-start gap-3.5">
                  <span
                    className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ring-1 ring-inset ${accent.chip}`}
                  >
                    <CategoryIcon name={service.categoryIcon} className="h-4.5 w-4.5" />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-ink-900">{service.name}</p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-ink-500">
                      <span>{service.categoryName}</span>
                      <span className="text-ink-200">•</span>
                      <span className="rounded-full bg-ink-50 px-2 py-0.5 font-semibold uppercase tracking-wide">
                        {service.handlingMode}
                      </span>
                      {!service.isActive && (
                        <span className="rounded-full bg-rose-50 px-2 py-0.5 font-semibold uppercase tracking-wide text-rose-600">
                          Hidden
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex shrink-0 items-center gap-2">
                  {service.officialPortalUrl && (
                    <a
                      href={service.officialPortalUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-lg border border-ink-200 px-2.5 py-2 text-xs font-semibold text-ink-600 transition hover:border-brand-300 hover:text-brand-700"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => (isEditing ? setEditing(null) : startEdit(service))}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-ink-200 px-3 py-2 text-xs font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    {isEditing ? "Close" : "Edit"}
                    {isEditing ? (
                      <ChevronUp className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronDown className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {isEditing && (
                <div className="border-t border-ink-100 bg-ink-50/50 p-4 sm:p-5">
                  <div className="grid gap-4 lg:grid-cols-2">
                    <Field label="Summary" htmlFor={`summary-${service.slug}`}>
                      <textarea
                        id={`summary-${service.slug}`}
                        rows={2}
                        value={String(draft.summary ?? "")}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, summary: event.target.value }))
                        }
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      />
                    </Field>

                    <Field label="Office / responsible desk" htmlFor={`office-${service.slug}`}>
                      <input
                        id={`office-${service.slug}`}
                        value={String(draft.office ?? "")}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, office: event.target.value }))
                        }
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      />
                    </Field>

                    <div className="lg:col-span-2">
                      <Field label="Description" htmlFor={`description-${service.slug}`}>
                        <textarea
                          id={`description-${service.slug}`}
                          rows={4}
                          value={String(draft.description ?? "")}
                          onChange={(event) =>
                            setDraft((current) => ({ ...current, description: event.target.value }))
                          }
                          className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm leading-relaxed text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                        />
                      </Field>
                    </div>

                    <Field
                      label="Procedure (one step per line)"
                      htmlFor={`procedure-${service.slug}`}
                    >
                      <textarea
                        id={`procedure-${service.slug}`}
                        rows={6}
                        value={String(draft.procedure ?? "")}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, procedure: event.target.value }))
                        }
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm leading-relaxed text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      />
                    </Field>

                    <Field
                      label="Requirements (one per line)"
                      htmlFor={`requirements-${service.slug}`}
                    >
                      <textarea
                        id={`requirements-${service.slug}`}
                        rows={6}
                        value={String(draft.requirements ?? "")}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, requirements: event.target.value }))
                        }
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm leading-relaxed text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      />
                    </Field>

                    <Field label="Documents (one per line)" htmlFor={`documents-${service.slug}`}>
                      <textarea
                        id={`documents-${service.slug}`}
                        rows={4}
                        value={String(draft.documents ?? "")}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, documents: event.target.value }))
                        }
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm leading-relaxed text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      />
                    </Field>

                    <Field label="Official portal URL" htmlFor={`portal-${service.slug}`}>
                      <input
                        id={`portal-${service.slug}`}
                        value={String(draft.officialPortalUrl ?? "")}
                        onChange={(event) =>
                          setDraft((current) => ({
                            ...current,
                            officialPortalUrl: event.target.value,
                          }))
                        }
                        placeholder="https://…"
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      />
                    </Field>

                    <Field label="Handling mode" htmlFor={`mode-${service.slug}`}>
                      <select
                        id={`mode-${service.slug}`}
                        value={String(draft.handlingMode ?? "redirect")}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, handlingMode: event.target.value }))
                        }
                        className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                      >
                        <option value="demo">Handled inside One Ahmedabad</option>
                        <option value="hybrid">Explained here · applied on AMC portal</option>
                        <option value="redirect">Official AMC / State portal</option>
                      </select>
                    </Field>

                    <div className="lg:col-span-2">
                      <Field label="Disclaimer / note" htmlFor={`disclaimer-${service.slug}`}>
                        <input
                          id={`disclaimer-${service.slug}`}
                          value={String(draft.disclaimer ?? "")}
                          onChange={(event) =>
                            setDraft((current) => ({ ...current, disclaimer: event.target.value }))
                          }
                          placeholder="e.g. Fees and timelines are published by AMC."
                          className="w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                        />
                      </Field>
                    </div>

                    <label className="flex items-center gap-2.5 text-sm font-medium text-ink-700">
                      <input
                        type="checkbox"
                        checked={Boolean(draft.isActive)}
                        onChange={(event) =>
                          setDraft((current) => ({ ...current, isActive: event.target.checked }))
                        }
                        className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-400"
                      />
                      Visible on the public service directory
                    </label>
                  </div>

                  <div className="mt-5 flex justify-end">
                    <button
                      type="button"
                      onClick={() => save(service.slug)}
                      disabled={busy}
                      className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:opacity-70"
                    >
                      {busy ? (
                        <LoaderCircle className="h-4 w-4 animate-spin" />
                      ) : (
                        <CheckCircle2 className="h-4 w-4" />
                      )}
                      Save service
                    </button>
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function toLines(value: string | string[] | boolean | undefined): string[] {
  if (typeof value !== "string") return [];
  return value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block text-xs font-bold uppercase tracking-wide text-ink-500">
        {label}
      </label>
      <div className="mt-1.5">{children}</div>
    </div>
  );
}
