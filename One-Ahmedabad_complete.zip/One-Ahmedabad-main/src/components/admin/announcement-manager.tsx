"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  LoaderCircle,
  Megaphone,
  Send,
} from "lucide-react";
import { formatDate } from "@/lib/utils";

type Announcement = {
  id: number;
  title: string;
  body: string;
  category: string;
  publishedAt: string;
  createdBy: string | null;
};

export function AnnouncementManager({
  initialAnnouncements,
}: {
  initialAnnouncements: Announcement[];
}) {
  const router = useRouter();
  const [items, setItems] = useState(initialAnnouncements);
  const [form, setForm] = useState({
    title: "",
    category: "Civic services",
    body: "",
    notify: true,
  });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function publish(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch("/api/announcements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: form.title,
          category: form.category,
          body: form.body,
          notifyCitizens: form.notify,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "Could not publish the announcement." });
        return;
      }
      setItems((current) => [
        {
          id: data.announcement.id,
          title: data.announcement.title,
          body: data.announcement.body,
          category: data.announcement.category,
          publishedAt: data.announcement.publishedAt,
          createdBy: data.announcement.createdBy,
        },
        ...current,
      ]);
      setForm({ title: "", category: "Civic services", body: "", notify: true });
      setMessage({
        type: "ok",
        text: form.notify
          ? "Announcement published and sent to all citizens as an in-app notification."
          : "Announcement published.",
      });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Network error — please try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
      <form
        onSubmit={publish}
        className="h-fit rounded-2xl border border-ink-100 bg-white p-6 shadow-soft"
      >
        <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
          <Megaphone className="h-4.5 w-4.5 text-brand-600" />
          Publish an announcement
        </h2>
        <p className="mt-1.5 text-xs leading-relaxed text-ink-500">
          Announcements appear on the public announcements page and, when notifications are enabled,
          in every citizen inbox.
        </p>

        {message && (
          <div
            className={
              "mt-4 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm " +
              (message.type === "ok"
                ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                : "border-rose-200 bg-rose-50 text-rose-700")
            }
          >
            {message.type === "ok" ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            ) : (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            )}
            {message.text}
          </div>
        )}

        <div className="mt-5 space-y-4">
          <div>
            <label htmlFor="ann-title" className="block text-sm font-semibold text-ink-800">
              Title
            </label>
            <input
              id="ann-title"
              value={form.title}
              onChange={(event) => setForm((c) => ({ ...c, title: event.target.value }))}
              placeholder="e.g. Monsoon drainage desilting completed in Zone 3"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>

          <div>
            <label htmlFor="ann-category" className="block text-sm font-semibold text-ink-800">
              Category
            </label>
            <select
              id="ann-category"
              value={form.category}
              onChange={(event) => setForm((c) => ({ ...c, category: event.target.value }))}
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            >
              {[
                "Civic services",
                "Service update",
                "Public works",
                "Water & drainage",
                "Property & taxes",
                "Notice",
              ].map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="ann-body" className="block text-sm font-semibold text-ink-800">
              Message
            </label>
            <textarea
              id="ann-body"
              rows={5}
              value={form.body}
              onChange={(event) => setForm((c) => ({ ...c, body: event.target.value }))}
              placeholder="Write the notice residents should read. Keep it factual and avoid promising fees, deadlines or eligibility rules."
              className="mt-1.5 w-full resize-y rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm leading-relaxed text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>

          <label className="flex items-center gap-2.5 text-sm font-medium text-ink-700">
            <input
              type="checkbox"
              checked={form.notify}
              onChange={(event) => setForm((c) => ({ ...c, notify: event.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-400"
            />
            Send an in-app notification to all citizens
          </label>
        </div>

        <button
          type="submit"
          disabled={busy}
          className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70"
        >
          {busy ? (
            <>
              <LoaderCircle className="h-4 w-4 animate-spin" /> Publishing…
            </>
          ) : (
            <>
              <Send className="h-4 w-4" /> Publish announcement
            </>
          )}
        </button>
      </form>

      <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        <h2 className="text-base font-bold text-ink-900">
          Published announcements{" "}
          <span className="ml-1 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-600">
            {items.length}
          </span>
        </h2>

        {items.length === 0 ? (
          <p className="mt-4 rounded-xl border border-dashed border-ink-200 bg-ink-50/60 px-4 py-8 text-center text-xs text-ink-500">
            Nothing published yet.
          </p>
        ) : (
          <ul className="mt-4 space-y-3">
            {items.map((item) => (
              <li key={item.id} className="rounded-xl border border-ink-100 p-4">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="rounded-full bg-brand-50 px-2.5 py-1 text-[11px] font-semibold text-brand-700 ring-1 ring-brand-100">
                    {item.category}
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-[11px] text-ink-400">
                    <CalendarDays className="h-3 w-3" />
                    {formatDate(item.publishedAt)}
                  </span>
                </div>
                <p className="mt-2 text-sm font-bold text-ink-900">{item.title}</p>
                <p className="mt-1 line-clamp-3 text-xs leading-relaxed text-ink-500">{item.body}</p>
                {item.createdBy && (
                  <p className="mt-2 text-[11px] text-ink-400">Published by {item.createdBy}</p>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
