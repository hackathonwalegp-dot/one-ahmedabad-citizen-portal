"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, Save } from "lucide-react";

const field =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

export function SupportPanel({
  reference,
  status: initialStatus,
  reply: initialReply,
}: {
  reference: string;
  status: string;
  reply: string | null;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(initialStatus);
  const [reply, setReply] = useState(initialReply ?? "");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch("/api/support", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reference, status: reply && status === "Open" ? "Answered" : status, reply }),
      });
      const data = await response.json();
      setMessage(response.ok ? "Saved." : (data.error ?? "Could not save."));
      if (response.ok) router.refresh();
    } catch {
      setMessage("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={save} className="mt-4 grid gap-3 sm:grid-cols-[160px_1fr_auto] sm:items-end">
      <div>
        <label htmlFor={`st-${reference}`} className="block text-xs font-semibold text-ink-700">Status</label>
        <select id={`st-${reference}`} value={status} onChange={(e) => setStatus(e.target.value)} className={field}>
          {["Open", "Answered", "Closed"].map((item) => (<option key={item}>{item}</option>))}
        </select>
      </div>
      <div>
        <label htmlFor={`rp-${reference}`} className="block text-xs font-semibold text-ink-700">Reply</label>
        <textarea id={`rp-${reference}`} rows={2} value={reply} onChange={(e) => setReply(e.target.value)} className={`${field} resize-y`} />
      </div>
      <div className="flex items-center gap-3">
        <button type="submit" disabled={busy} className="ah-button-primary disabled:opacity-70">
          {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
        </button>
        {message && <span className="text-xs font-semibold text-ink-500">{message}</span>}
      </div>
    </form>
  );
}
