"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, LoaderCircle, Save, Send } from "lucide-react";
import { APPLICATION_STATUSES, applicationStatusDescription, isApplicationStatus } from "@/lib/applications";
import { DEPARTMENTS } from "@/lib/departments";

const field =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

export function ApplicationAdminPanel({
  reference,
  currentStatus,
  currentRemark,
  currentAssignee,
}: {
  reference: string;
  currentStatus: string;
  currentRemark: string | null;
  currentAssignee: string | null;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(currentStatus);
  const [remark, setRemark] = useState(currentRemark ?? "");
  const [assignedTo, setAssignedTo] = useState(currentAssignee ?? "");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  const departments: string[] = [...DEPARTMENTS];
  if (assignedTo && !departments.includes(assignedTo)) departments.unshift(assignedTo);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch(`/api/applications/${reference}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, remark, assignedTo }),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "Could not update the application." });
        return;
      }
      setMessage({ type: "ok", text: data.message ?? "Application updated." });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Network error. Please try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
      <h2 className="text-base font-bold text-ink-900">Review decision</h2>
      <p className="mt-1.5 text-xs leading-relaxed text-ink-500">
        Saving writes an entry in the application history and notifies the citizen.
      </p>

      {message && (
        <div
          className={
            "mt-4 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm " +
            (message.type === "ok" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-rose-200 bg-rose-50 text-rose-700")
          }
        >
          {message.type === "ok" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> : <Send className="mt-0.5 h-4 w-4 shrink-0" />}
          {message.text}
        </div>
      )}

      <div className="mt-5 space-y-4">
        <div>
          <label htmlFor="status" className="block text-sm font-semibold text-ink-800">Status</label>
          <select id="status" value={status} onChange={(e) => setStatus(e.target.value)} className={field}>
            {APPLICATION_STATUSES.map((item) => (<option key={item} value={item}>{item}</option>))}
          </select>
          <p className="mt-1.5 text-xs text-ink-500">{isApplicationStatus(status) ? applicationStatusDescription[status] : ""}</p>
        </div>
        <div>
          <label htmlFor="assignedTo" className="block text-sm font-semibold text-ink-800">Department</label>
          <select id="assignedTo" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} className={field}>
            <option value="">Not assigned</option>
            {departments.map((item) => (<option key={item} value={item}>{item}</option>))}
          </select>
        </div>
        <div>
          <label htmlFor="remark" className="block text-sm font-semibold text-ink-800">Remark to the citizen</label>
          <textarea id="remark" rows={4} value={remark} onChange={(e) => setRemark(e.target.value)} placeholder="Explain the decision or the next step." className={`${field} resize-y leading-relaxed`} />
        </div>
      </div>

      <button type="submit" disabled={busy} className="ah-button-primary mt-5 w-full disabled:cursor-not-allowed disabled:opacity-70">
        {busy ? (<><LoaderCircle className="h-4 w-4 animate-spin" /> Saving…</>) : (<><Save className="h-4 w-4" /> Save decision</>)}
      </button>
    </form>
  );
}
