"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, UserPlus } from "lucide-react";
import { WARDS } from "@/lib/departments";

const field =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

export function OperatorForm() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", phone: "", ward: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/operators", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "The account could not be created." });
        return;
      }
      setMessage({ type: "ok", text: `${data.operator.name} can now sign in to the service-centre desk.` });
      setForm({ name: "", email: "", phone: "", ward: "", password: "" });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Network error. Please try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
      <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
        <UserPlus className="h-[18px] w-[18px] text-orange-600" /> Create a service-centre operator
      </h2>
      {message && (
        <p className={"mt-3 rounded-lg px-3 py-2 text-xs font-medium " + (message.type === "ok" ? "bg-emerald-50 text-emerald-800" : "bg-rose-50 text-rose-700")}>
          {message.text}
        </p>
      )}
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="opName" className="block text-sm font-semibold text-ink-800">Full name</label>
          <input id="opName" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={field} />
        </div>
        <div>
          <label htmlFor="opEmail" className="block text-sm font-semibold text-ink-800">Email</label>
          <input id="opEmail" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={field} />
        </div>
        <div>
          <label htmlFor="opPhone" className="block text-sm font-semibold text-ink-800">Mobile <span className="font-normal text-ink-400">(optional)</span></label>
          <input id="opPhone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={field} />
        </div>
        <div>
          <label htmlFor="opWard" className="block text-sm font-semibold text-ink-800">Centre locality</label>
          <select id="opWard" value={form.ward} onChange={(e) => setForm({ ...form, ward: e.target.value })} className={field}>
            <option value="">Select…</option>
            {WARDS.map((item) => (<option key={item}>{item}</option>))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="opPass" className="block text-sm font-semibold text-ink-800">Temporary password</label>
          <input id="opPass" type="password" autoComplete="new-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters with a letter and a number" className={field} />
        </div>
      </div>
      <button type="submit" disabled={busy} className="ah-button-primary mt-5 disabled:opacity-70">
        {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />} Create operator
      </button>
    </form>
  );
}
