"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Camera,
  ChevronRight,
  Filter,
  LoaderCircle,
  MapPin,
  RefreshCw,
  Search,
} from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { formatDateTime } from "@/lib/utils";

type Row = {
  id: number;
  reference: string;
  title: string;
  serviceName: string;
  serviceSlug: string | null;
  area: string;
  ward: string | null;
  status: string;
  photoUrl: string | null;
  createdAt: string;
  updatedAt: string;
};

const STATUS_FILTERS = [
  { value: "all", label: "All" },
  { value: "Submitted", label: "Submitted" },
  { value: "Under Review", label: "Under review" },
  { value: "Assigned", label: "Assigned" },
  { value: "In Progress", label: "In progress" },
  { value: "Resolved", label: "Resolved" },
  { value: "Rejected", label: "Rejected" },
];

export function AdminComplaintList({
  categories,
}: {
  categories: Array<{ slug: string; name: string }>;
}) {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("all");
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");

  async function load() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/complaints");
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "Could not load complaints.");
        return;
      }
      setRows(data.complaints ?? []);
    } catch {
      setError("Network error — could not load the complaint queue.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesStatus = status === "all" || row.status === status;
      const matchesCategory = category === "all" || row.serviceSlug === category;
      const matchesQuery =
        !term ||
        row.title.toLowerCase().includes(term) ||
        row.reference.toLowerCase().includes(term) ||
        row.area.toLowerCase().includes(term) ||
        (row.ward ?? "").toLowerCase().includes(term) ||
        row.serviceName.toLowerCase().includes(term);
      return matchesStatus && matchesCategory && matchesQuery;
    });
  }, [rows, status, category, query]);

  return (
    <div>
      <div className="rounded-2xl border border-ink-100 bg-white p-4 shadow-soft sm:p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search reference, title, area or ward"
              aria-label="Search complaints"
              className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>

          <select
            value={category}
            onChange={(event) => setCategory(event.target.value)}
            aria-label="Filter by service category"
            className="rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-800 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          >
            <option value="all">All services</option>
            {categories.map((item) => (
              <option key={item.slug} value={item.slug}>
                {item.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={load}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-ink-200 px-3.5 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </button>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-400">
            <Filter className="h-3.5 w-3.5" />
            Status
          </span>
          {STATUS_FILTERS.map((filter) => (
            <button
              key={filter.value}
              type="button"
              onClick={() => setStatus(filter.value)}
              className={
                "rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 ring-inset transition " +
                (status === filter.value
                  ? "bg-ink-900 text-white ring-ink-900"
                  : "bg-white text-ink-600 ring-ink-200 hover:ring-ink-300")
              }
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
          {error}
        </div>
      )}

      <div className="mt-4 flex items-center justify-between">
        <p className="text-xs text-ink-500">
          {loading ? (
            <span className="inline-flex items-center gap-2">
              <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> Loading queue…
            </span>
          ) : (
            <>
              <span className="font-semibold text-ink-900">{filtered.length}</span> complaint
              {filtered.length === 1 ? "" : "s"} shown of {rows.length}
            </>
          )}
        </p>
      </div>

      {!loading && filtered.length === 0 && (
        <div className="mt-4 rounded-2xl border border-dashed border-ink-200 bg-white px-6 py-14 text-center">
          <p className="text-sm font-semibold text-ink-900">No complaints match this filter</p>
          <p className="mt-1.5 text-xs text-ink-500">Adjust the status, service or search term.</p>
        </div>
      )}

      <ul className="mt-4 space-y-3">
        {filtered.map((row) => (
          <li key={row.id}>
            <Link
              href={`/admin/complaints/${row.reference}`}
              className="group flex flex-col gap-4 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft transition hover:border-brand-200 hover:shadow-card sm:flex-row sm:items-center sm:justify-between sm:p-5"
            >
              <div className="flex min-w-0 items-start gap-4">
                {row.photoUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={row.photoUrl}
                    alt=""
                    className="h-14 w-14 shrink-0 rounded-xl object-cover ring-1 ring-ink-100"
                  />
                ) : (
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-ink-50 text-ink-300 ring-1 ring-ink-100">
                    <Camera className="h-5 w-5" />
                  </span>
                )}
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-ink-900">{row.title}</p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-ink-500">
                    <span className="font-mono font-medium text-brand-700">{row.reference}</span>
                    <span className="text-ink-200">•</span>
                    <span>{row.serviceName}</span>
                  </p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-2 text-[11px] text-ink-400">
                    <MapPin className="h-3 w-3" />
                    <span>{row.area}</span>
                    {row.ward && (
                      <>
                        <span className="text-ink-200">•</span>
                        <span>{row.ward}</span>
                      </>
                    )}
                    <span className="text-ink-200">•</span>
                    <span>Updated {formatDateTime(row.updatedAt)}</span>
                  </p>
                </div>
              </div>

              <div className="flex shrink-0 items-center justify-between gap-3 border-t border-ink-100 pt-3 sm:border-0 sm:pt-0">
                <StatusBadge status={row.status} />
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-brand-700">
                  Update
                  <ChevronRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                </span>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
