"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, LoaderCircle, Save, Send } from "lucide-react";
import { COMPLAINT_STATUSES, statusMeta, type ComplaintStatus } from "@/lib/complaints";
import { DEPARTMENTS } from "@/lib/departments";

export function ComplaintAdminPanel({
  reference,
  currentStatus,
  currentRemark,
  currentAssignee,
}: {
  reference: string;
  currentStatus: string;
  currentRemark: string | null;
  currentAssignee: string | null;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(currentStatus);
  const [remark, setRemark] = useState(currentRemark ?? "");
  const [assignedTo, setAssignedTo] = useState(currentAssignee ?? "");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch(`/api/complaints/${reference}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, remark, assignedTo }),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "Could not update the complaint." });
        return;
      }
      setMessage({ type: "ok", text: data.message ?? "Complaint updated." });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Network error — please try again." });
    } finally {
      setBusy(false);
    }
  }

  const meta = statusMeta[status as ComplaintStatus] ?? statusMeta.Submitted;

  return (
    <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
      <h2 className="text-base font-bold text-ink-900">Administrative action</h2>
      <p className="mt-1.5 text-xs leading-relaxed text-ink-500">
        Changing the status writes an entry in the complaint history and sends an in-app
        notification to the citizen.
      </p>

      {message && (
        <div
          className={
            "mt-4 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm " +
            (message.type === "ok"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-rose-200 bg-rose-50 text-rose-700")
          }
        >
          {message.type === "ok" ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          ) : (
            <Send className="mt-0.5 h-4 w-4 shrink-0" />
          )}
          {message.text}
        </div>
      )}

      <div className="mt-5 space-y-4">
        <div>
          <label htmlFor="status" className="block text-sm font-semibold text-ink-800">
            Status
          </label>
          <select
            id="status"
            value={status}
            onChange={(event) => setStatus(event.target.value)}
            className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          >
            {COMPLAINT_STATUSES.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
          <p className="mt-1.5 text-xs text-ink-500">{meta.description}</p>
        </div>

        <div>
          <label htmlFor="assignedTo" className="block text-sm font-semibold text-ink-800">
            Assigned department / team <span className="font-normal text-ink-400">(optional)</span>
          </label>
          <input
            id="assignedTo"
            list="department-options"
            value={assignedTo}
            onChange={(event) => setAssignedTo(event.target.value)}
            placeholder="Choose a department or type a team name"
            className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
          <datalist id="department-options">
            {DEPARTMENTS.map((department) => (
              <option key={department} value={department} />
            ))}
          </datalist>
        </div>

        <div>
          <label htmlFor="remark" className="block text-sm font-semibold text-ink-800">
            Administrative remark
          </label>
          <textarea
            id="remark"
            rows={4}
            value={remark}
            onChange={(event) => setRemark(event.target.value)}
            placeholder="Explain the action taken, the next step, or why the complaint was closed."
            className="mt-1.5 w-full resize-y rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm leading-relaxed text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={busy}
        className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70"
      >
        {busy ? (
          <>
            <LoaderCircle className="h-4 w-4 animate-spin" /> Saving…
          </>
        ) : (
          <>
            <Save className="h-4 w-4" /> Save update
          </>
        )}
      </button>
    </form>
  );
}
