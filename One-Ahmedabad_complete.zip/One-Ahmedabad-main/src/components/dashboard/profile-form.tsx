"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  LoaderCircle,
  Save,
  User,
} from "lucide-react";

export function ProfileForm({
  user,
}: {
  user: {
    name: string;
    email: string;
    phone: string | null;
    ward: string | null;
    address: string | null;
  };
}) {
  const router = useRouter();
  const [details, setDetails] = useState({
    name: user.name,
    phone: user.phone ?? "",
    ward: user.ward ?? "",
    address: user.address ?? "",
  });
  const [passwords, setPasswords] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function saveDetails(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(details),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "Could not update the profile." });
        return;
      }
      setMessage({ type: "ok", text: data.message ?? "Profile updated." });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Network error — please try again." });
    } finally {
      setBusy(false);
    }
  }

  async function savePassword(event: React.FormEvent) {
    event.preventDefault();
    setMessage(null);
    if (passwords.newPassword !== passwords.confirmPassword) {
      setMessage({ type: "error", text: "The new passwords do not match." });
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword: passwords.currentPassword,
          newPassword: passwords.newPassword,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage({ type: "error", text: data.error ?? "Could not update the password." });
        return;
      }
      setPasswords({ currentPassword: "", newPassword: "", confirmPassword: "" });
      setMessage({ type: "ok", text: data.message ?? "Password updated." });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Network error — please try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
      <div className="space-y-6">
        <form
          onSubmit={saveDetails}
          className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft"
        >
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <User className="h-4.5 w-4.5 text-brand-600" />
            Personal details
          </h2>
          <p className="mt-1.5 text-xs text-ink-500">
            These details pre-fill your complaints so ward teams reach you faster.
          </p>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="p-name" className="block text-sm font-semibold text-ink-800">
                Full name
              </label>
              <input
                id="p-name"
                value={details.name}
                onChange={(event) =>
                  setDetails((current) => ({ ...current, name: event.target.value }))
                }
                className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>

            <div>
              <label htmlFor="p-email" className="block text-sm font-semibold text-ink-800">
                Email address
              </label>
              <input
                id="p-email"
                value={user.email}
                disabled
                className="mt-1.5 w-full rounded-xl border border-ink-200 bg-ink-50 px-3.5 py-2.5 text-sm text-ink-500 disabled:cursor-not-allowed"
              />
              <p className="mt-1.5 text-[11px] text-ink-400">
                The email is your login identity and is used to track complaints.
              </p>
            </div>

            <div>
              <label htmlFor="p-phone" className="block text-sm font-semibold text-ink-800">
                Phone number
              </label>
              <input
                id="p-phone"
                value={details.phone}
                onChange={(event) =>
                  setDetails((current) => ({ ...current, phone: event.target.value }))
                }
                placeholder="+91 98250 00000"
                className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>

            <div>
              <label htmlFor="p-ward" className="block text-sm font-semibold text-ink-800">
                Ward
              </label>
              <input
                id="p-ward"
                value={details.ward}
                onChange={(event) =>
                  setDetails((current) => ({ ...current, ward: event.target.value }))
                }
                placeholder="e.g. Ward 12"
                className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>

            <div>
              <label htmlFor="p-address" className="block text-sm font-semibold text-ink-800">
                Address
              </label>
              <input
                id="p-address"
                value={details.address}
                onChange={(event) =>
                  setDetails((current) => ({ ...current, address: event.target.value }))
                }
                placeholder="Street, society, city"
                className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:opacity-70"
          >
            {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save details
          </button>
        </form>

        <form
          onSubmit={savePassword}
          className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft"
        >
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <KeyRound className="h-4.5 w-4.5 text-brand-600" />
            Change password
          </h2>
          <p className="mt-1.5 text-xs text-ink-500">
            Passwords are hashed with scrypt on the server — the plain text is never stored.
          </p>

          <div className="mt-5 space-y-4">
            <div>
              <label htmlFor="p-current" className="block text-sm font-semibold text-ink-800">
                Current password
              </label>
              <input
                id="p-current"
                type={showPassword ? "text" : "password"}
                value={passwords.currentPassword}
                onChange={(event) =>
                  setPasswords((current) => ({ ...current, currentPassword: event.target.value }))
                }
                className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="p-new" className="block text-sm font-semibold text-ink-800">
                  New password
                </label>
                <input
                  id="p-new"
                  type={showPassword ? "text" : "password"}
                  value={passwords.newPassword}
                  onChange={(event) =>
                    setPasswords((current) => ({ ...current, newPassword: event.target.value }))
                  }
                  placeholder="At least 8 characters"
                  className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                />
              </div>
              <div>
                <label htmlFor="p-confirm" className="block text-sm font-semibold text-ink-800">
                  Confirm new password
                </label>
                <input
                  id="p-confirm"
                  type={showPassword ? "text" : "password"}
                  value={passwords.confirmPassword}
                  onChange={(event) =>
                    setPasswords((current) => ({
                      ...current,
                      confirmPassword: event.target.value,
                    }))
                  }
                  className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="mt-5 inline-flex items-center gap-2 rounded-xl border border-ink-200 px-5 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700 disabled:opacity-70"
          >
            {busy ? (
              <LoaderCircle className="h-4 w-4 animate-spin" />
            ) : (
              <KeyRound className="h-4 w-4" />
            )}
            Update password
          </button>
        </form>
      </div>

      <aside>
        {message && (
          <div
            className={
              "mb-4 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm " +
              (message.type === "ok"
                ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                : "border-rose-200 bg-rose-50 text-rose-700")
            }
          >
            {message.type === "ok" ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            ) : (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            )}
            {message.text}
          </div>
        )}

        <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
          <h2 className="text-sm font-bold text-ink-900">Account security</h2>
          <ul className="mt-3 space-y-2.5 text-xs leading-relaxed text-ink-600">
            {[
              "Passwords are stored as a salted scrypt hash — never as plain text.",
              "Sessions live in the database and are referenced by an httpOnly cookie.",
              "Citizens can only open their own complaints — access is checked on every request.",
              "The administrator console requires the admin role and is blocked for citizen accounts.",
            ].map((item) => (
              <li key={item} className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                {item}
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => setShowPassword((value) => !value)}
            className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-ink-500 hover:text-ink-800"
          >
            {showPassword ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            {showPassword ? "Hide password fields" : "Show password fields"}
          </button>
        </div>
      </aside>
    </div>
  );
}
