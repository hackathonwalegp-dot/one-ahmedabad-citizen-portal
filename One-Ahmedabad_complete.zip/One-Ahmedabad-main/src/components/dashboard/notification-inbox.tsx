"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Bell,
  CheckCheck,
  CheckCircle2,
  Clock3,
  Inbox,
  LoaderCircle,
  Megaphone,
  MessageSquare,
} from "lucide-react";
import { timeAgo } from "@/lib/utils";

type Item = {
  id: number;
  title: string;
  body: string;
  type: string;
  link: string | null;
  isRead: boolean;
  createdAt: string;
};

const ICONS: Record<string, typeof Bell> = {
  complaint: CheckCircle2,
  status: Clock3,
  announcement: Megaphone,
  system: MessageSquare,
};

export function NotificationInbox({ initialItems }: { initialItems: Item[] }) {
  const [items, setItems] = useState(initialItems);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<"all" | "unread">("all");

  async function patch(body: { id?: number; action: string }) {
    setBusy(true);
    try {
      const response = await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!response.ok) return;
      if (body.action === "markAllRead") {
        setItems((current) => current.map((item) => ({ ...item, isRead: true })));
      } else if (body.id) {
        setItems((current) =>
          current.map((item) =>
            item.id === body.id
              ? { ...item, isRead: body.action === "markRead" }
              : item,
          ),
        );
      }
    } finally {
      setBusy(false);
    }
  }

  const visible = filter === "unread" ? items.filter((item) => !item.isRead) : items;
  const unread = items.filter((item) => !item.isRead).length;

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setFilter("all")}
            className={
              "rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 ring-inset transition " +
              (filter === "all"
                ? "bg-ink-900 text-white ring-ink-900"
                : "bg-white text-ink-600 ring-ink-200 hover:ring-ink-300")
            }
          >
            All ({items.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter("unread")}
            className={
              "rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 ring-inset transition " +
              (filter === "unread"
                ? "bg-brand-600 text-white ring-brand-600"
                : "bg-white text-ink-600 ring-ink-200 hover:ring-ink-300")
            }
          >
            Unread ({unread})
          </button>
        </div>

        <button
          type="button"
          onClick={() => patch({ action: "markAllRead" })}
          disabled={busy || unread === 0}
          className="inline-flex items-center gap-2 rounded-xl border border-ink-200 px-3.5 py-2 text-xs font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700 disabled:opacity-50"
        >
          {busy ? (
            <LoaderCircle className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <CheckCheck className="h-3.5 w-3.5" />
          )}
          Mark all as read
        </button>
      </div>

      {visible.length === 0 ? (
        <div className="mt-4 rounded-2xl border border-dashed border-ink-200 bg-white px-6 py-16 text-center">
          <Inbox className="mx-auto h-7 w-7 text-ink-300" />
          <p className="mt-3 text-sm font-semibold text-ink-900">
            {items.length === 0 ? "No notifications yet" : "Nothing unread"}
          </p>
          <p className="mx-auto mt-1.5 max-w-sm text-xs leading-relaxed text-ink-500">
            You will be notified here when a complaint is submitted, its status changes, an officer
            adds a remark, or a new announcement is published.
          </p>
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {visible.map((item) => {
            const Icon = ICONS[item.type] ?? Bell;
            return (
              <li
                key={item.id}
                className={
                  "rounded-2xl border bg-white p-4 shadow-soft transition sm:p-5 " +
                  (item.isRead
                    ? "border-ink-100"
                    : "border-brand-200 bg-brand-50/30")
                }
              >
                <div className="flex items-start gap-3.5">
                  <span
                    className={
                      "grid h-10 w-10 shrink-0 place-items-center rounded-xl " +
                      (item.isRead
                        ? "bg-ink-50 text-ink-400"
                        : "bg-brand-600 text-white")
                    }
                  >
                    <Icon className="h-4.5 w-4.5" />
                  </span>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-bold text-ink-900">{item.title}</p>
                      {!item.isRead && (
                        <span className="rounded-full bg-brand-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                          New
                        </span>
                      )}
                    </div>
                    <p className="mt-1.5 text-sm leading-relaxed text-ink-600">{item.body}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-3">
                      <span className="text-[11px] text-ink-400">{timeAgo(item.createdAt)}</span>
                      {item.link && (
                        <Link
                          href={item.link}
                          className="text-[11px] font-semibold text-brand-700 hover:text-brand-800"
                        >
                          View details →
                        </Link>
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          patch({
                            id: item.id,
                            action: item.isRead ? "markUnread" : "markRead",
                          })
                        }
                        disabled={busy}
                        className="text-[11px] font-semibold text-ink-500 transition hover:text-ink-800 disabled:opacity-50"
                      >
                        Mark as {item.isRead ? "unread" : "read"}
                      </button>
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
