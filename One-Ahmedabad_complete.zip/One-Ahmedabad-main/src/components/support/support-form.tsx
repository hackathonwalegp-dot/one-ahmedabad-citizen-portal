"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, CheckCircle2, LoaderCircle, Send } from "lucide-react";

const TOPICS = [
  "Complaint status",
  "Application or certificate",
  "Property tax simulator",
  "Account or password",
  "Language or accessibility",
  "Something else",
] as const;

const field =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

export function SupportForm({ defaultName, defaultEmail }: { defaultName: string; defaultEmail: string }) {
  const router = useRouter();
  const [form, setForm] = useState({ name: defaultName, email: defaultEmail, topic: TOPICS[0] as string, message: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [reference, setReference] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "Your request could not be sent.");
        return;
      }
      setReference(data.reference);
      setForm((current) => ({ ...current, message: "" }));
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
      <h2 className="text-base font-bold text-ink-900">Ask the support desk</h2>
      {reference && (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          Request <b className="font-mono">{reference}</b> was logged. A reply will appear below and in your notifications.
        </div>
      )}
      {error && (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /> {error}
        </div>
      )}
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="sName" className="block text-sm font-semibold text-ink-800">Name</label>
          <input id="sName" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={field} />
        </div>
        <div>
          <label htmlFor="sEmail" className="block text-sm font-semibold text-ink-800">Email</label>
          <input id="sEmail" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={field} />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="sTopic" className="block text-sm font-semibold text-ink-800">Topic</label>
          <select id="sTopic" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} className={field}>
            {TOPICS.map((item) => (<option key={item} value={item}>{item}</option>))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="sMessage" className="block text-sm font-semibold text-ink-800">How can we help?</label>
          <textarea id="sMessage" rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={`${field} resize-y leading-relaxed`} />
        </div>
      </div>
      <button type="submit" disabled={busy} className="ah-button-primary mt-5 disabled:cursor-not-allowed disabled:opacity-70">
        {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Send request
      </button>
    </form>
  );
}
