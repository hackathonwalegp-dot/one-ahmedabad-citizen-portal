"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  ExternalLink,
  LoaderCircle,
  Send,
  MessageCircle,
  User,
} from "lucide-react";
import type { AssistantMatch } from "@/lib/assistant";
import { useLocale } from "@/components/site/locale-provider";

type Message = {
  role: "user" | "assistant";
  content: string;
  matches?: AssistantMatch[];
  suggestions?: string[];
};

const OPENING_MESSAGE: Message = {
  role: "assistant",
  content:
    "Namaste! I am the One Ahmedabad citizen service guide. Ask me about any municipal service in plain language — for example “my tap water has been muddy for three days”, “how do I get a birth certificate” or “where do I pay property tax”.\n\nI answer only from the verified service directory and always point you to the official AMC portal for the actual application. I will never guess a fee, a timeline or an eligibility rule.",
  suggestions: [
    "How do I raise a complaint?",
    "Where do I pay property tax?",
    "I need a birth certificate",
    "My streetlight is not working",
  ],
};

export function AssistantChat() {
  const { locale } = useLocale();
  const [messages, setMessages] = useState<Message[]>([OPENING_MESSAGE]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || busy) return;

    const history = messages
      .slice(-8)
      .map((message) => ({ role: message.role, content: message.content }));

    setMessages((current) => [...current, { role: "user", content: trimmed }]);
    setInput("");
    setBusy(true);

    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed, history, locale }),
      });
      const data = await response.json();
      if (!response.ok) {
        setMessages((current) => [
          ...current,
          {
            role: "assistant",
            content: data.error ?? "Something went wrong. Please try again.",
          },
        ]);
        return;
      }
      setMessages((current) => [
        ...current,
        {
          role: "assistant",
          content: data.reply,
          matches: data.matches,
          suggestions: data.suggestions,
        },
      ]);
    } catch {
      setMessages((current) => [
        ...current,
        { role: "assistant", content: "Network error — please try again." },
      ]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-card">
      <div className="flex items-center justify-between gap-3 border-b border-ink-100 bg-ink-950 px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-600/20 text-brand-200">
            <MessageCircle className="h-5 w-5" />
          </span>
          <div>
            <p className="text-sm font-bold text-white">One Ahmedabad service guide</p>
            <p className="text-[11px] text-ink-400">
              Answers grounded in the verified service directory
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400/15 px-2.5 py-1 text-[11px] font-semibold text-emerald-300">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          Service guide
        </span>
      </div>

      <div className="h-[26rem] space-y-4 overflow-y-auto bg-ink-50/40 px-4 py-5 scroll-slim sm:px-6">
        {messages.map((message, index) => (
          <div key={index} className="flex gap-3">
            <span
              className={
                "grid h-8 w-8 shrink-0 place-items-center rounded-xl " +
                (message.role === "assistant"
                  ? "bg-brand-600 text-white"
                  : "bg-white text-ink-600 ring-1 ring-ink-200")
              }
            >
              {message.role === "assistant" ? (
                <MessageCircle className="h-4 w-4" />
              ) : (
                <User className="h-4 w-4" />
              )}
            </span>

            <div className="min-w-0 flex-1">
              <div
                className={
                  "rounded-2xl px-4 py-3 text-sm leading-relaxed " +
                  (message.role === "assistant"
                    ? "bg-white text-ink-700 shadow-soft ring-1 ring-ink-100"
                    : "bg-brand-600 text-white")
                }
              >
                <RichText text={message.content} />
              </div>

              {message.matches && message.matches.length > 0 && (
                <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
                  {message.matches.map((match) => (
                    <div
                      key={match.slug}
                      className="rounded-xl border border-ink-100 bg-white p-3.5 shadow-soft"
                    >
                      <p className="text-xs font-bold text-ink-900">{match.name}</p>
                      <p className="mt-0.5 text-[11px] text-ink-500">{match.categoryName}</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Link
                          href={`/services/${match.slug}`}
                          className="inline-flex items-center gap-1 rounded-lg bg-ink-900 px-2.5 py-1.5 text-[11px] font-semibold text-white transition hover:bg-ink-800"
                        >
                          Open service
                          <ArrowRight className="h-3 w-3" />
                        </Link>
                        <Link
                          href={`/dashboard/complaints/new?category=${match.slug}`}
                          className="inline-flex items-center gap-1 rounded-lg border border-ink-200 px-2.5 py-1.5 text-[11px] font-semibold text-ink-600 transition hover:border-brand-300 hover:text-brand-700"
                        >
                          Register request
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {message.suggestions && message.suggestions.length > 0 && index === messages.length - 1 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {message.suggestions.map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => send(suggestion)}
                      className="rounded-full border border-ink-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-ink-600 transition hover:border-brand-300 hover:text-brand-700"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {busy && (
          <div className="flex gap-3">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">
              <MessageCircle className="h-4 w-4" />
            </span>
            <div className="flex items-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm text-ink-500 shadow-soft ring-1 ring-ink-100">
              <LoaderCircle className="h-4 w-4 animate-spin" />
              Looking up the service directory…
            </div>
          </div>
        )}

        <div ref={endRef} />
      </div>

      <form
        onSubmit={(event) => {
          event.preventDefault();
          send(input);
        }}
        className="border-t border-ink-100 bg-white p-4 sm:p-5"
      >
        <div className="flex items-center gap-2">
          <input
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Describe your civic problem or ask for a service…"
            aria-label="Message the assistant"
            className="flex-1 rounded-xl border border-ink-200 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
          <button
            type="submit"
            disabled={busy || !input.trim()}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Send className="h-4 w-4" />
            <span className="hidden sm:inline">Ask</span>
          </button>
        </div>
        <p className="mt-2.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-ink-400">
          <ExternalLink className="mt-0.5 h-3 w-3 shrink-0" />
          The assistant never invents fees, timelines or eligibility rules — it answers from the
          service directory and links to official AMC portals.
        </p>
      </form>
    </div>
  );
}

function RichText({ text }: { text: string }) {
  const blocks = text.split("\n");

  return (
    <div className="space-y-1.5">
      {blocks.map((line, index) => {
        const trimmed = line.trim();
        if (!trimmed) return <div key={index} className="h-1" />;

        const bullet = trimmed.match(/^[•\-]\s+(.*)$/);
        const numbered = trimmed.match(/^(\d+)\.\s+(.*)$/);

        if (bullet) {
          return (
            <p key={index} className="flex gap-2">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-current opacity-50" />
              <span>{inlineBold(bullet[1])}</span>
            </p>
          );
        }

        if (numbered) {
          return (
            <p key={index} className="flex gap-2">
              <span className="font-semibold opacity-70">{numbered[1]}.</span>
              <span>{inlineBold(numbered[2])}</span>
            </p>
          );
        }

        return <p key={index}>{inlineBold(trimmed)}</p>;
      })}
    </div>
  );
}

function inlineBold(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, index) =>
    part.startsWith("**") && part.endsWith("**") ? (
      <strong key={index} className="font-bold text-ink-900">
        {part.slice(2, -2)}
      </strong>
    ) : (
      <span key={index}>{part}</span>
    ),
  );
}
