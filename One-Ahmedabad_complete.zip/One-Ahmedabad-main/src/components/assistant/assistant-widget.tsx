"use client";

import { useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import Link from "next/link";
import {
  ArrowUpRight, Bot, ChevronDown, LoaderCircle, MessageCircle,
  Mic, Send, ShieldCheck, Sparkles, User, X,
} from "lucide-react";
import { useLocale } from "@/components/site/locale-provider";
import type { AssistantMatch } from "@/lib/assistant";

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  matches?: AssistantMatch[];
  suggestions?: string[];
};

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

type SpeechWindow = Window & {
  SpeechRecognition?: new () => SpeechRecognitionLike;
  webkitSpeechRecognition?: new () => SpeechRecognitionLike;
};

const COPY = {
  en: {
    title: "NagarSetu Assistant", subtitle: "Your city-service guide", welcome: "Namaste! I can help you find municipal services, understand the next steps and locate the right official portal. What would you like help with?", placeholder: "Ask about a city service…", send: "Send", online: "Ready to help", privacy: "Please don't share passwords, OTPs or sensitive identity details.", quick: ["Report a road problem", "Birth certificate", "Track a request"], thinking: "Checking the service directory…", voice: "Speak your question", unavailable: "Voice input is not available in this browser.", disclaimer: "Independent prototype · Not an official AMC channel",
  },
  gu: {
    title: "નગરસેતુ સહાયક", subtitle: "તમારી નાગરિક સેવા માર્ગદર્શિકા", welcome: "નમસ્તે! હું તમને નાગરિક સેવાઓ શોધવામાં, આગળનાં પગલાં સમજવામાં અને યોગ્ય સત્તાવાર પોર્ટલ સુધી પહોંચવામાં મદદ કરી શકું છું. તમને શેમાં મદદ જોઈએ છે?", placeholder: "નાગરિક સેવા વિશે પૂછો…", send: "મોકલો", online: "મદદ માટે તૈયાર", privacy: "પાસવર્ડ, OTP અથવા સંવેદનશીલ ઓળખ વિગતો શેર કરશો નહીં.", quick: ["રસ્તાની સમસ્યા નોંધાવો", "જન્મ પ્રમાણપત્ર", "અરજી ટ્રૅક કરો"], thinking: "સેવા ડિરેક્ટરી તપાસી રહ્યા છીએ…", voice: "તમારો પ્રશ્ન બોલો", unavailable: "આ બ્રાઉઝરમાં વૉઇસ ઇનપુટ ઉપલબ્ધ નથી.", disclaimer: "સ્વતંત્ર પ્રોટોટાઇપ · સત્તાવાર AMC ચેનલ નથી",
  },
  hi: {
    title: "नगरसेतु सहायक", subtitle: "आपकी नागरिक सेवा मार्गदर्शिका", welcome: "नमस्ते! मैं नगर सेवाएँ खोजने, अगले कदम समझने और सही आधिकारिक पोर्टल तक पहुँचने में मदद कर सकता हूँ। आपको किस चीज़ में मदद चाहिए?", placeholder: "नगर सेवा के बारे में पूछें…", send: "भेजें", online: "मदद के लिए तैयार", privacy: "पासवर्ड, OTP या संवेदनशील पहचान विवरण साझा न करें।", quick: ["सड़क की समस्या दर्ज करें", "जन्म प्रमाणपत्र", "आवेदन ट्रैक करें"], thinking: "सेवा निर्देशिका देख रहे हैं…", voice: "अपना सवाल बोलें", unavailable: "इस ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है।", disclaimer: "स्वतंत्र प्रोटोटाइप · आधिकारिक AMC चैनल नहीं",
  },
} as const;

export function AssistantWidget() {
  const { locale } = useLocale();
  const t = COPY[locale];
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceNotice, setVoiceNotice] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) window.setTimeout(() => inputRef.current?.focus(), 100);
  }, [open]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function sendMessage(raw: string) {
    const message = raw.trim();
    if (!message || busy) return;
    const history = messages.slice(-8).map(({ role, content }) => ({ role, content }));
    setMessages((current) => [...current, { role: "user", content: message }]);
    setInput("");
    setBusy(true);
    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, history, locale }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Unable to get an answer right now.");
      setMessages((current) => [...current, {
        role: "assistant",
        content: data.reply || "I couldn't prepare an answer. Please try again.",
        matches: data.matches || [],
        suggestions: data.suggestions || [],
      }]);
    } catch (error) {
      setMessages((current) => [...current, {
        role: "assistant",
        content: error instanceof Error ? error.message : "Network error. Please try again.",
      }]);
    } finally {
      setBusy(false);
    }
  }

  function startVoice() {
    const speechWindow = window as SpeechWindow;
    const Recognition = speechWindow.SpeechRecognition || speechWindow.webkitSpeechRecognition;
    if (!Recognition) {
      setVoiceNotice(t.unavailable);
      return;
    }
    const recognition = new Recognition();
    recognition.lang = locale === "gu" ? "gu-IN" : locale === "hi" ? "hi-IN" : "en-IN";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      const transcript = event.results[0]?.[0]?.transcript || "";
      setInput((current) => current ? `${current} ${transcript}` : transcript);
      setVoiceNotice("");
    };
    recognition.onerror = () => setVoiceNotice(t.unavailable);
    recognition.onend = () => setListening(false);
    setListening(true);
    setVoiceNotice("");
    recognition.start();
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void sendMessage(input);
  }

  return (
    <div className="nag-setu-widget fixed bottom-5 right-5 z-[70] flex flex-col items-end gap-3">
      {open && (
        <section className="nag-setu-panel flex w-[min(410px,calc(100vw-2rem))] flex-col overflow-hidden rounded-[22px] border border-slate-200 bg-white shadow-[0_24px_80px_rgba(8,26,48,.24)]" aria-label="NagarSetu AI assistant">
          <header className="flex items-center justify-between gap-3 bg-[#10233f] px-4 py-4 text-white">
            <div className="flex min-w-0 items-center gap-3">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/10 text-orange-300"><Bot className="h-6 w-6" /></span>
              <div className="min-w-0">
                <p className="truncate text-sm font-bold">{t.title}</p>
                <p className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />{t.online}</p>
              </div>
            </div>
            <button type="button" onClick={() => setOpen(false)} aria-label="Minimise assistant" className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-slate-200 transition hover:bg-white/10 hover:text-white"><ChevronDown className="h-5 w-5" /></button>
          </header>

          <div className="flex items-start gap-2 border-b border-slate-100 bg-[#f8fafc] px-4 py-2.5 text-[10px] leading-4 text-slate-600">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-700" />
            <span>{t.disclaimer}</span>
          </div>

          <div className="nag-setu-messages flex-1 space-y-3 overflow-y-auto bg-[#f5f7fa] px-3 py-4" aria-live="polite">
            {messages.map((message, index) => (
              <div key={`${index}-${message.role}`} className={`flex gap-2 ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg ${message.role === "assistant" ? "bg-[#1d568a] text-white" : "bg-white text-slate-600 ring-1 ring-slate-200"}`}>
                  {message.role === "assistant" ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
                </span>
                <div className={`max-w-[84%] rounded-2xl px-3.5 py-2.5 text-[12px] leading-[1.65] ${message.role === "assistant" ? "rounded-tl-md bg-white text-slate-700 shadow-sm ring-1 ring-slate-100" : "rounded-tr-md bg-[#1d568a] text-white"}`}>
                  <MessageText text={message.content} />
                  {message.matches?.length ? <div className="mt-2 space-y-2">{message.matches.slice(0, 2).map((match) => (
                    <Link key={match.slug} href={`/services/${match.slug}`} onClick={() => setOpen(false)} className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50 p-2 text-left text-[11px] font-semibold text-[#174574] hover:border-[#8fb6d8]">
                      <span className="min-w-0"><span className="block truncate">{match.name}</span><span className="mt-0.5 block font-normal text-slate-500">{match.categoryName}</span></span><ArrowUpRight className="h-4 w-4 shrink-0" />
                    </Link>
                  ))}</div> : null}
                  {message.suggestions?.length && index === messages.length - 1 ? <div className="mt-2 flex flex-wrap gap-1.5">{message.suggestions.slice(0, 3).map((suggestion) => <button key={suggestion} type="button" onClick={() => void sendMessage(suggestion)} className="rounded-full border border-[#d5e2ee] bg-white px-2.5 py-1.5 text-[10px] font-semibold text-[#174574] hover:bg-[#edf4fb]">{suggestion}</button>)}</div> : null}
                </div>
              </div>
            ))}
            {busy && <div className="flex items-center gap-2 pl-9 text-[11px] text-slate-500"><LoaderCircle className="h-3.5 w-3.5 animate-spin" />{t.thinking}</div>}
            <div ref={endRef} />
          </div>

          <form onSubmit={submit} className="border-t border-slate-200 bg-white p-3">
            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-1.5 focus-within:border-[#5d91bd] focus-within:ring-2 focus-within:ring-[#dce9f5]">
              <input ref={inputRef} value={input} onChange={(event) => setInput(event.target.value)} placeholder={t.placeholder} aria-label={t.placeholder} maxLength={600} className="min-w-0 flex-1 bg-transparent px-2 py-2 text-xs text-slate-800 outline-none placeholder:text-slate-400" />
              <button type="button" onClick={startVoice} aria-label={t.voice} title={t.voice} className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg transition ${listening ? "bg-rose-100 text-rose-700" : "text-slate-500 hover:bg-slate-100 hover:text-[#174574]"}`}><Mic className="h-4 w-4" /></button>
              <button type="submit" disabled={busy || !input.trim()} aria-label={t.send} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#e85d37] text-white transition hover:bg-[#c84a2b] disabled:cursor-not-allowed disabled:opacity-45"><Send className="h-4 w-4" /></button>
            </div>
            {voiceNotice ? <p className="mt-1.5 text-[10px] text-rose-600">{voiceNotice}</p> : null}
            <p className="mt-2 px-1 text-[10px] leading-4 text-slate-400">{t.privacy}</p>
          </form>
        </section>
      )}
      <button type="button" onClick={() => { if (!open && messages.length === 0) setMessages([{ role: "assistant", content: t.welcome }]); setOpen((value) => !value); }} aria-label={open ? "Close NagarSetu assistant" : "Open NagarSetu assistant"} aria-expanded={open} className="group flex items-center gap-2 rounded-full bg-[#e85d37] py-2.5 pl-3 pr-4 text-white shadow-[0_10px_30px_rgba(232,93,55,.34)] transition hover:-translate-y-0.5 hover:bg-[#c84a2b]">
        <span className="relative grid h-10 w-10 place-items-center rounded-full bg-white/15"><MessageCircle className="h-5 w-5" /><span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-[#e85d37] bg-emerald-300" /></span>
        <span className="pr-1 text-left"><span className="block text-xs font-bold">{t.title}</span><span className="mt-0.5 block text-[10px] text-white/80">{t.subtitle}</span></span>
        <Sparkles className="ml-1 h-4 w-4 text-orange-100" />
      </button>
    </div>
  );
}

function MessageText({ text }: { text: string }) {
  return <div className="whitespace-pre-wrap break-words">{text.split(/(https?:\/\/[^\s]+)/g).map((part, index) => part.startsWith("http") ? <a key={index} href={part} target="_blank" rel="noreferrer" className="break-all underline underline-offset-2">{part}</a> : part)}</div>;
}
