"use client";

import { useState } from "react";
import Link from "next/link";
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  CircleX,
  LoaderCircle,
  Search,
  ShieldCheck,
} from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { formatDateTime } from "@/lib/utils";

type TrackedComplaint = {
  reference: string;
  title: string;
  serviceName: string;
  area: string;
  ward: string | null;
  status: string;
  statusDescription: string;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
  adminRemark: string | null;
};

export function TrackLookup() {
  const [reference, setReference] = useState("");
  const [email, setEmail] = useState("");
  const [result, setResult] = useState<TrackedComplaint | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setResult(null);
    setBusy(true);
    try {
      const response = await fetch("/api/complaints/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reference, email }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "We could not find that request.");
        return;
      }
      setResult(data.complaint);
    } catch {
      setError("Network error — please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.15fr]">
      <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        <h2 className="text-base font-bold text-ink-900">Enter your details</h2>
        <p className="mt-1.5 text-xs leading-relaxed text-ink-500">
          For your security the reference number alone is not enough — enter the email address used
          when the complaint was registered.
        </p>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="mt-5 space-y-4">
          <div>
            <label htmlFor="reference" className="block text-sm font-semibold text-ink-800">
              Reference number
            </label>
            <input
              id="reference"
              value={reference}
              onChange={(event) => setReference(event.target.value.toUpperCase())}
              placeholder="AMC-2026-482193"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 font-mono text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>
          <div>
            <label htmlFor="track-email" className="block text-sm font-semibold text-ink-800">
              Registered email address
            </label>
            <input
              id="track-email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {busy ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" /> Looking up…
              </>
            ) : (
              <>
                <Search className="h-4 w-4" /> Track request
              </>
            )}
          </button>
        </div>

        <div className="mt-5 flex items-start gap-2 rounded-xl bg-ink-50 px-4 py-3 text-[11px] leading-relaxed text-ink-500">
          <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-600" />
          Signed-in citizens see the full timeline and remarks in their dashboard.
        </div>
      </form>

      <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        {!result ? (
          <div className="flex h-full min-h-[16rem] flex-col items-center justify-center text-center">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-ink-50 text-ink-300">
              <Search className="h-6 w-6" />
            </span>
            <p className="mt-4 text-sm font-semibold text-ink-900">No request loaded yet</p>
            <p className="mx-auto mt-1.5 max-w-xs text-xs leading-relaxed text-ink-500">
              Enter a reference number and the registered email address to see the current status of
              a complaint.
            </p>
          </div>
        ) : (
          <div>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-mono text-xs font-semibold text-brand-700">
                  {result.reference}
                </p>
                <h2 className="mt-1.5 text-lg font-bold tracking-tight text-ink-900">
                  {result.title}
                </h2>
                <p className="mt-1 text-xs text-ink-500">
                  {result.serviceName} · {result.area}
                  {result.ward ? ` · ${result.ward}` : ""}
                </p>
              </div>
              <StatusBadge status={result.status} className="px-3 py-1.5 text-sm" />
            </div>

            <div className="mt-5 flex items-start gap-2.5 rounded-xl bg-ink-50 px-4 py-3.5">
              {result.status === "Resolved" ? (
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
              ) : result.status === "Rejected" ? (
                <CircleX className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
              ) : (
                <Search className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
              )}
              <p className="text-xs leading-relaxed text-ink-700">{result.statusDescription}</p>
            </div>

            {result.adminRemark && (
              <div className="mt-3 rounded-xl border border-brand-100 bg-brand-50/60 px-4 py-3.5">
                <p className="text-xs font-bold uppercase tracking-wide text-brand-800">
                  Administrative remark
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-700">{result.adminRemark}</p>
              </div>
            )}

            <dl className="mt-5 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-ink-100 px-4 py-3">
                <dt className="text-[11px] font-medium uppercase tracking-wide text-ink-400">
                  Raised on
                </dt>
                <dd className="mt-1 text-xs font-semibold text-ink-800">
                  {formatDateTime(result.createdAt)}
                </dd>
              </div>
              <div className="rounded-xl border border-ink-100 px-4 py-3">
                <dt className="text-[11px] font-medium uppercase tracking-wide text-ink-400">
                  Last update
                </dt>
                <dd className="mt-1 text-xs font-semibold text-ink-800">
                  {formatDateTime(result.updatedAt)}
                </dd>
              </div>
            </dl>

            <Link
              href="/login"
              className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 hover:text-brand-800"
            >
              Sign in for the full history <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
