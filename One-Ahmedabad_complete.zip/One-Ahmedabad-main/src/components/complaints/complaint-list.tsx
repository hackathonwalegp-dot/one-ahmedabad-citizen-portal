"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Camera, ChevronRight, Filter, PlusCircle, Search } from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { formatDate } from "@/lib/utils";

export type ComplaintRow = {
  id: number;
  reference: string;
  title: string;
  serviceName: string;
  area: string;
  ward: string | null;
  status: string;
  photoUrl: string | null;
  createdAt: string;
  updatedAt: string;
};

const FILTERS = [
  { value: "all", label: "All" },
  { value: "Submitted", label: "Submitted" },
  { value: "Under Review", label: "Under review" },
  { value: "Assigned", label: "Assigned" },
  { value: "In Progress", label: "In progress" },
  { value: "Resolved", label: "Resolved" },
  { value: "Rejected", label: "Rejected" },
];

export function ComplaintList({
  complaints,
  actionHref = "/dashboard/complaints/new",
  actionLabel = "Register a complaint",
  detailBasePath = "/dashboard/complaints",
}: {
  complaints: ComplaintRow[];
  actionHref?: string;
  actionLabel?: string;
  detailBasePath?: string;
}) {
  const [status, setStatus] = useState("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return complaints.filter((complaint) => {
      const matchesStatus = status === "all" || complaint.status === status;
      const matchesQuery =
        !term ||
        complaint.title.toLowerCase().includes(term) ||
        complaint.reference.toLowerCase().includes(term) ||
        complaint.area.toLowerCase().includes(term) ||
        complaint.serviceName.toLowerCase().includes(term);
      return matchesStatus && matchesQuery;
    });
  }, [complaints, status, query]);

  return (
    <div>
      <div className="rounded-2xl border border-ink-100 bg-white p-4 shadow-soft sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search reference, title or area"
              aria-label="Search complaints"
              className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>
          <Link
            href={actionHref}
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700"
          >
            <PlusCircle className="h-4 w-4" />
            {actionLabel}
          </Link>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-400">
            <Filter className="h-3.5 w-3.5" />
            Status
          </span>
          {FILTERS.map((filter) => (
            <button
              key={filter.value}
              type="button"
              onClick={() => setStatus(filter.value)}
              className={
                "rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 ring-inset transition " +
                (status === filter.value
                  ? "bg-ink-900 text-white ring-ink-900"
                  : "bg-white text-ink-600 ring-ink-200 hover:ring-ink-300")
              }
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      <p className="mt-4 text-xs text-ink-500">
        Showing <span className="font-semibold text-ink-900">{filtered.length}</span> of{" "}
        {complaints.length} complaint{complaints.length === 1 ? "" : "s"}
      </p>

      {filtered.length === 0 ? (
        <div className="mt-4 rounded-2xl border border-dashed border-ink-200 bg-ink-50/60 px-6 py-14 text-center">
          <p className="text-sm font-semibold text-ink-900">Nothing to show here</p>
          <p className="mx-auto mt-1.5 max-w-sm text-xs leading-relaxed text-ink-500">
            {complaints.length === 0
              ? "You have not registered any complaint yet. Raise one and you will receive a reference number."
              : "No complaint matches the current filter. Try a different status or clear the search."}
          </p>
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {filtered.map((complaint) => (
            <li key={complaint.id}>
              <Link
                href={`${detailBasePath}/${complaint.reference}`}
                className="group flex flex-col gap-4 rounded-2xl border border-ink-100 bg-white p-4 shadow-soft transition hover:border-brand-200 hover:shadow-card sm:flex-row sm:items-center sm:justify-between sm:p-5"
              >
                <div className="flex min-w-0 items-start gap-4">
                  {complaint.photoUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={complaint.photoUrl}
                      alt=""
                      className="h-14 w-14 shrink-0 rounded-xl object-cover ring-1 ring-ink-100"
                    />
                  ) : (
                    <span className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-ink-50 text-ink-300 ring-1 ring-ink-100">
                      <Camera className="h-5 w-5" />
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-ink-900">{complaint.title}</p>
                    <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-ink-500">
                      <span className="font-mono font-medium text-brand-700">
                        {complaint.reference}
                      </span>
                      <span className="text-ink-200">•</span>
                      <span>{complaint.serviceName}</span>
                      <span className="text-ink-200">•</span>
                      <span>{complaint.area}</span>
                      {complaint.ward && (
                        <>
                          <span className="text-ink-200">•</span>
                          <span>{complaint.ward}</span>
                        </>
                      )}
                    </p>
                    <p className="mt-1 text-[11px] text-ink-400">
                      Raised on {formatDate(complaint.createdAt)}
                    </p>
                  </div>
                </div>

                <div className="flex shrink-0 items-center justify-between gap-3 border-t border-ink-100 pt-3 sm:border-0 sm:pt-0">
                  <StatusBadge status={complaint.status} />
                  <ChevronRight className="h-4 w-4 text-ink-300 transition group-hover:translate-x-0.5 group-hover:text-brand-600" />
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
