"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  ArrowRight,
  Camera,
  CheckCircle2,
  ImageOff,
  LoaderCircle,
  MapPin,
  Trash2,
  Upload,
} from "lucide-react";

export type ComplaintCategoryOption = {
  slug: string;
  name: string;
  summary: string;
  categoryName: string;
  categoryIcon: string;
  accent: string;
};

export function ComplaintForm({
  categories,
  initialCategory,
  onBehalfOf,
}: {
  categories: ComplaintCategoryOption[];
  initialCategory?: string;
  /** Set when a service-centre operator files for a citizen. */
  onBehalfOf?: { id: number; name: string };
}) {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({
    category: initialCategory ?? "",
    title: "",
    description: "",
    area: "",
    ward: "",
    landmark: "",
    contactPhone: "",
  });
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState<{ reference: string; title: string } | null>(null);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const selected = useMemo(
    () => categories.find((item) => item.slug === form.category),
    [categories, form.category],
  );

  function update(key: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
    setFieldErrors((current) => {
      if (!current[key]) return current;
      const next = { ...current };
      delete next[key];
      return next;
    });
  }

  function pickFile(event: React.ChangeEvent<HTMLInputElement>) {
    const picked = event.target.files?.[0];
    if (!picked) return;
    if (picked.size > 5 * 1024 * 1024) {
      setError("Image size must be under 5 MB.");
      return;
    }
    setError("");
    setFile(picked);
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setFieldErrors({});

    const body = new FormData();
    body.set("category", form.category);
    body.set("title", form.title);
    body.set("description", form.description);
    body.set("area", form.area);
    body.set("ward", form.ward);
    body.set("landmark", form.landmark);
    body.set("contactPhone", form.contactPhone);
    if (file) body.set("photo", file);
    if (onBehalfOf) body.set("citizenId", String(onBehalfOf.id));

    setBusy(true);
    try {
      const response = await fetch("/api/complaints", { method: "POST", body });
      const data = await response.json();

      if (!response.ok) {
        setError(data.error ?? "We could not register the complaint.");
        if (Array.isArray(data.issues)) {
          const map: Record<string, string> = {};
          for (const issue of data.issues) map[issue.path] = issue.message;
          setFieldErrors(map);
        }
        return;
      }

      setSuccess({ reference: data.reference, title: form.title });
      router.refresh();
    } catch {
      setError("Network error — please try again.");
    } finally {
      setBusy(false);
    }
  }

  if (success) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-white p-8 text-center shadow-soft">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-600">
          <CheckCircle2 className="h-7 w-7" />
        </span>
        <h2 className="mt-5 text-xl font-bold text-ink-900">Complaint registered</h2>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-ink-500">
          Your complaint has been submitted to the ward queue. Save the reference number below —
          you can use it to track every status change.
        </p>
        <div className="mx-auto mt-5 inline-flex items-center gap-3 rounded-xl bg-ink-950 px-5 py-3.5">
          <span className="text-xs font-medium uppercase tracking-wide text-ink-400">Reference</span>
          <span className="font-mono text-lg font-bold tracking-wide text-white">
            {success.reference}
          </span>
        </div>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link
            href={onBehalfOf ? `/centre/requests/${success.reference}` : `/dashboard/complaints/${success.reference}`}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700"
          >
            Track this complaint
            <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            href={onBehalfOf ? "/centre/assist" : "/dashboard/complaints"}
            className="inline-flex items-center gap-2 rounded-xl border border-ink-200 px-5 py-3 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
          >
            {onBehalfOf ? "Assist another citizen" : "All my complaints"}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-5 rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        {error && (
          <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <div>
          <label htmlFor="category" className="block text-sm font-semibold text-ink-800">
            Complaint category
          </label>
          <select
            id="category"
            value={form.category}
            onChange={(event) => update("category", event.target.value)}
            className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          >
            <option value="">Select a category…</option>
            {categories.map((category) => (
              <option key={category.slug} value={category.slug}>
                {category.name} — {category.categoryName}
              </option>
            ))}
          </select>
          {fieldErrors.category && (
            <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.category}</p>
          )}
          {selected && (
            <p className="mt-2 rounded-lg bg-ink-50 px-3 py-2 text-xs leading-relaxed text-ink-600">
              {selected.summary}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="title" className="block text-sm font-semibold text-ink-800">
            Short title
          </label>
          <input
            id="title"
            value={form.title}
            onChange={(event) => update("title", event.target.value)}
            placeholder="e.g. Deep pothole near the school gate"
            maxLength={120}
            className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
          <div className="mt-1 flex items-center justify-between">
            {fieldErrors.title ? (
              <p className="text-xs font-medium text-rose-600">{fieldErrors.title}</p>
            ) : (
              <span />
            )}
            <span className="text-[11px] text-ink-400">{form.title.length}/120</span>
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-semibold text-ink-800">
            Description of the issue
          </label>
          <textarea
            id="description"
            value={form.description}
            onChange={(event) => update("description", event.target.value)}
            rows={5}
            maxLength={2000}
            placeholder="Describe what is happening, since when, and the impact on residents or traffic."
            className="mt-1.5 w-full resize-y rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm leading-relaxed text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
          <div className="mt-1 flex items-center justify-between">
            {fieldErrors.description ? (
              <p className="text-xs font-medium text-rose-600">{fieldErrors.description}</p>
            ) : (
              <span />
            )}
            <span className="text-[11px] text-ink-400">{form.description.length}/2000</span>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="area" className="block text-sm font-semibold text-ink-800">
              Area / street / society
            </label>
            <input
              id="area"
              value={form.area}
              onChange={(event) => update("area", event.target.value)}
              placeholder="e.g. Satellite Road, near RBI crossing"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
            {fieldErrors.area && (
              <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.area}</p>
            )}
          </div>
          <div>
            <label htmlFor="ward" className="block text-sm font-semibold text-ink-800">
              Ward <span className="font-normal text-ink-400">(if known)</span>
            </label>
            <input
              id="ward"
              value={form.ward}
              onChange={(event) => update("ward", event.target.value)}
              placeholder="e.g. Ward 12"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="landmark" className="block text-sm font-semibold text-ink-800">
              Landmark <span className="font-normal text-ink-400">(optional)</span>
            </label>
            <input
              id="landmark"
              value={form.landmark}
              onChange={(event) => update("landmark", event.target.value)}
              placeholder="e.g. Opposite City Park Gate 2"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>
          <div>
            <label htmlFor="contactPhone" className="block text-sm font-semibold text-ink-800">
              Contact number <span className="font-normal text-ink-400">(optional)</span>
            </label>
            <input
              id="contactPhone"
              value={form.contactPhone}
              onChange={(event) => update("contactPhone", event.target.value)}
              placeholder="+91 98250 00000"
              className="mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
            />
          </div>
        </div>

        <div>
          <span className="block text-sm font-semibold text-ink-800">
            Photograph <span className="font-normal text-ink-400">(optional, max 5 MB)</span>
          </span>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            onChange={pickFile}
            className="sr-only"
            id="photo"
          />
          {preview ? (
            <div className="mt-2 flex items-center gap-4 rounded-xl border border-ink-200 bg-ink-50/60 p-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={preview}
                alt="Selected complaint photograph preview"
                className="h-20 w-20 rounded-lg object-cover"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-ink-900">{file?.name}</p>
                <p className="mt-0.5 text-xs text-ink-500">
                  {((file?.size ?? 0) / 1024).toFixed(0)} KB ·{" "}
                  {file?.type.replace("image/", "").toUpperCase()}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = "";
                  }}
                  className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Remove image
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="mt-2 flex w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-ink-300 bg-ink-50/50 px-4 py-8 text-center transition hover:border-brand-400 hover:bg-brand-50/40"
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-brand-600 ring-1 ring-ink-100">
                <Camera className="h-5 w-5" />
              </span>
              <span className="text-sm font-semibold text-ink-800">Upload a photograph</span>
              <span className="text-xs text-ink-500">
                A clear photo helps the field team act on the first visit
              </span>
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-5">
          <p className="text-[11px] leading-relaxed text-ink-400">
            This is a prototype workflow — no AMC system receives the complaint.
          </p>
          <button
            type="submit"
            disabled={busy}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {busy ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" /> Submitting…
              </>
            ) : (
              <>
                <Upload className="h-4 w-4" /> Submit complaint
              </>
            )}
          </button>
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
          <h2 className="text-sm font-bold text-ink-900">What happens next</h2>
          <ol className="mt-4 space-y-3.5">
            {[
              "You receive a unique reference number instantly.",
              "The complaint enters the ward queue for verification.",
              "An officer reviews the details and photographs.",
              "You get an in-app notification at every status change.",
            ].map((step, index) => (
              <li key={step} className="flex gap-3">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand-50 text-[11px] font-bold text-brand-700 ring-1 ring-brand-100">
                  {index + 1}
                </span>
                <p className="pt-0.5 text-xs leading-relaxed text-ink-600">{step}</p>
              </li>
            ))}
          </ol>
        </div>

        <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
          <h2 className="flex items-center gap-2 text-sm font-bold text-ink-900">
            <MapPin className="h-4 w-4 text-brand-600" /> Tips for a faster response
          </h2>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-ink-600">
            <li>• Add the nearest landmark so the field team can find the spot.</li>
            <li>• Mention the ward if you know it — it routes the complaint correctly.</li>
            <li>• Upload a daytime photograph showing the scale of the issue.</li>
            <li>• Give a contactable number for verification calls.</li>
          </ul>
        </div>

        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
          <h2 className="flex items-center gap-2 text-sm font-bold text-amber-900">
            <ImageOff className="h-4 w-4" /> Before you submit
          </h2>
          <p className="mt-2 text-xs leading-relaxed text-amber-900/80">
            For emergency situations such as a live electrical hazard or an active collapse, contact
            the relevant emergency service directly. This platform is not monitored in real time.
          </p>
        </div>
      </aside>
    </form>
  );
}
