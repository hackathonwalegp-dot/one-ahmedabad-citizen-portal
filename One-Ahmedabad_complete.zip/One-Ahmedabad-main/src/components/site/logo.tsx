import Link from "next/link";

export function Logo({
  variant = "dark",
  compact = false,
}: {
  variant?: "dark" | "light";
  compact?: boolean;
}) {
  const isLight = variant === "light";
  return (
    <Link href="/" className="group flex items-center gap-3" aria-label="One Ahmedabad home">
      <span className={`relative grid h-11 w-11 shrink-0 place-items-center border-2 ${isLight ? "border-white/40 bg-white/10" : "border-[#f15a36] bg-[#f15a36]"}`}>
        <svg viewBox="0 0 32 32" className="h-7 w-7 text-white" fill="none" aria-hidden="true">
          <path d="M4 25.5h24M7 25V12l9-5 9 5v13M11 25V15h10v10M13.5 15v10M18.5 15v10M4.5 12h23" stroke="currentColor" strokeWidth="1.6" strokeLinecap="square" />
          <path d="M16 3.5v3M13.5 4.5h5M10 10.5h12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="square" />
        </svg>
      </span>
      <span className="leading-none">
        <span className={`block text-[16px] font-extrabold uppercase tracking-[0.035em] ${isLight ? "text-white" : "text-[#10223f]"}`}>
          One Ahmedabad
        </span>
        {!compact && (
          <span className={`mt-1.5 block text-[9px] font-semibold uppercase tracking-[0.18em] ${isLight ? "text-slate-300" : "text-slate-500"}`}>
            Citizen service portal
          </span>
        )}
      </span>
    </Link>
  );
}
