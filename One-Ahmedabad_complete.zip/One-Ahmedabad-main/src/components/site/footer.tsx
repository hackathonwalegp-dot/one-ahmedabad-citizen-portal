import Link from "next/link";
import { ArrowUpRight, ExternalLink, Landmark, MapPin } from "lucide-react";
import { Logo } from "@/components/site/logo";
import { AMC_HOME, AMC_SAMPARK, AMC_WATER, GUJ_RTI } from "@/lib/services-data";

const serviceLinks = [
  { href: "/services?category=property-taxes", label: "Property & taxes" },
  { href: "/services?category=water-drainage", label: "Water & drainage" },
  { href: "/services?category=certificates", label: "Certificates" },
  { href: "/services?category=licences-permissions", label: "Licences & permissions" },
  { href: "/services?category=civic-services", label: "Civic services" },
  { href: "/services?category=public-facilities", label: "Public facilities" },
];

const platformLinks = [
  { href: "/track", label: "Track a request" },
  { href: "/dashboard/complaints/new", label: "Register a complaint" },
  { href: "/dashboard/applications/new", label: "Apply for a certificate" },
  { href: "/dashboard/payments", label: "Property tax simulator" },
  { href: "/dashboard/support", label: "Help & support" },
  { href: "/assistant", label: "NagarSetu AI assistant" },
  { href: "/announcements", label: "City updates" },
  { href: "/register", label: "Create an account" },
];

const externalLinks = [
  { href: AMC_HOME, label: "AMC official website" },
  { href: AMC_SAMPARK, label: "AMC e-Sampark" },
  { href: AMC_WATER, label: "Ahmedabad water department" },
  { href: GUJ_RTI, label: "Gujarat RTI online" },
];

export function Footer() {
  return (
    <footer className="site-footer mt-0">
      <div className="container-page grid gap-10 py-14 lg:grid-cols-[1.45fr_1fr_1fr_1.1fr]">
        <div>
          <Logo variant="light" />
          <p className="mt-5 max-w-sm text-sm leading-7 text-slate-300">
            A single, easy-to-navigate starting point for Ahmedabad's municipal services, civic information and citizen support.
          </p>
          <div className="mt-5 flex items-start gap-2 border-l-2 border-orange-500 bg-white/5 p-3 text-xs leading-6 text-slate-300">
            <Landmark className="mt-0.5 h-4 w-4 shrink-0 text-orange-300" />
            <span><strong className="text-white">Prototype notice:</strong> One Ahmedabad is an independent hackathon concept, not an official AMC website. Payments and government certificates are not processed here.</span>
          </div>
        </div>
        <div>
          <h3 className="footer-heading">Explore services</h3>
          <ul className="mt-4 space-y-3 text-sm">
            {serviceLinks.map((link) => <li key={link.href}><Link href={link.href} className="footer-link">{link.label}</Link></li>)}
          </ul>
        </div>
        <div>
          <h3 className="footer-heading">Citizen tools</h3>
          <ul className="mt-4 space-y-3 text-sm">
            {platformLinks.map((link) => <li key={link.href}><Link href={link.href} className="footer-link">{link.label}</Link></li>)}
          </ul>
        </div>
        <div>
          <h3 className="footer-heading">Official portals</h3>
          <ul className="mt-4 space-y-3 text-sm">
            {externalLinks.map((link) => (
              <li key={link.href}><a href={link.href} target="_blank" rel="noreferrer" className="footer-link inline-flex items-center gap-2"><span>{link.label}</span><ExternalLink className="h-3 w-3" /></a></li>
            ))}
          </ul>
          <a href="https://ahmedabad.nic.in/" target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 border-b border-white/30 pb-1 text-xs font-semibold text-white hover:border-orange-400 hover:text-orange-200">
            Ahmedabad district portal <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
          <p className="mt-5 flex items-start gap-2 text-xs leading-6 text-slate-400"><MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-orange-300" /> Ahmedabad, Gujarat, India</p>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-page flex flex-col items-start justify-between gap-3 py-5 text-[11px] text-slate-400 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} One Ahmedabad · Independent civic-service prototype</p>
          <p>Always verify fees, eligibility and official procedures on the relevant government portal.</p>
        </div>
      </div>
    </footer>
  );
}
