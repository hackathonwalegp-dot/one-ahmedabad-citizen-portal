"use client";

import { useLocale } from "@/components/site/locale-provider";
import { UI_TEXT } from "@/lib/ui-text";

/** Hook returning a translate function for the keys in `lib/ui-text.ts`. */
export function useT() {
  const { locale } = useLocale();
  return (key: string) => UI_TEXT[key]?.[locale] ?? UI_TEXT[key]?.en ?? key;
}

/** Inline translated text for use inside server-rendered pages. */
export function T({ k }: { k: string }) {
  const t = useT();
  return <>{t(k)}</>;
}
