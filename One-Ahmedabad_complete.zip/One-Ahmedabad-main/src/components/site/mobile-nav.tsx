"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Building2, LogIn, Menu, ShieldCheck, User, X } from "lucide-react";
import type { PublicUser } from "@/lib/auth";
import { useLocale } from "@/components/site/locale-provider";

export type NavLink = {
  href: string;
  label: string;
};

export function MobileNav({
  links,
  user,
}: {
  links: NavLink[];
  user: PublicUser | null;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const { locale } = useLocale();
  const navLabel = (label: string) => ({
    "Municipal services": locale === "gu" ? "સેવાઓ" : locale === "hi" ? "सेवाएँ" : "Services",
    "Track a complaint": locale === "gu" ? "ફરિયાદ ટ્રૅક કરો" : locale === "hi" ? "शिकायत ट्रैक करें" : "Track complaint",
    "Track a request": locale === "gu" ? "વિનંતી ટ્રૅક કરો" : locale === "hi" ? "अनुरोध ट्रैक करें" : "Track request",
    "My requests": locale === "gu" ? "મારી વિનંતીઓ" : locale === "hi" ? "मेरे अनुरोध" : "My requests",
    "Search requests": locale === "gu" ? "વિનંતીઓ શોધો" : locale === "hi" ? "अनुरोध खोजें" : "Search requests",
    "My complaints": locale === "gu" ? "મારી ફરિયાદો" : locale === "hi" ? "मेरी शिकायतें" : "My complaints",
    Announcements: locale === "gu" ? "શહેરના સમાચાર" : locale === "hi" ? "शहर अपडेट" : "City updates",
    "AI assistant": locale === "gu" ? "નગરસેતુ AI" : locale === "hi" ? "नगरसेतु AI" : "NagarSetu AI",
  } as Record<string, string>)[label] ?? label;
  const ui = locale === "gu"
    ? { signed: "આ રીતે લૉગ ઇન:", dashboard: "મારું ડેશબોર્ડ", admin: "એડમિન કન્સોલ", logout: "લૉગ આઉટ", loggingOut: "લૉગ આઉટ થઈ રહ્યું છે…", signIn: "લૉગ ઇન" }
    : locale === "hi"
      ? { signed: "साइन इन:", dashboard: "मेरा डैशबोर्ड", admin: "एडमिन कंसोल", logout: "साइन आउट", loggingOut: "साइन आउट हो रहा है…", signIn: "साइन इन" }
      : { signed: "Signed in as", dashboard: "My dashboard", admin: "Admin console", logout: "Sign out", loggingOut: "Signing out…", signIn: "Sign in" };
  const router = useRouter();

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.push("/");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="xl:hidden">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label={open ? "Close navigation" : "Open navigation"}
        aria-expanded={open}
        className="grid h-10 w-10 place-items-center rounded-xl border border-ink-200 bg-white text-ink-700 transition hover:border-brand-300"
      >
        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {open && (
        <div className="absolute inset-x-0 top-full z-40 border-b border-ink-100 bg-white/95 shadow-card backdrop-blur">
          <nav className="container-page flex flex-col gap-1 py-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-2.5 text-sm font-semibold text-ink-700 transition hover:bg-ink-50 hover:text-brand-700"
              >
                {navLabel(link.label)}
              </Link>
            ))}

            <div className="my-2 h-px bg-ink-100" />

            {user ? (
              <div className="flex flex-col gap-1">
                <p className="px-3 text-xs font-medium uppercase tracking-wide text-ink-400">
                  {ui.signed} {user.name}
                </p>
                <Link
                  href={user.role === "operator" ? "/centre" : "/dashboard"}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
                >
                  <User className="h-4 w-4" /> {ui.dashboard}
                </Link>
                {user.role === "operator" && (
                  <Link
                    href="/centre"
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
                  >
                    <Building2 className="h-4 w-4" /> {locale === "gu" ? "સેવા કેન્દ્ર" : locale === "hi" ? "सेवा केंद्र" : "Service centre"}
                  </Link>
                )}
                {user.role === "admin" && (
                  <Link
                    href="/admin"
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
                  >
                    <ShieldCheck className="h-4 w-4" /> {ui.admin}
                  </Link>
                )}
                <button
                  type="button"
                  onClick={logout}
                  disabled={busy}
                  className="rounded-xl px-3 py-2.5 text-left text-sm font-semibold text-rose-600 hover:bg-rose-50 disabled:opacity-60"
                >
                  {busy ? ui.loggingOut : ui.logout}
                </button>
              </div>
            ) : (
              <>
              <Link
                href="/login"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 rounded-xl border border-ink-200 px-3 py-2.5 text-sm font-semibold text-ink-700"
              >
                <LogIn className="h-4 w-4" /> {ui.signIn}
              </Link>
              <Link
                href="/register"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-3 py-2.5 text-sm font-semibold text-white shadow-soft"
              >
                {locale === "gu" ? "ખાતું બનાવો" : locale === "hi" ? "खाता बनाएँ" : "Create account"}
              </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </div>
  );
}
