"use client";

import { Globe2 } from "lucide-react";
import { useLocale } from "@/components/site/locale-provider";

export function LanguagePicker({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale } = useLocale();
  return (
    <label className={`language-picker ${compact ? "language-picker-compact" : ""}`}>
      <Globe2 className="h-4 w-4" aria-hidden="true" />
      <span className="sr-only">Choose language</span>
      <select
        value={locale}
        onChange={(event) => setLocale(event.target.value as "en" | "gu" | "hi")}
        aria-label="Choose website language"
      >
        <option value="en">English</option>
        <option value="gu">ગુજરાતી</option>
        <option value="hi">हिन्दी</option>
      </select>
    </label>
  );
}
