"use client";

import Link from "next/link";
import { ArrowUpRight, Building2, ShieldCheck } from "lucide-react";
import { LanguagePicker } from "@/components/site/language-picker";
import { useLocale } from "@/components/site/locale-provider";
import { MobileNav, type NavLink } from "@/components/site/mobile-nav";
import { UserMenu } from "@/components/site/user-menu";
import type { PublicUser } from "@/lib/auth";

const LABELS: Record<string, Record<"en" | "gu" | "hi", string>> = {
  "Municipal services": { en: "Services", gu: "સેવાઓ", hi: "सेवाएँ" },
  "Track a complaint": { en: "Track complaint", gu: "ફરિયાદ ટ્રૅક કરો", hi: "शिकायत ट्रैक करें" },
  "Track a request": { en: "Track request", gu: "વિનંતી ટ્રૅક કરો", hi: "अनुरोध ट्रैक करें" },
  "My requests": { en: "My requests", gu: "મારી વિનંતીઓ", hi: "मेरे अनुरोध" },
  "Search requests": { en: "Search requests", gu: "વિનંતીઓ શોધો", hi: "अनुरोध खोजें" },
  "My complaints": { en: "My complaints", gu: "મારી ફરિયાદો", hi: "मेरी शिकायतें" },
  Announcements: { en: "City updates", gu: "શહેરના સમાચાર", hi: "शहर अपडेट" },
  "AI assistant": { en: "NagarSetu AI", gu: "નગરસેતુ AI", hi: "नगरसेतु AI" },
};

export function PrimaryNavigation({ links, user }: { links: NavLink[]; user: PublicUser | null }) {
  const { locale } = useLocale();
  const copy = locale === "gu"
    ? { signIn: "લૉગ ઇન", create: "ખાતું બનાવો", admin: "એડમિન", centre: "સેવા કેન્દ્ર" }
    : locale === "hi"
      ? { signIn: "साइन इन", create: "खाता बनाएँ", admin: "एडमिन", centre: "सेवा केंद्र" }
      : { signIn: "Sign in", create: "Create account", admin: "Admin", centre: "Service centre" };

  return (
    <>
      <nav className="hidden items-center gap-1 xl:flex" aria-label="Main navigation">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="site-nav-link"
          >
            {LABELS[link.label]?.[locale] ?? link.label}
          </Link>
        ))}
      </nav>
      <div className="flex items-center gap-2.5">
        <LanguagePicker />
        {user ? (
          <>
            {user.role === "admin" && (
              <Link href="/admin" className="admin-nav-link">
                <ShieldCheck className="h-4 w-4" /> {copy.admin}
              </Link>
            )}
            {user.role === "operator" && (
              <Link href="/centre" className="admin-nav-link">
                <Building2 className="h-4 w-4" /> {copy.centre}
              </Link>
            )}
            <UserMenu user={user} />
          </>
        ) : (
          <>
            <Link href="/login" className="hidden rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 sm:inline-flex">
              {copy.signIn}
            </Link>
            <Link href="/register" className="header-cta">
              {copy.create} <ArrowUpRight className="h-4 w-4" />
            </Link>
          </>
        )}
        <MobileNav links={links} user={user} />
      </div>
    </>
  );
}
