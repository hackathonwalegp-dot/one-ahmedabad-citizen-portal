import Link from "next/link";
import { ExternalLink, Landmark, MapPin } from "lucide-react";
import { getCurrentUser, toPublicUser } from "@/lib/auth";
import { AMC_HOME, AMC_SAMPARK } from "@/lib/services-data";
import { Logo } from "@/components/site/logo";
import { PrimaryNavigation } from "@/components/site/primary-navigation";
import type { NavLink } from "@/components/site/mobile-nav";

const NAV_LINKS: NavLink[] = [
  { href: "/services", label: "Municipal services" },
  { href: "/track", label: "Track a request" },
  { href: "/announcements", label: "Announcements" },
  { href: "/assistant", label: "AI assistant" },
];

export async function Header() {
  const user = await getCurrentUser();
  const publicUser = user ? toPublicUser(user) : null;
  const links = publicUser
    ? NAV_LINKS.map((link) => link.href === "/track"
      ? publicUser.role === "operator"
        ? { href: "/centre/track", label: "Search requests" }
        : { href: "/dashboard/applications", label: "My requests" }
      : link)
    : NAV_LINKS;

  return (
    <header className="site-header sticky top-0 z-50 w-full">
      <div className="topline">
        <div className="container-page flex min-h-9 items-center justify-between gap-4 text-[11px] font-medium">
          <p className="flex items-center gap-2 text-slate-200">
            <MapPin className="h-3.5 w-3.5 text-orange-400" />
            <span>Ahmedabad, Gujarat</span>
            <span className="hidden text-slate-500 sm:inline">|</span>
            <span className="hidden sm:inline">A simpler way to navigate city services</span>
          </p>
          <div className="flex items-center gap-4">
            <a href={AMC_HOME} target="_blank" rel="noreferrer" className="topline-link">
              AMC official site <ExternalLink className="h-3 w-3" />
            </a>
            <a href={AMC_SAMPARK} target="_blank" rel="noreferrer" className="topline-link hidden sm:inline-flex">
              e-Sampark <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
      </div>

      <div className="border-b border-slate-200 bg-white">
        <div className="container-page flex min-h-[76px] items-center justify-between gap-5">
          <div className="flex min-w-0 items-center gap-3">
            <Logo />
            <span className="hidden h-9 w-px bg-slate-200 md:block" />
            <span className="hidden max-w-[155px] text-[10px] font-semibold uppercase leading-[1.35] tracking-[0.14em] text-slate-500 md:block">
              Citizen-first city services
            </span>
          </div>
          <PrimaryNavigation links={links} user={publicUser} />
        </div>
      </div>
      <div className="border-b border-orange-100 bg-orange-50/90">
        <div className="container-page flex min-h-8 items-center justify-center gap-2 text-center text-[10px] leading-relaxed text-orange-950 sm:text-[11px]">
          <Landmark className="h-3.5 w-3.5 shrink-0 text-orange-700" />
          <span><strong>Prototype notice:</strong> independent civic-service concept, not an official AMC website.</span>
          <Link href="/services" className="hidden font-bold underline underline-offset-2 sm:inline">Explore services</Link>
        </div>
      </div>
    </header>
  );
}
