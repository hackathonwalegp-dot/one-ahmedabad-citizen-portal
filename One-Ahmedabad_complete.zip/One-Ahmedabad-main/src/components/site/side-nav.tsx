"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  Bell,
  Building2,
  ClipboardList,
  FilePlus2,
  FileText,
  Globe,
  HeartHandshake,
  LayoutDashboard,
  LifeBuoy,
  Megaphone,
  PlusCircle,
  Search,
  User,
  UserPlus,
  Users,
  WalletCards,
} from "lucide-react";
import { useT } from "@/components/site/t";
import { cn } from "@/lib/utils";

const ICONS = {
  overview: LayoutDashboard,
  complaints: ClipboardList,
  newComplaint: PlusCircle,
  applications: FileText,
  newApplication: FilePlus2,
  payments: WalletCards,
  notifications: Bell,
  support: LifeBuoy,
  profile: User,
  citizens: Users,
  departments: Building2,
  reports: BarChart3,
  services: Globe,
  announcements: Megaphone,
  registerCitizen: UserPlus,
  assist: HeartHandshake,
  search: Search,
} as const;

export type SideNavItem = {
  href: string;
  labelKey: string;
  icon: keyof typeof ICONS;
  /** Exact match only (used for section home pages such as /admin). */
  exact?: boolean;
  badge?: number;
};

/** Sidebar on large screens and a scrolling pill row on small screens. */
export function SideNav({ items, variant }: { items: SideNavItem[]; variant: "sidebar" | "pills" }) {
  const pathname = usePathname();
  const t = useT();

  const isActive = (item: SideNavItem) => {
    const base = item.href.split("?")[0];
    if (item.exact) return pathname === base;
    return pathname === base || pathname.startsWith(`${base}/`);
  };

  // "My complaints" must not light up on /dashboard/complaints/new.
  const siblingWins = (item: SideNavItem) =>
    items.some(
      (other) =>
        other !== item &&
        other.href.split("?")[0].length > item.href.split("?")[0].length &&
        isActive(other),
    );

  if (variant === "pills") {
    return (
      <nav className="flex w-max gap-2 pb-1" aria-label="Section navigation">
        {items.map((item) => {
          const Icon = ICONS[item.icon];
          const active = isActive(item) && !siblingWins(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-2 whitespace-nowrap rounded-full border px-4 py-2 text-xs font-semibold shadow-soft",
                active
                  ? "border-orange-500 bg-orange-50 text-orange-700"
                  : "border-ink-200 bg-white text-ink-600",
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {t(item.labelKey)}
            </Link>
          );
        })}
      </nav>
    );
  }

  return (
    <nav className="space-y-1" aria-label="Section navigation">
      {items.map((item) => {
        const Icon = ICONS[item.icon];
        const active = isActive(item) && !siblingWins(item);
        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-xl border-l-[3px] px-3.5 py-2.5 text-sm font-semibold transition",
              active
                ? "border-orange-500 bg-white text-ink-950 shadow-soft"
                : "border-transparent text-ink-600 hover:bg-white hover:text-ink-950 hover:shadow-soft",
            )}
          >
            <Icon className={cn("h-[18px] w-[18px]", active ? "text-orange-600" : "text-ink-400")} />
            {t(item.labelKey)}
            {item.badge ? (
              <span className="ml-auto grid h-5 min-w-5 place-items-center rounded-full bg-orange-600 px-1.5 text-[10px] font-bold text-white">
                {item.badge}
              </span>
            ) : null}
          </Link>
        );
      })}
    </nav>
  );
}
