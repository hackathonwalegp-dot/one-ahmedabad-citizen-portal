"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Building2, ChevronDown, LogOut, LayoutDashboard, ShieldCheck, User } from "lucide-react";
import { initials } from "@/lib/utils";
import type { PublicUser } from "@/lib/auth";

export function UserMenu({ user }: { user: PublicUser }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.push("/");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-haspopup="menu"
        className="flex items-center gap-2 rounded-full border border-ink-200 bg-white py-1.5 pl-1.5 pr-3 text-sm font-medium text-ink-700 transition hover:border-brand-300 hover:shadow-soft"
      >
        <span className="grid h-8 w-8 place-items-center rounded-full bg-ink-900 text-xs font-bold text-white">
          {initials(user.name)}
        </span>
        <span className="hidden max-w-[9rem] truncate sm:inline">{user.name.split(" ")[0]}</span>
        <ChevronDown className="h-4 w-4 text-ink-400" />
      </button>

      {open && (
        <>
          <button
            type="button"
            aria-label="Close menu"
            className="fixed inset-0 z-30 cursor-default"
            onClick={() => setOpen(false)}
          />
          <div
            role="menu"
            className="absolute right-0 z-40 mt-2 w-60 overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-lift"
          >
            <div className="border-b border-ink-100 bg-ink-50/70 px-4 py-3">
              <p className="truncate text-sm font-semibold text-ink-900">{user.name}</p>
              <p className="truncate text-xs text-ink-500">{user.email}</p>
              <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-white px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-brand-700 ring-1 ring-brand-100">
                {user.role === "admin" ? <ShieldCheck className="h-3 w-3" /> : user.role === "operator" ? <Building2 className="h-3 w-3" /> : <User className="h-3 w-3" />}
                {user.role === "admin" ? "Administrator" : user.role === "operator" ? "Service centre" : "Citizen"}
              </span>
            </div>
            <div className="p-1.5">
              <Link
                href={user.role === "operator" ? "/centre" : "/dashboard"}
                onClick={() => setOpen(false)}
                className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium text-ink-700 transition hover:bg-ink-50"
              >
                <LayoutDashboard className="h-4 w-4 text-ink-400" />
                My dashboard
              </Link>
              {(user.role === "admin" || user.role === "operator") && (
                <Link
                  href="/centre"
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium text-ink-700 transition hover:bg-ink-50"
                >
                  <Building2 className="h-4 w-4 text-ink-400" />
                  Service-centre desk
                </Link>
              )}
              {user.role === "admin" && (
                <Link
                  href="/admin"
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium text-ink-700 transition hover:bg-ink-50"
                >
                  <ShieldCheck className="h-4 w-4 text-ink-400" />
                  Admin console
                </Link>
              )}
              <Link
                href="/dashboard/profile"
                onClick={() => setOpen(false)}
                className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium text-ink-700 transition hover:bg-ink-50"
              >
                <User className="h-4 w-4 text-ink-400" />
                Profile settings
              </Link>
              <button
                type="button"
                onClick={logout}
                disabled={busy}
                className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-sm font-medium text-rose-600 transition hover:bg-rose-50 disabled:opacity-60"
              >
                <LogOut className="h-4 w-4" />
                {busy ? "Signing out…" : "Sign out"}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
