"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AlertCircle, ArrowRight, CheckCircle2, KeyRound, LoaderCircle, UserPlus } from "lucide-react";
import { WARDS } from "@/lib/departments";

const field =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

type Created = { id: number; name: string; email: string; password: string };

export function CitizenForm() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", phone: "", email: "", ward: "", address: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<Created | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/centre/citizens", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "The citizen profile could not be created.");
        return;
      }
      setCreated({ id: data.citizen.id, name: data.citizen.name, email: data.citizen.email, password: data.temporaryPassword });
      setForm({ name: "", phone: "", email: "", ward: "", address: "" });
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      {created && (
        <div className="rounded-2xl border border-emerald-200 bg-white p-6 shadow-soft">
          <p className="flex items-center gap-2 text-sm font-bold text-emerald-800">
            <CheckCircle2 className="h-4 w-4" /> Profile created for {created.name}
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-ink-50 px-4 py-3">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">Sign-in email</p>
              <p className="mt-1 break-all font-mono text-sm font-bold text-ink-900">{created.email}</p>
            </div>
            <div className="rounded-xl bg-ink-950 px-4 py-3">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-400"><KeyRound className="h-3 w-3" /> Temporary password</p>
              <p className="mt-1 font-mono text-lg font-bold tracking-wider text-white">{created.password}</p>
            </div>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-ink-500">
            This password is shown once and only its hash is stored. Hand it to the citizen in person and ask them to change it in Profile settings.
          </p>
          <Link href={`/centre/assist?citizen=${created.id}`} className="ah-button-primary mt-4">
            File a request for {created.name.split(" ")[0]} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      )}

      <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
        <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
          <UserPlus className="h-[18px] w-[18px] text-orange-600" /> Register a citizen
        </h2>
        {error && (
          <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /> {error}
          </div>
        )}
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label htmlFor="cName" className="block text-sm font-semibold text-ink-800">Full name</label>
            <input id="cName" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={field} />
          </div>
          <div>
            <label htmlFor="cPhone" className="block text-sm font-semibold text-ink-800">Mobile number</label>
            <input id="cPhone" inputMode="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={field} />
          </div>
          <div>
            <label htmlFor="cEmail" className="block text-sm font-semibold text-ink-800">Email <span className="font-normal text-ink-400">(optional)</span></label>
            <input id="cEmail" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={field} />
          </div>
          <div>
            <label htmlFor="cWard" className="block text-sm font-semibold text-ink-800">Ward / locality</label>
            <select id="cWard" value={form.ward} onChange={(e) => setForm({ ...form, ward: e.target.value })} className={field}>
              <option value="">Select…</option>
              {WARDS.map((item) => (<option key={item}>{item}</option>))}
            </select>
          </div>
          <div>
            <label htmlFor="cAddress" className="block text-sm font-semibold text-ink-800">Address <span className="font-normal text-ink-400">(optional)</span></label>
            <input id="cAddress" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={field} />
          </div>
        </div>
        <p className="mt-3 text-xs text-ink-500">Mobile or email is required. Without an email, a sign-in id is generated from the mobile number.</p>
        <button type="submit" disabled={busy} className="ah-button-primary mt-5 disabled:opacity-70">
          {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />} Create profile
        </button>
      </form>
    </div>
  );
}
