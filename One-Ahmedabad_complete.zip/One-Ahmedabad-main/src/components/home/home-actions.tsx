"use client";

import Link from "next/link";
import { ArrowRight, ClipboardList, FilePlus2, Search, WalletCards } from "lucide-react";
import { useT } from "@/components/site/t";

const TILES = [
  { href: "/dashboard/complaints/new", icon: ClipboardList, title: "home.complaint", body: "home.complaintBody" },
  { href: "/dashboard/applications/new", icon: FilePlus2, title: "home.application", body: "home.applicationBody" },
  { href: "/dashboard/payments", icon: WalletCards, title: "home.payment", body: "home.paymentBody" },
  { href: "/track", icon: Search, title: "home.track", body: "home.trackBody" },
] as const;

/** Entry points into the signed-in features, shown on the homepage. */
export function HomeActions() {
  const t = useT();
  return (
    <section className="container-page pt-16 lg:pt-20" aria-labelledby="home-actions-title">
      <div className="max-w-2xl">
        <p className="ah-eyebrow">{t("home.eyebrow")}</p>
        <h2 id="home-actions-title" className="ah-section-title">{t("home.title")}</h2>
        <p className="mt-3 text-sm leading-7 text-slate-600">{t("home.body")}</p>
      </div>
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {TILES.map((tile) => (
          <Link key={tile.href} href={tile.href} className="ah-service-card group !min-h-[190px]">
            <span className="ah-service-icon"><tile.icon className="h-5 w-5" /></span>
            <h3 className="mt-5 text-base font-bold text-slate-900">{t(tile.title)}</h3>
            <p className="mt-2 flex-1 text-xs leading-6 text-slate-600">{t(tile.body)}</p>
            <span className="ah-text-link mt-4 text-xs">
              <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
            </span>
          </Link>
        ))}
      </div>
      <div className="mt-5 flex flex-col gap-2 border-l-[3px] border-orange-500 bg-slate-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-bold text-slate-900">{t("home.centre")}</p>
          <p className="text-xs text-slate-600">{t("home.centreBody")}</p>
        </div>
        <Link href="/login?next=/centre" className="ah-text-link text-xs">{t("home.centreLink")} <ArrowRight className="h-3.5 w-3.5" /></Link>
      </div>
    </section>
  );
}
