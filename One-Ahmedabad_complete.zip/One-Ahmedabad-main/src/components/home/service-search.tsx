"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Search, Info } from "lucide-react";
import { useLocale } from "@/components/site/locale-provider";

type Suggestion = {
  slug: string;
  name: string;
  categoryName: string;
  handlingMode: string;
};

export function ServiceSearch({ compact = false }: { compact?: boolean }) {
  const [query, setQuery] = useState("");
  const { locale } = useLocale();
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const term = query.trim();
    if (term.length < 2) {
      setSuggestions([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const response = await fetch(`/api/services?q=${encodeURIComponent(term)}&limit=6`);
        const data = await response.json();
        setSuggestions(Array.isArray(data.services) ? data.services : []);
      } catch {
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    }, 220);
    return () => clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    function onClickOutside(event: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(event.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const helperText = useMemo(() => {
    if (locale === "gu") {
      if (loading) return "સેવાઓ શોધી રહ્યા છીએ…";
      if (query.trim().length < 2) return "જેમ કે “પાણી”, “મિલકત વેરો”, “જન્મ પ્રમાણપત્ર”";
      if (!suggestions.length) return "મેળ મળ્યો નથી — બધી સેવાઓ જોવા Enter દબાવો";
      return "";
    }
    if (locale === "hi") {
      if (loading) return "नगर सेवाएँ खोजी जा रही हैं…";
      if (query.trim().length < 2) return "जैसे “पानी”, “संपत्ति कर”, “जन्म प्रमाणपत्र”";
      if (!suggestions.length) return "कोई परिणाम नहीं — सभी सेवाएँ देखने के लिए Enter दबाएँ";
      return "";
    }
    if (loading) return "Searching municipal services…";
    if (query.trim().length < 2) return "Try “water”, “property tax”, “birth certificate”";
    if (!suggestions.length) return "No match yet — press Enter to browse all services";
    return "";
  }, [locale, loading, query, suggestions.length]);

  function submit(event: React.FormEvent) {
    event.preventDefault();
    const term = query.trim();
    router.push(term ? `/services?q=${encodeURIComponent(term)}` : "/services");
    setOpen(false);
  }

  return (
    <div ref={boxRef} className="relative w-full">
      <form onSubmit={submit} className="relative">
        <div className="flex items-center gap-2 rounded-2xl bg-white p-1.5 shadow-lift ring-1 ring-ink-900/5">
          <div className="flex flex-1 items-center gap-2.5 px-3">
            <Search className="h-5 w-5 shrink-0 text-ink-400" />
            <input
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              placeholder={
                compact
                  ? locale === "gu" ? "સેવાઓ શોધો…" : locale === "hi" ? "सेवाएँ खोजें…" : "Search services…"
                  : locale === "gu" ? "મ્યુનિસિપલ સેવા શોધો, જેમ કે પાણીનું જોડાણ"
                    : locale === "hi" ? "नगर सेवा खोजें, जैसे पानी का कनेक्शन"
                      : "Search for a municipal service, e.g. water connection"
              }
              aria-label={locale === "gu" ? "મ્યુનિસિપલ સેવાઓ શોધો" : locale === "hi" ? "नगर सेवाएँ खोजें" : "Search municipal services"}
              className="w-full bg-transparent py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:outline-none sm:text-[15px]"
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 sm:px-5"
          >
            <span className="hidden sm:inline">{locale === "gu" ? "શોધો" : locale === "hi" ? "खोजें" : "Search"}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {helperText && (
          <p className="mt-2.5 flex items-center gap-1.5 px-1 text-xs text-ink-400">
            <Info className="h-3.5 w-3.5" />
            {helperText}
          </p>
        )}
      </form>

      {open && suggestions.length > 0 && (
        <div className="absolute inset-x-0 top-[68px] z-30 overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-lift">
          <ul className="max-h-80 overflow-y-auto scroll-slim">
            {suggestions.map((service) => (
              <li key={service.slug}>
                <button
                  type="button"
                  onClick={() => {
                    router.push(`/services/${service.slug}`);
                    setOpen(false);
                  }}
                  className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition hover:bg-ink-50"
                >
                  <span>
                    <span className="block text-sm font-semibold text-ink-900">{service.name}</span>
                    <span className="block text-xs text-ink-500">{service.categoryName}</span>
                  </span>
                  <span className="shrink-0 rounded-full bg-ink-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-ink-500">
                    {service.handlingMode === "demo" ? "In-platform" : "Official portal"}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
