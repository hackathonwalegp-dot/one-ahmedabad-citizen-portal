"use client";

import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  BellRing,
  Building2,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  FileText,
  MapPinned,
  MessageCircle,
  TrainFront,
  WalletCards,
  Waves,
} from "lucide-react";
import { CategoryIcon } from "@/components/ui/category-icon";
import { HomeActions } from "@/components/home/home-actions";
import { ServiceSearch } from "@/components/home/service-search";
import { useLocale, type Locale } from "@/components/site/locale-provider";

export type HomeCategory = {
  slug: string;
  name: string;
  description: string;
  icon: string;
  accent: string;
  serviceCount: number;
};

export type HomeService = {
  slug: string;
  name: string;
  summary: string;
  handlingMode: string;
  categorySlug: string;
  categoryName: string;
  categoryIcon: string;
  accent: string;
};

export type HomeAnnouncement = {
  id: number;
  title: string;
  body: string;
  category: string;
  publishedAt: string;
};

type Props = {
  stats: { services: number; categories: number; complaintTypes: number };
  categories: HomeCategory[];
  services: HomeService[];
  announcements: HomeAnnouncement[];
  announcementTotal: number;
};

const COPY: Record<Locale, Record<string, string>> = {
  en: {
    city: "AHMEDABAD · GUJARAT",
    title1: "City services,",
    title2: "closer to every citizen.",
    intro: "One place to discover municipal services, raise civic concerns and stay connected with the city you call home.",
    search: "Search property tax, water connection, certificates…",
    browse: "Explore services",
    track: "Track a complaint",
    statsServices: "Services listed",
    statsCategories: "Service categories",
    statsComplaints: "Complaint types",
    popular: "START WITH THE ESSENTIALS",
    popularTitle: "Everyday services, made easier.",
    popularBody: "Find the right service, understand what you need and follow the correct route — without hunting across multiple websites.",
    allServices: "View all services",
    categories: "BROWSE BY NEED",
    categoriesTitle: "What can we help you with?",
    cityLabel: "A CITY WITH ITS OWN CHARACTER",
    cityTitle: "Rooted in heritage. Moving forward together.",
    cityBody: "From the Sabarmati Riverfront to the lanes of the historic walled city, Ahmedabad is shaped by the people who make it their own. One Ahmedabad brings that same local focus to everyday civic services.",
    riverfront: "Explore the Sabarmati Riverfront",
    cityUpdates: "CITY BULLETIN",
    cityUpdatesTitle: "Updates from One Ahmedabad",
    updatesBody: "Notices and service updates published on this prototype. For official orders, always check AMC channels.",
    allUpdates: "All updates",
    how: "A CLEARER WAY TO GET THINGS DONE",
    howTitle: "Three simple steps.",
    howBody: "A clearer route from your question to the right service.",
    step1: "Find your service",
    step1Body: "Search or browse the directory by category and topic.",
    step2: "Choose the right route",
    step2Body: "See what can be done here and what needs an official portal.",
    step3: "Keep your reference close",
    step3Body: "Track demo complaints with a reference number and view status updates.",
    guideLabel: "NEED A LITTLE GUIDANCE?",
    guideTitle: "Not sure where to begin?",
    guideBody: "Ask the citizen guide to find the right service and understand the next steps. It provides guidance from this directory; it does not replace official AMC advice.",
    askGuide: "Open citizen guide",
    signIn: "Sign in",
    register: "Create an account",
    serviceModeDemo: "Track in this prototype",
    serviceModeHybrid: "Guidance here · apply officially",
    serviceModeRedirect: "Continue to official portal",
    platform: "ONE AHMEDABAD",
  },
  gu: {
    city: "અમદાવાદ · ગુજરાત",
    title1: "શહેરની સેવાઓ,",
    title2: "દરેક નાગરિકની નજીક.",
    intro: "મ્યુનિસિપલ સેવાઓ શોધવા, નાગરિક સમસ્યાઓ નોંધાવવા અને તમારા શહેર સાથે જોડાયેલા રહેવા માટે એક જ સ્થળ.",
    search: "મિલકત વેરો, પાણીનું જોડાણ, પ્રમાણપત્ર શોધો…",
    browse: "સેવાઓ જુઓ",
    track: "ફરિયાદ ટ્રૅક કરો",
    statsServices: "સૂચિબદ્ધ સેવાઓ",
    statsCategories: "સેવા વિભાગો",
    statsComplaints: "ફરિયાદના પ્રકારો",
    popular: "જરૂરી સેવાઓથી શરૂઆત કરો",
    popularTitle: "રોજિંદી સેવાઓ, હવે સરળ.",
    popularBody: "યોગ્ય સેવા શોધો, જરૂરી માહિતી સમજો અને સાચો માર્ગ પસંદ કરો — અનેક વેબસાઇટ્સ વચ્ચે ભટક્યા વગર.",
    allServices: "બધી સેવાઓ જુઓ",
    categories: "જરૂરિયાત પ્રમાણે શોધો",
    categoriesTitle: "અમે તમને શેમાં મદદ કરી શકીએ?",
    cityLabel: "પોતાની આગવી ઓળખ ધરાવતું શહેર",
    cityTitle: "વારસામાં મૂળ. સાથે મળીને આગળ.",
    cityBody: "સાબરમતી રિવરફ્રન્ટથી લઈને ઐતિહાસિક જૂના શહેરની પોળો સુધી, અમદાવાદને અહીંના લોકો પોતાની ઓળખ આપે છે. વન અમદાવાદ એ જ સ્થાનિક સમજને રોજિંદી નાગરિક સેવાઓમાં લાવે છે.",
    riverfront: "સાબરમતી રિવરફ્રન્ટ વિશે જાણો",
    cityUpdates: "શહેરની માહિતી",
    cityUpdatesTitle: "વન અમદાવાદના અપડેટ્સ",
    updatesBody: "આ પ્રોટોટાઇપ પર પ્રકાશિત સૂચનાઓ અને સેવા અપડેટ્સ. સત્તાવાર આદેશો માટે AMC ચેનલ્સ તપાસો.",
    allUpdates: "બધા અપડેટ્સ",
    how: "કામ કરવાની વધુ સરળ રીત",
    howTitle: "ત્રણ સરળ પગલાં.",
    howBody: "તમારા પ્રશ્નથી યોગ્ય સેવા સુધીનો સ્પષ્ટ માર્ગ.",
    step1: "સેવા શોધો",
    step1Body: "વિભાગ અને વિષય પ્રમાણે ડિરેક્ટરીમાં શોધો.",
    step2: "યોગ્ય માર્ગ પસંદ કરો",
    step2Body: "અહીં શું થઈ શકે અને કઈ બાબત માટે સત્તાવાર પોર્ટલ જરૂરી છે તે જુઓ.",
    step3: "તમારો રેફરન્સ સાચવો",
    step3Body: "પ્રોટોટાઇપ ફરિયાદને રેફરન્સ નંબરથી ટ્રૅક કરો અને સ્થિતિ જુઓ.",
    guideLabel: "થોડી મદદ જોઈએ છે?",
    guideTitle: "શરૂઆત ક્યાંથી કરવી તે સમજાતું નથી?",
    guideBody: "યોગ્ય સેવા શોધવા અને આગળનાં પગલાં સમજવા માટે નાગરિક માર્ગદર્શિકાનો ઉપયોગ કરો. આ માર્ગદર્શન છે, સત્તાવાર AMC સલાહનો વિકલ્પ નથી.",
    askGuide: "નાગરિક માર્ગદર્શિકા ખોલો",
    signIn: "લૉગ ઇન",
    register: "ખાતું બનાવો",
    serviceModeDemo: "આ પ્રોટોટાઇપમાં ટ્રૅક કરો",
    serviceModeHybrid: "અહીં માર્ગદર્શન · અરજી સત્તાવાર રીતે",
    serviceModeRedirect: "સત્તાવાર પોર્ટલ પર જાઓ",
    platform: "વન અમદાવાદ",
  },
  hi: {
    city: "अहमदाबाद · गुजरात",
    title1: "शहर की सेवाएँ,",
    title2: "हर नागरिक के और करीब।",
    intro: "नगर सेवाएँ खोजने, नागरिक समस्याएँ दर्ज करने और अपने शहर से जुड़े रहने के लिए एक ही जगह।",
    search: "संपत्ति कर, पानी का कनेक्शन, प्रमाणपत्र खोजें…",
    browse: "सेवाएँ देखें",
    track: "शिकायत ट्रैक करें",
    statsServices: "सूचीबद्ध सेवाएँ",
    statsCategories: "सेवा श्रेणियाँ",
    statsComplaints: "शिकायत के प्रकार",
    popular: "ज़रूरी सेवाओं से शुरुआत करें",
    popularTitle: "रोज़मर्रा की सेवाएँ, अब आसान।",
    popularBody: "सही सेवा खोजें, ज़रूरी जानकारी समझें और सही प्रक्रिया चुनें — कई वेबसाइटों पर भटके बिना।",
    allServices: "सभी सेवाएँ देखें",
    categories: "ज़रूरत के अनुसार ब्राउज़ करें",
    categoriesTitle: "हम आपकी किस तरह मदद कर सकते हैं?",
    cityLabel: "अपनी अलग पहचान वाला शहर",
    cityTitle: "विरासत से जुड़ा. साथ मिलकर आगे.",
    cityBody: "साबरमती रिवरफ्रंट से लेकर पुराने शहर की ऐतिहासिक पोल तक, अहमदाबाद को यहाँ के लोग अपनी पहचान देते हैं। वन अहमदाबाद उसी स्थानीय सोच को रोज़मर्रा की नागरिक सेवाओं तक लाता है।",
    riverfront: "साबरमती रिवरफ्रंट के बारे में जानें",
    cityUpdates: "शहर की सूचना",
    cityUpdatesTitle: "वन अहमदाबाद अपडेट्स",
    updatesBody: "इस प्रोटोटाइप पर प्रकाशित सूचनाएँ और सेवा अपडेट। आधिकारिक आदेशों के लिए हमेशा AMC चैनल देखें।",
    allUpdates: "सभी अपडेट्स",
    how: "काम करने का आसान तरीका",
    howTitle: "तीन आसान कदम।",
    howBody: "आपके सवाल से सही सेवा तक का स्पष्ट रास्ता।",
    step1: "अपनी सेवा खोजें",
    step1Body: "श्रेणी और विषय के अनुसार डायरेक्टरी में खोजें।",
    step2: "सही प्रक्रिया चुनें",
    step2Body: "देखें कि यहाँ क्या हो सकता है और किस काम के लिए आधिकारिक पोर्टल ज़रूरी है।",
    step3: "अपना रेफ़रेंस संभालें",
    step3Body: "प्रोटोटाइप शिकायत को रेफ़रेंस नंबर से ट्रैक करें और स्थिति देखें।",
    guideLabel: "थोड़ी मदद चाहिए?",
    guideTitle: "शुरुआत कहाँ से करें, समझ नहीं आ रहा?",
    guideBody: "सही सेवा और अगले कदम समझने के लिए नागरिक गाइड से पूछें। यह केवल मार्गदर्शन देता है, आधिकारिक AMC सलाह का विकल्प नहीं है।",
    askGuide: "नागरिक गाइड खोलें",
    signIn: "साइन इन",
    register: "खाता बनाएँ",
    serviceModeDemo: "इस प्रोटोटाइप में ट्रैक करें",
    serviceModeHybrid: "यहाँ मार्गदर्शन · आवेदन आधिकारिक पोर्टल पर",
    serviceModeRedirect: "आधिकारिक पोर्टल पर जाएँ",
    platform: "वन अहमदाबाद",
  },
};

const CATEGORY_TRANSLATIONS: Record<string, Record<Locale, string>> = {
  "property-taxes": { en: "Property & Taxes", gu: "મિલકત અને વેરા", hi: "संपत्ति और कर" },
  "water-drainage": { en: "Water & Drainage", gu: "પાણી અને ગટર", hi: "पानी और ड्रेनेज" },
  certificates: { en: "Certificates", gu: "પ્રમાણપત્રો", hi: "प्रमाणपत्र" },
  "licences-permissions": { en: "Licences & Permissions", gu: "લાઇસન્સ અને મંજૂરી", hi: "लाइसेंस और अनुमति" },
  "civic-services": { en: "Civic Services", gu: "નાગરિક સેવાઓ", hi: "नागरिक सेवाएँ" },
  "public-facilities": { en: "Public Facilities", gu: "જાહેર સુવિધાઓ", hi: "सार्वजनिक सुविधाएँ" },
};

const SERVICE_TRANSLATIONS: Record<string, Record<Locale, string>> = {
  "property-tax-information": { en: "Property tax information", gu: "મિલકત વેરાની માહિતી", hi: "संपत्ति कर की जानकारी" },
  "water-connection-information": { en: "Water connection information", gu: "પાણીના જોડાણની માહિતી", hi: "पानी कनेक्शन की जानकारी" },
  "birth-registration-certificate": { en: "Birth registration & certificate", gu: "જન્મ નોંધણી અને પ્રમાણપત્ર", hi: "जन्म पंजीकरण और प्रमाणपत्र" },
  "garbage-collection-complaint": { en: "Garbage collection complaint", gu: "કચરો એકત્રિત કરવાની ફરિયાદ", hi: "कचरा संग्रह की शिकायत" },
  "potholes-damaged-roads": { en: "Potholes & damaged roads", gu: "ખાડા અને ક્ષતિગ્રસ્ત રસ્તા", hi: "गड्ढे और क्षतिग्रस्त सड़कें" },
  "building-permission-information": { en: "Building permission information", gu: "બાંધકામ મંજૂરીની માહિતી", hi: "निर्माण अनुमति की जानकारी" },
};

function translatedCategory(category: HomeCategory, locale: Locale) {
  return CATEGORY_TRANSLATIONS[category.slug]?.[locale] ?? category.name;
}

function translatedService(service: HomeService, locale: Locale) {
  return SERVICE_TRANSLATIONS[service.slug]?.[locale] ?? service.name;
}

function modeText(mode: string, t: Record<string, string>) {
  if (mode === "demo") return t.serviceModeDemo;
  if (mode === "hybrid") return t.serviceModeHybrid;
  return t.serviceModeRedirect;
}

function dateLabel(value: string, locale: Locale) {
  const localeName = locale === "gu" ? "gu-IN" : locale === "hi" ? "hi-IN" : "en-IN";
  return new Intl.DateTimeFormat(localeName, { day: "numeric", month: "short", year: "numeric" }).format(new Date(value));
}

export function HomeExperience({ stats, categories, services, announcements, announcementTotal }: Props) {
  const { locale } = useLocale();
  const t = COPY[locale];

  return (
    <>
      <section className="ah-hero">
        <div className="container-page relative z-10 flex min-h-[550px] items-center py-14 sm:min-h-[590px] lg:min-h-[620px]">
          <div className="max-w-[690px]">
            <div className="inline-flex items-center gap-2 rounded-sm border border-white/25 bg-slate-950/40 px-3 py-2 text-[11px] font-bold uppercase tracking-[0.19em] text-white">
              <MapPinned className="h-4 w-4 text-orange-400" /> {t.city}
            </div>
            <h1 className="ah-hero-title mt-6 max-w-[650px] text-[clamp(2.7rem,5.5vw,4.5rem)] font-bold leading-[1.03] tracking-[-0.04em]">
              {t.title1}<br /><span className="ah-hero-accent">{t.title2}</span>
            </h1>
            <p className="ah-hero-intro mt-6 max-w-[590px] text-base leading-8 sm:text-lg">
              {t.intro}
            </p>
            <div className="mt-7 max-w-[610px]">
              <ServiceSearch />
            </div>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/services" className="ah-button-primary">
                {t.browse} <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/track" className="ah-button-outline">
                <ClipboardList className="h-4 w-4" /> {t.track}
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 border-t border-white/25 pt-5 text-white">
              <div><strong className="block text-2xl font-bold tabular-nums">{stats.services}</strong><span className="text-xs text-slate-200">{t.statsServices}</span></div>
              <div><strong className="block text-2xl font-bold tabular-nums">{stats.categories}</strong><span className="text-xs text-slate-200">{t.statsCategories}</span></div>
              <div><strong className="block text-2xl font-bold tabular-nums">{stats.complaintTypes}</strong><span className="text-xs text-slate-200">{t.statsComplaints}</span></div>
            </div>
          </div>
          <div className="hidden w-[310px] shrink-0 self-end pb-12 xl:block">
            <div className="ah-hero-aside border-l-2 border-orange-500 bg-slate-950/80 p-5 backdrop-blur-sm">
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-orange-300">Ahmedabad, in focus</p>
              <p className="mt-2 text-xl font-semibold leading-snug">A better city experience starts with easier access.</p>
              <p className="mt-3 text-xs leading-6 text-slate-300">From civic information to complaint tracking, find the next step without losing your way.</p>
              <Link href="/services" className="mt-4 inline-flex items-center gap-2 text-xs font-bold text-white hover:text-orange-300">Open service directory <ArrowUpRight className="h-4 w-4" /></Link>
            </div>
          </div>
        </div>
      </section>

      <section className="relative z-20 -mt-7 pb-4 sm:-mt-10">
        <div className="container-page">
          <div className="ah-category-strip">
            {categories.map((category) => (
              <Link key={category.slug} href={`/services?category=${encodeURIComponent(category.slug)}`} className="ah-category-item">
                <span className="ah-category-icon"><CategoryIcon name={category.icon} className="h-7 w-7" /></span>
                <span className="mt-3 text-sm font-semibold leading-snug text-slate-900">{translatedCategory(category, locale)}</span>
                <span className="mt-1 text-[11px] text-slate-500">{category.serviceCount} {locale === "gu" ? "સેવાઓ" : locale === "hi" ? "सेवाएँ" : "services"}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <HomeActions />

      <section className="container-page py-16 lg:py-20" id="services">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="ah-eyebrow">{t.popular}</p>
            <h2 className="ah-section-title">{t.popularTitle}</h2>
            <p className="mt-3 text-sm leading-7 text-slate-600">{t.popularBody}</p>
          </div>
          <Link href="/services" className="ah-text-link">{t.allServices} <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {services.map((service, index) => {
            const iconMap = [WalletCards, Waves, FileText, BellRing, TrainFront, Building2];
            const Icon = iconMap[index % iconMap.length];
            return (
              <Link key={service.slug} href={`/services/${service.slug}`} className="ah-service-card group">
                <div className="flex items-start justify-between gap-3">
                  <span className="ah-service-icon"><Icon className="h-5 w-5" /></span>
                  <span className="ah-service-category">{CATEGORY_TRANSLATIONS[service.categorySlug]?.[locale] ?? service.categoryName}</span>
                </div>
                <h3 className="mt-5 text-[17px] font-bold leading-snug text-slate-900">{translatedService(service, locale)}</h3>
                <p className="mt-2 min-h-[48px] text-sm leading-6 text-slate-600">{service.summary}</p>
                <div className="mt-5 flex items-center justify-between gap-3 border-t border-slate-100 pt-4">
                  <span className="text-[11px] font-semibold text-slate-500">{modeText(service.handlingMode, t)}</span>
                  <ArrowUpRight className="h-4 w-4 text-slate-400 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-orange-600" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="bg-[#f3f5f7] py-16 lg:py-20">
        <div className="container-page grid gap-8 lg:grid-cols-[1.12fr_0.88fr] lg:items-stretch">
          <div className="ah-city-feature">
            <div className="ah-city-image" role="img" aria-label="Illustrative evening view of the Sabarmati Riverfront and Atal Bridge" />
            <div className="ah-city-copy relative z-10 max-w-xl p-7 sm:p-9">
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-orange-300">{t.cityLabel}</p>
              <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">{t.cityTitle}</h2>
              <p className="mt-4 max-w-lg text-sm leading-7 text-slate-100">{t.cityBody}</p>
              <a href="https://ahmedabad.nic.in/tourist-place/river-front-sabarmati/" target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 border-b border-orange-400 pb-1 text-sm font-semibold text-white hover:text-orange-200">
                {t.riverfront} <ArrowUpRight className="h-4 w-4" />
              </a>
              <div className="mt-8 flex flex-wrap gap-2">
                {["Sabarmati Riverfront", "Historic Walled City", "Kankaria Lake"].map((label) => <span key={label} className="border border-white/30 bg-slate-950/30 px-3 py-1.5 text-[10px] font-semibold tracking-wide text-white">{label}</span>)}
              </div>
            </div>
          </div>

          <div className="flex flex-col bg-white p-6 shadow-sm sm:p-8">
            <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-5">
              <div>
                <p className="ah-eyebrow">{t.cityUpdates}</p>
                <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">{t.cityUpdatesTitle}</h2>
              </div>
              <BellRing className="h-6 w-6 shrink-0 text-orange-600" />
            </div>
            <p className="mt-4 text-xs leading-6 text-slate-500">{t.updatesBody}</p>
            <div className="mt-4 flex-1 divide-y divide-slate-100">
              {announcements.length ? announcements.map((item) => (
                <article key={item.id} className="py-4 first:pt-1">
                  <div className="flex flex-wrap items-center gap-2 text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                    <span className="text-orange-700">{item.category}</span><span>·</span><span>{dateLabel(item.publishedAt, locale)}</span>
                  </div>
                  <h3 className="mt-2 text-[15px] font-bold leading-snug text-slate-900">{item.title}</h3>
                  <p className="mt-1.5 line-clamp-2 text-xs leading-6 text-slate-600">{item.body}</p>
                </article>
              )) : (
                <div className="py-8 text-sm text-slate-500">No updates have been published yet.</div>
              )}
            </div>
            <Link href="/announcements" className="mt-3 inline-flex items-center gap-2 self-start text-sm font-bold text-blue-900 hover:text-orange-700">
              {t.allUpdates} ({announcementTotal}) <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="container-page py-16 lg:py-20">
        <div className="max-w-2xl">
          <p className="ah-eyebrow">{t.how}</p>
          <h2 className="ah-section-title">{t.howTitle}</h2>
          <p className="mt-3 text-sm leading-7 text-slate-600">{t.howBody}</p>
        </div>
        <div className="mt-9 grid gap-5 md:grid-cols-3">
          {[
            { icon: MapPinned, number: "01", title: t.step1, body: t.step1Body },
            { icon: ClipboardList, number: "02", title: t.step2, body: t.step2Body },
            { icon: CheckCircle2, number: "03", title: t.step3, body: t.step3Body },
          ].map((step) => (
            <div key={step.number} className="ah-step-card">
              <div className="flex items-center justify-between"><step.icon className="h-6 w-6 text-orange-600" /><span className="text-xs font-bold tracking-[0.16em] text-slate-300">{step.number}</span></div>
              <h3 className="mt-6 text-lg font-bold text-slate-900">{step.title}</h3>
              <p className="mt-2 text-sm leading-7 text-slate-600">{step.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-page pb-16 lg:pb-20">
        <div className="ah-guide-banner">
          <div className="max-w-2xl">
            <p className="text-[10px] font-bold uppercase tracking-[0.19em] text-orange-300">{t.guideLabel}</p>
            <h2 className="ah-guide-title mt-3 text-2xl font-bold sm:text-3xl">{t.guideTitle}</h2>
            <p className="ah-guide-copy mt-3 max-w-xl text-sm leading-7">{t.guideBody}</p>
          </div>
          <div className="flex shrink-0 flex-wrap gap-3">
            <Link href="/assistant" className="ah-button-primary"> <MessageCircle className="h-4 w-4" /> {t.askGuide} </Link>
            <Link href="/register" className="ah-button-outline">{t.register}</Link>
          </div>
        </div>
      </section>
    </>
  );
}
