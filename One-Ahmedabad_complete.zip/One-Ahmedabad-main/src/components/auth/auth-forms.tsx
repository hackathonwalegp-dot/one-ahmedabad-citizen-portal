"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  LoaderCircle,
  Mail,
  MapPin,
  Phone,
  User,
} from "lucide-react";

type Mode = "login" | "register";

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    ward: "",
    address: "",
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  function update(key: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
    setFieldErrors((current) => {
      if (!current[key]) return current;
      const next = { ...current };
      delete next[key];
      return next;
    });
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setFieldErrors({});

    if (mode === "register" && form.password !== form.confirmPassword) {
      setFieldErrors({ confirmPassword: "Passwords do not match." });
      return;
    }

    setBusy(true);
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body =
        mode === "login"
          ? { email: form.email, password: form.password }
          : {
              name: form.name,
              email: form.email,
              phone: form.phone,
              ward: form.ward,
              address: form.address,
              password: form.password,
            };

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await response.json();

      if (!response.ok) {
        setError(data.error ?? "Something went wrong. Please try again.");
        if (Array.isArray(data.issues)) {
          const map: Record<string, string> = {};
          for (const issue of data.issues) map[issue.path] = issue.message;
          setFieldErrors(map);
        }
        return;
      }

      router.push(data.redirectTo ?? "/dashboard");
      router.refresh();
    } catch {
      setError("Network error — please check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  const isLogin = mode === "login";

  return (
    <div className="grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
      <div className="hidden lg:block">
        <h1 className="text-[clamp(2rem,3.6vw,2.75rem)] font-bold leading-[1.1] tracking-tight">
          {isLogin ? "Welcome back to One Ahmedabad" : "Create your citizen account"}
        </h1>
        <p className="mt-4 max-w-md text-[15px] leading-relaxed text-ink-500">
          {isLogin
            ? "Sign in to track your complaints, manage your profile and use the citizen service guide."
            : "One account gives you tracked complaints, in-app notifications and a single place for every municipal service you use."}
        </p>

        <ul className="mt-8 space-y-3.5">
          {[
            "Passwords hashed with scrypt and a per-user salt",
            "Server-side sessions stored in the database",
            "Separate citizen, service-centre and administrator roles",
            "Complaint history and reference numbers kept for you",
          ].map((item) => (
            <li key={item} className="flex items-start gap-3 text-sm text-ink-600">
              <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-brand-600" />
              {item}
            </li>
          ))}
        </ul>

        <div className="mt-9 border-l-2 border-orange-500 bg-ink-50/60 p-5">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-ink-700">Getting started</p>
          <p className="mt-2 text-sm leading-6 text-ink-600">
            New to One Ahmedabad? Create a citizen account to register and follow prototype complaints. Administrator accounts are provisioned separately by the platform owner.
          </p>
          {isLogin && <Link href="/register" className="mt-3 inline-flex items-center gap-2 text-xs font-bold text-brand-700 hover:text-brand-800">Create a citizen account <ArrowRight className="h-3.5 w-3.5" /></Link>}
        </div>
      </div>

      <div className="rounded-3xl border border-ink-100 bg-white p-6 shadow-card sm:p-8">
        <div className="lg:hidden">
          <h1 className="text-2xl font-bold tracking-tight">
            {isLogin ? "Welcome back" : "Create your account"}
          </h1>
          <p className="mt-2 text-sm text-ink-500">
            {isLogin
              ? "Sign in to access your citizen dashboard."
              : "Register as a citizen to raise and track complaints."}
          </p>

        </div>

        <form onSubmit={submit} className="mt-2 space-y-4 lg:mt-0" noValidate>


          {error && (
            <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          {!isLogin && (
            <div>
              <label htmlFor="name" className="block text-sm font-semibold text-ink-800">
                Full name
              </label>
              <div className="relative mt-1.5">
                <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                <input
                  id="name"
                  value={form.name}
                  onChange={(event) => update("name", event.target.value)}
                  placeholder="Rohan Patel"
                  className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                />
              </div>
              {fieldErrors.name && (
                <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.name}</p>
              )}
            </div>
          )}

          <div>
            <label htmlFor="email" className="block text-sm font-semibold text-ink-800">
              Email address
            </label>
            <div className="relative mt-1.5">
              <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={form.email}
                onChange={(event) => update("email", event.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>
            {fieldErrors.email && (
              <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.email}</p>
            )}
          </div>

          {!isLogin && (
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="phone" className="block text-sm font-semibold text-ink-800">
                  Phone <span className="font-normal text-ink-400">(optional)</span>
                </label>
                <div className="relative mt-1.5">
                  <Phone className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                  <input
                    id="phone"
                    value={form.phone}
                    onChange={(event) => update("phone", event.target.value)}
                    placeholder="+91 98250 00000"
                    className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="ward" className="block text-sm font-semibold text-ink-800">
                  Ward <span className="font-normal text-ink-400">(optional)</span>
                </label>
                <div className="relative mt-1.5">
                  <MapPin className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                  <input
                    id="ward"
                    value={form.ward}
                    onChange={(event) => update("ward", event.target.value)}
                    placeholder="Ward 12"
                    className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                </div>
              </div>
            </div>
          )}

          <div>
            <label htmlFor="password" className="block text-sm font-semibold text-ink-800">
              Password
            </label>
            <div className="relative mt-1.5">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete={isLogin ? "current-password" : "new-password"}
                value={form.password}
                onChange={(event) => update("password", event.target.value)}
                placeholder={isLogin ? "Your password" : "At least 8 characters with a number"}
                className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-3.5 pr-11 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
              <button
                type="button"
                onClick={() => setShowPassword((value) => !value)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 transition hover:text-ink-700"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {fieldErrors.password && (
              <p className="mt-1.5 text-xs font-medium text-rose-600">{fieldErrors.password}</p>
            )}
            {!isLogin && (
              <p className="mt-1.5 text-xs text-ink-400">
                Minimum 8 characters, including at least one letter and one number.
              </p>
            )}
          </div>

          {!isLogin && (
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-semibold text-ink-800">
                Confirm password
              </label>
              <input
                id="confirmPassword"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                value={form.confirmPassword}
                onChange={(event) => update("confirmPassword", event.target.value)}
                placeholder="Repeat your password"
                className="w-full rounded-xl border border-ink-200 bg-white py-2.5 px-3.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
              {fieldErrors.confirmPassword && (
                <p className="mt-1.5 text-xs font-medium text-rose-600">
                  {fieldErrors.confirmPassword}
                </p>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {busy ? (
              <>
                <LoaderCircle className="h-4 w-4 animate-spin" />
                {isLogin ? "Signing in…" : "Creating account…"}
              </>
            ) : (
              <>
                {isLogin ? "Sign in" : "Create citizen account"}
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>

          <p className="text-center text-sm text-ink-500">
            {isLogin ? "New to One Ahmedabad?" : "Already registered?"}{" "}
            <Link
              href={isLogin ? "/register" : "/login"}
              className="font-semibold text-brand-700 hover:text-brand-800"
            >
              {isLogin ? "Create an account" : "Sign in"}
            </Link>
          </p>

          <p className="rounded-xl bg-ink-50 px-4 py-3 text-[11px] leading-relaxed text-ink-500">
            One Ahmedabad is a prototype platform. By creating an account you accept that no
            government service is executed here — official applications happen on AMC portals.
          </p>
        </form>
      </div>
    </div>
  );
}
