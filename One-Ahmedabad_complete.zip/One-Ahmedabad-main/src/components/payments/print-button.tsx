"use client";

import { Printer } from "lucide-react";

export function PrintButton() {
  return (
    <button type="button" onClick={() => window.print()} className="ah-button-primary">
      <Printer className="h-4 w-4" /> Print or save as PDF
    </button>
  );
}
