"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AlertCircle, CheckCircle2, CreditCard, Home, LoaderCircle, Plus, Receipt } from "lucide-react";
import { formatRupees, PAYMENT_METHODS } from "@/lib/money";
import { WARDS } from "@/lib/departments";

export type PropertyCard = {
  id: number;
  propertyCode: string;
  ownerName: string;
  address: string;
  ward: string | null;
  assessmentYear: string;
  assessmentAmount: number;
  paid: number;
  outstanding: number;
};

const field =
  "mt-1.5 w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100";

function PayForm({ property }: { property: PropertyCard }) {
  const router = useRouter();
  const [amount, setAmount] = useState(String(property.outstanding));
  const [method, setMethod] = useState<string>(PAYMENT_METHODS[0]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [receipt, setReceipt] = useState<string | null>(null);

  async function pay(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/payments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ propertyId: property.id, amount: Number(amount), method }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "The demo payment could not be recorded.");
        return;
      }
      setReceipt(data.receiptNo);
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  if (receipt) {
    return (
      <div className="mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
        <CheckCircle2 className="h-4 w-4 shrink-0" />
        <span>Demo payment recorded. Receipt <b className="font-mono">{receipt}</b></span>
        <Link href={`/dashboard/payments/${receipt}`} className="ml-auto inline-flex items-center gap-1.5 font-bold underline underline-offset-2">
          <Receipt className="h-4 w-4" /> Open receipt
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={pay} className="mt-4 grid gap-3 rounded-xl bg-ink-50 p-4 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700 sm:col-span-3">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
        </div>
      )}
      <div>
        <label htmlFor={`amount-${property.id}`} className="block text-xs font-semibold text-ink-700">Amount (₹)</label>
        <input id={`amount-${property.id}`} type="number" min={1} max={property.outstanding} step={1} value={amount} onChange={(e) => setAmount(e.target.value)} className={field} />
      </div>
      <div>
        <label htmlFor={`method-${property.id}`} className="block text-xs font-semibold text-ink-700">Method</label>
        <select id={`method-${property.id}`} value={method} onChange={(e) => setMethod(e.target.value)} className={field}>
          {PAYMENT_METHODS.map((item) => (<option key={item} value={item}>{item}</option>))}
        </select>
      </div>
      <button type="submit" disabled={busy} className="ah-button-primary disabled:cursor-not-allowed disabled:opacity-70">
        {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />} Simulate payment
      </button>
    </form>
  );
}

export function PropertyList({ properties }: { properties: PropertyCard[] }) {
  return (
    <div className="space-y-4">
      {properties.map((property) => {
        const share = property.assessmentAmount ? Math.min(100, (property.paid / property.assessmentAmount) * 100) : 0;
        return (
          <section key={property.id} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs font-semibold tracking-wide text-brand-700">{property.propertyCode}</p>
                <h3 className="mt-1 flex items-center gap-2 text-base font-bold text-ink-900">
                  <Home className="h-4 w-4 text-orange-600" /> {property.address}
                </h3>
                <p className="mt-1 text-xs text-ink-500">
                  {property.ownerName} · {property.ward ?? "Ward not set"} · Assessment year {property.assessmentYear}
                </p>
              </div>
              <span className={"rounded-full px-3 py-1 text-xs font-bold ring-1 ring-inset " + (property.outstanding === 0 ? "bg-emerald-50 text-emerald-700 ring-emerald-200" : "bg-amber-50 text-amber-800 ring-amber-200")}>
                {property.outstanding === 0 ? "Fully paid (demo)" : "Outstanding (demo)"}
              </span>
            </div>

            <dl className="mt-5 grid grid-cols-3 gap-3 text-center">
              {[
                { label: "Illustrative assessment", value: formatRupees(property.assessmentAmount) },
                { label: "Paid in demo", value: formatRupees(property.paid) },
                { label: "Outstanding", value: formatRupees(property.outstanding) },
              ].map((row) => (
                <div key={row.label} className="rounded-xl border border-ink-100 px-3 py-3">
                  <dt className="text-[10px] font-semibold uppercase tracking-wide text-ink-400">{row.label}</dt>
                  <dd className="mt-1 text-base font-bold tabular-nums text-ink-900">{row.value}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-ink-100">
              <div className="h-full rounded-full bg-emerald-500" style={{ width: `${share}%` }} />
            </div>

            {property.outstanding > 0 ? (
              <PayForm property={property} />
            ) : (
              <p className="mt-4 text-xs text-ink-500">Nothing is outstanding for this property in the simulator.</p>
            )}
          </section>
        );
      })}
    </div>
  );
}

export function AddPropertyForm({ defaultOwner, defaultWard }: { defaultOwner: string; defaultWard: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [ownerName, setOwnerName] = useState(defaultOwner);
  const [address, setAddress] = useState("");
  const [ward, setWard] = useState(defaultWard);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/properties", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ownerName, address, ward }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "The property could not be added.");
        return;
      }
      setAddress("");
      setOpen(false);
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="ah-button-primary">
        <Plus className="h-4 w-4" /> Add a property
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
      <h3 className="text-base font-bold text-ink-900">Add a property</h3>
      <p className="mt-1 text-xs leading-relaxed text-ink-500">
        The simulator attaches an illustrative assessment. It is not looked up from any AMC tax record.
      </p>
      {error && <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700">{error}</p>}
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="ownerName" className="block text-sm font-semibold text-ink-800">Owner name</label>
          <input id="ownerName" value={ownerName} onChange={(e) => setOwnerName(e.target.value)} className={field} />
        </div>
        <div>
          <label htmlFor="propWard" className="block text-sm font-semibold text-ink-800">Ward / locality</label>
          <select id="propWard" value={ward} onChange={(e) => setWard(e.target.value)} className={field}>
            <option value="">Select…</option>
            {WARDS.map((item) => (<option key={item} value={item}>{item}</option>))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="propAddress" className="block text-sm font-semibold text-ink-800">Property address</label>
          <input id="propAddress" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="House number, street, area, Ahmedabad" className={field} />
        </div>
      </div>
      <div className="mt-5 flex gap-3">
        <button type="submit" disabled={busy} className="ah-button-primary disabled:opacity-70">
          {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Add property
        </button>
        <button type="button" onClick={() => setOpen(false)} className="inline-flex min-h-[46px] items-center border border-ink-200 px-5 text-sm font-semibold text-ink-700">Cancel</button>
      </div>
    </form>
  );
}
