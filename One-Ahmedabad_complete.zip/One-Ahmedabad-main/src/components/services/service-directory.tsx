"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, LoaderCircle, Search, SlidersHorizontal, X } from "lucide-react";
import { accentStyle, CategoryIcon } from "@/components/ui/category-icon";

export type DirectoryService = {
  slug: string;
  name: string;
  summary: string;
  categoryName: string;
  categorySlug: string;
  categoryIcon: string;
  accent: string;
  handlingMode: string;
  officialPortalUrl: string | null;
};

export type DirectoryCategory = {
  slug: string;
  name: string;
  description: string | null;
  icon: string;
  accent: string;
};

function modeLabel(mode: string) {
  if (mode === "demo") return "Handled in One Ahmedabad";
  if (mode === "hybrid") return "Info here · apply on AMC portal";
  return "Official AMC / State portal";
}

function modeTone(mode: string) {
  if (mode === "demo") return "bg-emerald-50 text-emerald-700 ring-emerald-100";
  if (mode === "hybrid") return "bg-amber-50 text-amber-800 ring-amber-100";
  return "bg-ink-100 text-ink-600 ring-ink-200";
}

export function ServiceDirectory({
  categories,
  initialServices,
  initialQuery = "",
  initialCategory = "all",
}: {
  categories: DirectoryCategory[];
  initialServices: DirectoryService[];
  initialQuery?: string;
  initialCategory?: string;
}) {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory || "all");
  const [services, setServices] = useState<DirectoryService[]>(initialServices);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const term = query.trim();
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (term) params.set("q", term);
        if (category && category !== "all") params.set("category", category);
        const response = await fetch(`/api/services?${params.toString()}`, {
          signal: controller.signal,
        });
        const data = await response.json();
        if (Array.isArray(data.services)) setServices(data.services);
      } catch (error) {
        if ((error as Error).name !== "AbortError") setServices([]);
      } finally {
        setLoading(false);
      }
    }, 200);

    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [query, category]);

  const activeCategory = useMemo(
    () => categories.find((item) => item.slug === category),
    [categories, category],
  );

  return (
    <div>
      {/* Controls */}
      <div className="rounded-2xl border border-ink-100 bg-white p-4 shadow-soft sm:p-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-ink-400" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search services — try “water”, “tax”, “certificate”, “pothole”"
            aria-label="Search municipal services"
            className="w-full rounded-xl border border-ink-200 bg-white py-3 pl-11 pr-11 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="absolute right-3.5 top-1/2 -translate-y-1/2 rounded-lg p-1 text-ink-400 transition hover:bg-ink-50 hover:text-ink-700"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-400">
            <SlidersHorizontal className="h-3.5 w-3.5" />
            Filter
          </span>
          <button
            type="button"
            onClick={() => setCategory("all")}
            className={
              "rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 ring-inset transition " +
              (category === "all"
                ? "bg-ink-900 text-white ring-ink-900"
                : "bg-white text-ink-600 ring-ink-200 hover:ring-ink-300")
            }
          >
            All categories
          </button>
          {categories.map((item) => (
            <button
              key={item.slug}
              type="button"
              onClick={() => setCategory(item.slug)}
              className={
                "rounded-full px-3.5 py-1.5 text-xs font-semibold ring-1 ring-inset transition " +
                (category === item.slug
                  ? "bg-brand-600 text-white ring-brand-600"
                  : "bg-white text-ink-600 ring-ink-200 hover:ring-ink-300")
              }
            >
              {item.name}
            </button>
          ))}
        </div>
      </div>

      {/* Meta */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-500">
          {loading ? (
            <span className="inline-flex items-center gap-2">
              <LoaderCircle className="h-4 w-4 animate-spin" /> Loading services…
            </span>
          ) : (
            <>
              <span className="font-semibold text-ink-900">{services.length}</span> service
              {services.length === 1 ? "" : "s"}
              {query.trim() && (
                <>
                  {" "}
                  matching{" "}
                  <span className="font-semibold text-ink-900">“{query.trim()}”</span>
                </>
              )}
              {activeCategory && category !== "all" && (
                <>
                  {" "}
                  in <span className="font-semibold text-ink-900">{activeCategory.name}</span>
                </>
              )}
            </>
          )}
        </p>
        {(query || category !== "all") && (
          <button
            type="button"
            onClick={() => {
              setQuery("");
              setCategory("all");
            }}
            className="text-xs font-semibold text-brand-700 hover:text-brand-800"
          >
            Reset filters
          </button>
        )}
      </div>

      {/* Results */}
      {services.length === 0 && !loading ? (
        <div className="mt-6 rounded-2xl border border-dashed border-ink-200 bg-ink-50/60 px-6 py-14 text-center">
          <Search className="mx-auto h-7 w-7 text-ink-300" />
          <p className="mt-3 text-sm font-semibold text-ink-900">No services match your search</p>
          <p className="mx-auto mt-1.5 max-w-sm text-xs leading-relaxed text-ink-500">
            Try a broader term such as “water”, “tax” or “road”. If the service you need is not
            listed, ask the AI assistant — it maps your question to the closest matching service.
          </p>
          <Link
            href="/assistant"
            className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-semibold text-white"
          >
            Ask the AI assistant
          </Link>
        </div>
      ) : (
        <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {services.map((service) => {
            const accent = accentStyle(service.accent);
            return (
              <Link
                key={service.slug}
                href={`/services/${service.slug}`}
                className="group card-hover flex flex-col rounded-2xl border border-ink-100 bg-white p-5 shadow-soft"
              >
                <div className="flex items-start justify-between gap-3">
                  <span
                    className={`grid h-11 w-11 place-items-center rounded-xl ring-1 ring-inset ${accent.chip}`}
                  >
                    <CategoryIcon name={service.categoryIcon} className="h-5 w-5" />
                  </span>
                  <ArrowUpRight className="h-4 w-4 text-ink-300 transition group-hover:text-brand-600" />
                </div>
                <h3 className="mt-4 text-[15px] font-bold leading-snug text-ink-900">
                  {service.name}
                </h3>
                <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-ink-500">
                  {service.summary}
                </p>
                <div className="mt-auto flex flex-wrap items-center gap-2 border-t border-ink-100 pt-3.5">
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">
                    {service.categoryName}
                  </span>
                  <span
                    className={`ml-auto rounded-full px-2 py-0.5 text-[10px] font-semibold ring-1 ring-inset ${modeTone(service.handlingMode)}`}
                  >
                    {modeLabel(service.handlingMode)}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
