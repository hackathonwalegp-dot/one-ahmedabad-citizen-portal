import {
  Award,
  Building2,
  CalendarCheck,
  Droplets,
  FileText,
  Hammer,
  Landmark,
  Percent,
  Receipt,
  ScrollText,
  Store,
  Trees,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  Percent,
  Droplets,
  ScrollText,
  Store,
  Hammer,
  Trees,
  Landmark,
  Building2,
  FileText,
  Receipt,
  CalendarCheck,
  Award,
};

export function CategoryIcon({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  const Icon = ICONS[name] ?? Landmark;
  return <Icon className={className} strokeWidth={1.75} aria-hidden="true" />;
}

const ACCENTS: Record<string, { chip: string; solid: string; soft: string }> = {
  blue: {
    chip: "bg-brand-50 text-brand-700 ring-brand-100",
    solid: "bg-brand-600 text-white",
    soft: "bg-brand-50",
  },
  cyan: {
    chip: "bg-cyan-50 text-cyan-700 ring-cyan-100",
    solid: "bg-cyan-600 text-white",
    soft: "bg-cyan-50",
  },
  violet: {
    chip: "bg-brand-50 text-brand-700 ring-brand-100",
    solid: "bg-brand-700 text-white",
    soft: "bg-brand-50",
  },
  amber: {
    chip: "bg-amber-50 text-amber-700 ring-amber-100",
    solid: "bg-amber-600 text-white",
    soft: "bg-amber-50",
  },
  emerald: {
    chip: "bg-emerald-50 text-emerald-700 ring-emerald-100",
    solid: "bg-emerald-600 text-white",
    soft: "bg-emerald-50",
  },
  rose: {
    chip: "bg-orange-50 text-orange-700 ring-orange-100",
    solid: "bg-orange-600 text-white",
    soft: "bg-orange-50",
  },
};

export function accentStyle(accent: string) {
  return ACCENTS[accent] ?? ACCENTS.blue;
}
