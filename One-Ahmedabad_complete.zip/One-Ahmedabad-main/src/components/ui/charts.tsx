import { cn } from "@/lib/utils";

/** Horizontal bars, pure CSS, rendered on the server. */
export function BarList({
  items,
  tone = "bg-brand-600",
}: {
  items: { label: string; value: number }[];
  tone?: string;
}) {
  const max = Math.max(1, ...items.map((item) => item.value));
  if (!items.length) return <p className="text-sm text-ink-500">No data yet.</p>;
  return (
    <ul className="space-y-3">
      {items.map((item) => (
        <li key={item.label}>
          <div className="flex items-center justify-between gap-3 text-xs">
            <span className="min-w-0 truncate font-semibold text-ink-700">{item.label}</span>
            <span className="tabular-nums font-bold text-ink-900">{item.value}</span>
          </div>
          <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-ink-100">
            <div className={cn("h-full rounded-full", tone)} style={{ width: `${(item.value / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

/** Grouped vertical columns (two series) with labels, pure SVG. */
export function ColumnChart({
  data,
}: {
  data: { label: string; a: number; b: number }[];
}) {
  const max = Math.max(1, ...data.flatMap((d) => [d.a, d.b]));
  const height = 150;
  const slot = 100 / Math.max(1, data.length);
  return (
    <div>
      <svg viewBox={`0 0 100 ${height + 18}`} className="h-52 w-full" role="img" aria-label="Monthly requests">
        {[0, 0.5, 1].map((fraction) => (
          <line key={fraction} x1="0" x2="100" y1={height - fraction * height} y2={height - fraction * height} stroke="#e9edf2" strokeWidth="0.4" />
        ))}
        {data.map((d, index) => {
          const x = index * slot + slot / 2;
          const hA = (d.a / max) * (height - 8);
          const hB = (d.b / max) * (height - 8);
          return (
            <g key={d.label}>
              <rect x={x - 5.2} y={height - hA} width="4.8" height={hA} fill="#e85d37" rx="0.6" />
              <rect x={x + 0.4} y={height - hB} width="4.8" height={hB} fill="#153a60" rx="0.6" />
              <text x={x} y={height + 11} textAnchor="middle" fontSize="4" fill="#647488">
                {d.label}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="mt-2 flex items-center gap-5 text-xs text-ink-600">
        <span className="inline-flex items-center gap-1.5"><i className="h-2.5 w-2.5 rounded-sm bg-[#e85d37]" /> Complaints</span>
        <span className="inline-flex items-center gap-1.5"><i className="h-2.5 w-2.5 rounded-sm bg-[#153a60]" /> Applications</span>
      </div>
    </div>
  );
}

/** Donut with a legend, pure SVG. */
export function Donut({
  parts,
  centre,
}: {
  parts: { label: string; value: number; color: string }[];
  centre?: string;
}) {
  const total = parts.reduce((sum, part) => sum + part.value, 0);
  const radius = 15.9155;
  let offset = 25;
  return (
    <div className="flex flex-wrap items-center gap-6">
      <svg viewBox="0 0 42 42" className="h-40 w-40 shrink-0" role="img" aria-label="Status split">
        <circle cx="21" cy="21" r={radius} fill="none" stroke="#e9edf2" strokeWidth="5" />
        {total > 0 &&
          parts.map((part) => {
            const share = (part.value / total) * 100;
            const node = (
              <circle
                key={part.label}
                cx="21"
                cy="21"
                r={radius}
                fill="none"
                stroke={part.color}
                strokeWidth="5"
                strokeDasharray={`${share} ${100 - share}`}
                strokeDashoffset={offset}
              />
            );
            offset -= share;
            return node;
          })}
        <text x="21" y="22.5" textAnchor="middle" fontSize="7" fontWeight="700" fill="#10233f">
          {centre ?? total}
        </text>
      </svg>
      <ul className="space-y-2 text-sm">
        {parts.map((part) => (
          <li key={part.label} className="flex items-center gap-2.5">
            <i className="h-2.5 w-2.5 rounded-sm" style={{ background: part.color }} />
            <span className="text-ink-600">{part.label}</span>
            <b className="tabular-nums text-ink-900">{part.value}</b>
          </li>
        ))}
      </ul>
    </div>
  );
}
