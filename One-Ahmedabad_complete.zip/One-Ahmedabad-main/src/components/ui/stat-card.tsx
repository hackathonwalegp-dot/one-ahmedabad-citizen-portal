import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const TONES = {
  navy: "bg-brand-50 text-brand-700",
  orange: "bg-orange-50 text-orange-700",
  green: "bg-emerald-50 text-emerald-700",
  amber: "bg-amber-50 text-amber-700",
  slate: "bg-ink-100 text-ink-600",
} as const;

export function StatCard({
  label,
  value,
  note,
  icon,
  tone = "navy",
}: {
  label: string;
  value: ReactNode;
  note?: string;
  icon: ReactNode;
  tone?: keyof typeof TONES;
}) {
  return (
    <div className="rounded-2xl border border-ink-100 bg-white p-5 shadow-soft">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-ink-400">{label}</p>
        <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-xl", TONES[tone])}>{icon}</span>
      </div>
      <p className="mt-3 text-3xl font-bold tabular-nums tracking-tight text-ink-900">{value}</p>
      {note && <p className="mt-1 text-xs text-ink-500">{note}</p>}
    </div>
  );
}
