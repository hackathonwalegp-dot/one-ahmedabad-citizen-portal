import { Clock3 } from "lucide-react";
import { getStatusMeta } from "@/lib/complaints";
import { formatDateTime } from "@/lib/utils";

export type TimelineEntry = {
  id: number;
  status: string;
  note: string | null;
  actorType: string;
  actorName: string | null;
  createdAt: Date | string;
};

const ACTOR_LABEL: Record<string, string> = {
  admin: "Administrator",
  citizen: "Citizen",
  operator: "Service centre",
  system: "System",
};

export function Timeline({ title, events }: { title: string; events: TimelineEntry[] }) {
  return (
    <section className="rounded-2xl border border-ink-100 bg-white p-6 shadow-soft">
      <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
        <Clock3 className="h-[18px] w-[18px] text-orange-600" />
        {title}
      </h2>
      <ol className="mt-5 space-y-5">
        {events.map((event, index) => {
          const meta = getStatusMeta(event.status);
          return (
            <li key={event.id} className="relative flex gap-4 pl-1">
              {index < events.length - 1 && (
                <span className="absolute left-[13px] top-7 h-full w-px bg-ink-100" />
              )}
              <span className={`relative z-10 mt-1 h-3 w-3 shrink-0 rounded-full ring-4 ring-white ${meta.dot}`} />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-sm font-bold text-ink-900">{meta.label}</p>
                  <span className="text-[11px] text-ink-400">{formatDateTime(event.createdAt)}</span>
                  <span className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-ink-500">
                    {ACTOR_LABEL[event.actorType] ?? "System"}
                  </span>
                </div>
                {event.note && <p className="mt-1.5 text-sm leading-relaxed text-ink-600">{event.note}</p>}
                {event.actorName && <p className="mt-1 text-[11px] text-ink-400">by {event.actorName}</p>}
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
