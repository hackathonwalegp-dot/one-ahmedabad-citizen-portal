/**
 * One Ahmedabad — municipal services catalogue (seed content)
 * -----------------------------------------------------------------
 * IMPORTANT: this content is informational only.
 *  - No official fees, processing times or eligibility rules are invented.
 *  - Every external link points to a public AMC / State portal.
 *  - `handlingMode` tells the citizen exactly what this prototype does:
 *      "demo"    -> request is created and tracked inside One Ahmedabad
 *      "redirect"-> the citizen is guided to the official AMC / State portal
 *      "hybrid"  -> we explain the procedure here, application happens there
 */

export type HandlingMode = "demo" | "redirect" | "hybrid";

export type CategorySeed = {
  slug: string;
  name: string;
  description: string;
  icon: string;
  accent: string;
  sortOrder: number;
};

export type ServiceSeed = {
  slug: string;
  name: string;
  categorySlug: string;
  summary: string;
  description: string;
  requirements: string[];
  procedure: string[];
  documents: string[];
  officialPortalUrl?: string;
  handlingMode: HandlingMode;
  office?: string;
  disclaimer?: string;
  isComplaintType?: boolean;
};

export const AMC_HOME = "https://ahmedabadcity.gov.in";
export const AMC_SAMPARK = "https://sampark.ahmedabadcity.gov.in";
export const AMC_WATER = "https://awmc.org.in";
export const GUJ_RTI = "https://rti.gujarat.gov.in";

export const categorySeed: CategorySeed[] = [
  {
    slug: "property-taxes",
    name: "Property & Taxes",
    description: "Property tax, professional tax, dues and assessment guidance.",
    icon: "Percent",
    accent: "blue",
    sortOrder: 1,
  },
  {
    slug: "water-drainage",
    name: "Water & Drainage",
    description: "Water connections, supply issues, leakage and stormwater drainage.",
    icon: "Droplets",
    accent: "cyan",
    sortOrder: 2,
  },
  {
    slug: "certificates",
    name: "Certificates",
    description: "Birth, death and marriage registration guidance and portals.",
    icon: "ScrollText",
    accent: "violet",
    sortOrder: 3,
  },
  {
    slug: "licences-permissions",
    name: "Licences & Permissions",
    description: "Shops, hawkers, trade licences and building permissions.",
    icon: "Store",
    accent: "amber",
    sortOrder: 4,
  },
  {
    slug: "civic-services",
    name: "Civic Services",
    description: "Roads, waste, streetlights, drainage and cleanliness grievances.",
    icon: "Hammer",
    accent: "emerald",
    sortOrder: 5,
  },
  {
    slug: "public-facilities",
    name: "Public Facilities",
    description: "Community halls, pools, gyms and parks across the city.",
    icon: "Trees",
    accent: "rose",
    sortOrder: 6,
  },
];

export const serviceSeed: ServiceSeed[] = [
  /* ---------------- Property & Taxes ---------------- */
  {
    slug: "property-tax-information",
    name: "Property tax information",
    categorySlug: "property-taxes",
    summary: "Understand how property tax is assessed, what it covers and where to check your dues.",
    description:
      "Property tax in Ahmedabad is levied by the Ahmedabad Municipal Corporation on property owners. This page explains the assessment cycle, the documents you are generally asked to keep ready, and how to verify your outstanding dues on the official AMC portals. Fee slabs and due dates are published by AMC — please confirm the current figures on the official portal before you pay.",
    requirements: [
      "Property details such as the address, survey / CTS number and the owner's name as per records.",
      "A recent municipal tax receipt, if available, to trace earlier payment history.",
      "Identity proof of the owner or authorised representative.",
    ],
    procedure: [
      "Note the property address and ward from your municipal tax receipt or AMC property search.",
      "Open the AMC e-Sampark portal and locate the property-tax section for assessment and dues details.",
      "Verify the outstanding amount and download the assessment receipt shown on the portal.",
      "Complete payment only on the official AMC payment gateway — One Ahmedabad never collects money.",
    ],
    documents: [
      "Property tax receipts (previous years)",
      "Identity / address proof",
      "Ownership or authorisation letter",
    ],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "hybrid",
    office: "Zone office of the Ahmedabad Municipal Corporation (AMC)",
    disclaimer:
      "Rates, due dates and rebate rules are set by AMC and may change — always confirm on the official portal.",
  },
  {
    slug: "professional-tax",
    name: "Professional tax",
    categorySlug: "property-taxes",
    summary: "Guidance for professionals and salaried employees on professional tax registration and payment.",
    description:
      "Professional tax is levied on persons employed in professions, trades, calling or occupations. AMC collects professional tax certificates and receipts through its tax section. This page tells you what the AMC process looks like and which portal to use, so you never pay through an unverified aggregator.",
    requirements: [
      "Proof of professional or employment status, as applicable.",
      "Address proof and identity proof of the assessee.",
      "Previous professional tax receipt, if already registered.",
    ],
    procedure: [
      "Confirm whether you are already enrolled for professional tax in the city of Ahmedabad.",
      "Use the AMC e-Sampark portal to reach the professional-tax service and check your certificate / receipt status.",
      "Pay the amount shown on the official portal and save the generated receipt.",
      "Contact your employer or the AMC tax section if a new enrolment certificate is required.",
    ],
    documents: ["Identity proof", "Address proof", "Employer details (for employees)"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "redirect",
    office: "AMC Tax Section, ward office",
    disclaimer:
      "Professional tax amounts are notified by the Government of Gujarat — no amount is quoted here.",
  },
  {
    slug: "tax-payment-portal",
    name: "Tax payment portal access",
    categorySlug: "property-taxes",
    summary: "Direct link to the official AMC tax payment portal and a checklist before you pay.",
    description:
      "One Ahmedabad does not process payments. Use the official AMC payment portal, check the payee name carefully, keep the transaction receipt, and use only the government domain (.gov.in) or the AMC application.",
    requirements: [
      "Property / tax account number printed on your AMC bill.",
      "A working mobile number linked with the property for OTP confirmation.",
      "Internet banking, UPI or a card for the official payment gateway.",
    ],
    procedure: [
      "Open the AMC e-Sampark portal from the official AMC website.",
      "Choose the tax payment service and enter the property or taxpayer identifier.",
      "Verify the amount, the property name and the ward before confirming.",
      "Download and store the payment receipt for your records.",
    ],
    documents: ["Property tax bill / account number", "Property card or 7/12 extract"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "redirect",
    office: "Online — AMC e-Sampark portal",
    disclaimer:
      "Prototype demo: no payment is collected, processed or simulated on this platform.",
  },
  {
    slug: "property-details-and-dues",
    name: "Property details and dues guidance",
    categorySlug: "property-taxes",
    summary: "Find where to check property records, 7/12 extracts and outstanding municipal dues.",
    description:
      "Property records and dues are maintained by AMC. This page points you to the right desk and portal for property details, occupancy details and outstanding dues, and explains what a good citizen-side verification looks like.",
    requirements: [
      "Property address, ward and CTS / survey number.",
      "Owner details as per the record, if it differs from your current documents.",
    ],
    procedure: [
      "Search the property on the AMC portal using the address, CTS number or owner name.",
      "If the record is missing or incorrect, visit or contact the concerned zone / ward office with proof of ownership.",
      "Ask for a written dues statement for the property.",
      "Use the official payment portal for any amount that is genuinely outstanding.",
    ],
    documents: ["7/12 extract or sale deed", "Identity proof", "Latest municipal bill"],
    officialPortalUrl: AMC_HOME,
    handlingMode: "hybrid",
    office: "AMC Zone / Ward office",
  },

  /* ---------------- Water & Drainage ---------------- */
  {
    slug: "water-connection-information",
    name: "Water connection information",
    categorySlug: "water-drainage",
    summary: "How a piped water connection is applied for, verified and activated by the water department.",
    description:
      "New water connections, change of use, reconnection and shifting of connections are handled by the Ahmedabad water department. This page summarises the general process and points to the official water department portal for the live application form.",
    requirements: [
      "Property ownership documents and a clear address with ward.",
      "Identity proof of the applicant.",
      "Site plan / building permission details where applicable for a new connection.",
    ],
    procedure: [
      "Apply through the official Ahmedabad water department portal for a new connection.",
      "Upload ownership and site documents and pay the government fee only on the portal.",
      "Schedule the site inspection / connection work as advised by the department.",
      "Receive the connection and start paying the metered consumption bill.",
    ],
    documents: ["Ownership documents", "Identity proof", "Site plan / sanctioned plan"],
    officialPortalUrl: AMC_WATER,
    handlingMode: "redirect",
    office: "Ahmedabad water department / ward office",
    disclaimer:
      "Connection charges and timelines are published by the water department — they are not quoted here.",
  },
  {
    slug: "drainage-connection-information",
    name: "Drainage connection information",
    categorySlug: "water-drainage",
    summary: "Guidance for storm-water drain connections, line clearance and sewer complaints.",
    description:
      "Storm-water drainage connections and sewer issues are handled by the AMC drainage section. Learn which desk owns your issue, what to submit for a connection, and how to escalate a blocked or overflowing drain.",
    requirements: [
      "Property details and the exact location of the drain / manhole.",
      "Photos that clearly show the blockage or the connection point.",
      "Ward identification of the affected stretch.",
    ],
    procedure: [
      "Identify whether the issue is a private connection, a public drain or a manhole.",
      "Submit the location with clear photographs and a landmark.",
      "Escalate through the AMC grievance channel if the response is not received.",
      "Use the civic complaint form in One Ahmedabad to keep a tracked reference for the demo workflow.",
    ],
    documents: ["Property details", "Site photographs", "Landmark / GPS coordinates if available"],
    officialPortalUrl: AMC_HOME,
    handlingMode: "hybrid",
    office: "AMC Drainage section, ward office",
  },
  {
    slug: "water-leakage-complaint",
    name: "Water leakage complaint",
    categorySlug: "water-drainage",
    summary: "Report a leaking main line, burst pipe or continuous seepage with a tracked reference number.",
    description:
      "Leakage in the distribution main, a burst pipe or a running tap in a public area wastes treated water and damages roads. Submit the complaint with a photograph, the exact landmark and the ward, and track every status change until it is resolved.",
    requirements: [
      "Accurate location: street, landmark and ward.",
      "A clear photograph of the leak, if safe to take one.",
      "An accessible contact number for the field team.",
    ],
    procedure: [
      "Fill the complaint form with the category, title, description and area.",
      "Attach a photograph of the leakage and note the landmark.",
      "Submit to receive a unique reference number.",
      "Track the reference and read the administrative remarks added at each stage.",
    ],
    documents: ["Photograph of the leakage", "Landmark details"],
    officialPortalUrl: AMC_WATER,
    handlingMode: "demo",
    office: "AMC water department / ward office",
    isComplaintType: true,
  },
  {
    slug: "water-supply-complaint",
    name: "Water supply complaint",
    categorySlug: "water-drainage",
    summary: "Report no supply, low pressure, dirty water or supply disruption in your area.",
    description:
      "Intermittent or absent supply, low pressure, contamination notices and supply interruptions are common grievances. This prototype records the complaint, generates a reference number and keeps the citizen informed at every stage.",
    requirements: [
      "Affected street / society name and ward.",
      "Duration and time of the disruption, if known.",
      "Photograph of the supply line, tank or affected area where relevant.",
    ],
    procedure: [
      "Choose 'Water supply complaint' and describe the disruption.",
      "Add the area, ward and a contactable number.",
      "Submit the complaint and save the reference number.",
      "Follow the status timeline for updates from the department.",
    ],
    documents: ["Photograph (optional)", "Society / street details"],
    officialPortalUrl: AMC_WATER,
    handlingMode: "demo",
    office: "AMC water department / ward office",
    isComplaintType: true,
  },

  /* ---------------- Certificates ---------------- */
  {
    slug: "birth-registration-certificate",
    name: "Birth registration & certificate",
    categorySlug: "certificates",
    summary: "How birth registration is done at the ward office and how to request a certified copy.",
    description:
      "Birth registration is carried out by the ward office of the Ahmedabad Municipal Corporation. Registration is time-bound by law, so register the birth as soon as possible. This prototype explains the process and the documents generally asked for; the certificate itself is issued only by the competent authority.",
    requirements: [
      "Parents' identity proof and a working contact number.",
      "Proof of the birth event as available with the reporting person.",
      "Hospital or institution birth record, if the birth took place in a hospital.",
    ],
    procedure: [
      "Report the birth at the ward office within the period prescribed by law.",
      "Submit the documents listed on this page together with the registration form.",
      "Collect the acknowledgement slip and note the registration reference.",
      "Apply for a certified copy through the official AMC service and collect it from the ward office.",
    ],
    documents: [
      "Identity proof of parents / guardian",
      "Hospital discharge summary or institution record",
      "Proof of residence",
    ],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "redirect",
    office: "AMC Ward office (Registrar of births)",
    disclaimer:
      "One Ahmedabad cannot issue or promise any government certificate — the ward office is the issuing authority.",
  },
  {
    slug: "death-registration-certificate",
    name: "Death registration & certificate",
    categorySlug: "certificates",
    summary: "Guidance for registering a death and obtaining a certified copy of the death certificate.",
    description:
      "Death registration is done by the ward office and the certificate is issued by the Registrar. This page lists the general documentation for registration and for a certified copy request, and links to the official AMC service entry point.",
    requirements: [
      "Identity proof of the informant and proof of the relationship.",
      "Medical certificate or cause-of-death record from the treating institution.",
      "Address details of the deceased and the place of residence.",
    ],
    procedure: [
      "Report the death at the ward office with the medical record.",
      "Complete the statutory form and pay the notified fee only on the official channel.",
      "Keep the acknowledgement slip and the registration number.",
      "Request certified copies through the official AMC service for legal and property purposes.",
    ],
    documents: [
      "Medical / cause-of-death certificate",
      "Identity proof of informant",
      "Proof of relationship or residence",
    ],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "redirect",
    office: "AMC Ward office (Registrar of deaths)",
    disclaimer: "Certificates are issued only by the competent authority, never by this prototype.",
  },
  {
    slug: "marriage-registration-information",
    name: "Marriage registration information",
    categorySlug: "certificates",
    summary: "Where and how a marriage is registered, and how to obtain a certified marriage certificate.",
    description:
      "Marriage registration is handled through the office of the concerned Registrar in Ahmedabad. This page explains the general sequence — registration, entry in the register, certified copy — and directs you to official AMC and State sources.",
    requirements: [
      "Identity proof of both parties with address and photograph.",
      "Age proof as per the applicable requirement.",
      "Witness details and their identity proof.",
    ],
    procedure: [
      "Visit the office of the concerned Registrar with both parties and witnesses.",
      "Complete the required forms and submit the supporting documents.",
      "Complete the registration formalities and collect the acknowledgement.",
      "Apply for a certified copy through the official service when needed for official purposes.",
    ],
    documents: ["Identity & address proof of both parties", "Witness details", "Age proof"],
    officialPortalUrl: AMC_HOME,
    handlingMode: "redirect",
    office: "Office of the Registrar, Ahmedabad",
    disclaimer: "No certificate is issued through this platform.",
  },

  /* ---------------- Licences & Permissions ---------------- */
  {
    slug: "shops-establishment-registration",
    name: "Shops & establishment registration",
    categorySlug: "licences-permissions",
    summary: "Steps to register a shop or establishment and where to apply for the licence.",
    description:
      "Registration and licensing of shops and establishments is governed by the Gujarat Shops and Establishments legislation and is administered through the concerned state / local office. This page gives the general checklist so you can approach the right desk with complete documents.",
    requirements: [
      "Premises details: address, carpet area and the nature of the establishment.",
      "Owner / proprietor identity and address proof.",
      "List of employees with details, where the establishment employs staff.",
    ],
    procedure: [
      "Prepare the registration or licence application with the premises details.",
      "Submit it at the office of the competent authority for your establishment.",
      "Respond to queries and inspection, if any.",
      "Display the registration or licence at the premises as required by law.",
    ],
    documents: [
      "Premises rent / ownership proof",
      "Identity & address proof of proprietor",
      "Employee details list",
    ],
    officialPortalUrl: AMC_HOME,
    handlingMode: "redirect",
    office: "Competent authority for shops & establishments, Ahmedabad",
    disclaimer:
      "The applicable act, forms and fee structure are notified by the State — verify before filing.",
  },
  {
    slug: "hawker-registration",
    name: "Hawker registration",
    categorySlug: "licences-permissions",
    summary: "How vending rights and hawker identity documents are arranged in Ahmedabad.",
    description:
      "Street vendors operate through vending zones and committee certificates issued by the competent local authority. This page summarises the general route to obtain a vending / hawker identity document and highlights the anti-eviction and identity safeguards that apply.",
    requirements: [
      "Proof of identity and a recent photograph, as required by the committee.",
      "Details of the vending location / zone and the type of trade.",
      "Proof of residence in the city.",
    ],
    procedure: [
      "Identify the vending zone and the committee responsible for it.",
      "Apply for vending registration / identity card with the committee.",
      "Attend the committee's verification, if required.",
      "Keep the certificate with the goods and cooperate with periodic verification drives.",
    ],
    documents: ["Identity proof", "Residence proof", "Passport-size photographs (as required)"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "redirect",
    office: "AMC Town Vending Committee / ward office",
    disclaimer: "Vending policy is decided by AMC and the Town Vending Committee.",
  },
  {
    slug: "building-permission-information",
    name: "Building permission information",
    categorySlug: "licences-permissions",
    summary: "Where to apply for building permission and how to check the status of an application.",
    description:
      "Building permission for construction, alteration or change of use is granted by the Ahmedabad Municipal Corporation. This page explains the general process and the documents commonly required, and points to the official AMC portal for the live application and status.",
    requirements: [
      "Approved or sanctioned site plan with dimensions and setbacks.",
      "Ownership documents of the plot.",
      "Structural and other drawings as required for the proposal.",
    ],
    procedure: [
      "Prepare the drawings and documents for the proposal.",
      "Apply through the official AMC building permission service.",
      "Track the application status and respond to queries.",
      "Start construction only after the sanction is issued, and apply for the completion certificate when finished.",
    ],
    documents: [
      "7/12 extract / ownership documents",
      "Site plan and building drawings",
      "Structural safety information",
    ],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "redirect",
    office: "AMC Town Planning / building permission section",
    disclaimer:
      "No approval, sanction or fee is simulated here — only guidance to the official process.",
  },

  /* ---------------- Civic Services (in-platform complaints) ---------------- */
  {
    slug: "garbage-collection-complaint",
    name: "Garbage collection complaint",
    categorySlug: "civic-services",
    summary: "Report missed door-to-door collection, illegal dumping or overflowing bins.",
    description:
      "Missed household collection, overflowing community bins and illegal waste dumping are among the most reported civic grievances. Register the complaint with a photograph and exact location to get a tracked reference number.",
    requirements: [
      "Exact location: street, society or landmark, and the ward.",
      "A photograph showing the waste pile or the bin.",
      "An approximate date and time when the issue was noticed.",
    ],
    procedure: [
      "Select 'Garbage collection' as the complaint category.",
      "Describe the issue and add the location details.",
      "Attach a photograph and submit.",
      "Track the reference number and the remarks added by the department.",
    ],
    documents: ["Photograph of the waste pile", "Location details"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC solid waste / ward office",
    isComplaintType: true,
  },
  {
    slug: "potholes-damaged-roads",
    name: "Potholes & damaged roads",
    categorySlug: "civic-services",
    summary: "Report potholes, broken road surfaces, dividers and open manholes on the carriageway.",
    description:
      "Potholes and damaged road stretches put two-wheelers, cyclists and pedestrians at risk. Report the exact location with a photograph so the road maintenance team can act on it.",
    requirements: [
      "Exact spot with the nearest landmark and the ward.",
      "A photograph showing the pothole or damaged stretch.",
      "Approximate size or number of affected locations.",
    ],
    procedure: [
      "Pick 'Potholes / damaged roads' in the complaint form.",
      "Pinpoint the location and describe the damage.",
      "Upload the photograph and submit for a reference number.",
      "Follow the status until the work is marked resolved.",
    ],
    documents: ["Photograph", "Landmark details"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC roads / ward office",
    isComplaintType: true,
  },
  {
    slug: "streetlight-complaint",
    name: "Streetlight complaint",
    categorySlug: "civic-services",
    summary: "Report a non-working, flickering or permanently dark streetlight.",
    description:
      "Non-functional streetlights reduce safety, especially for women and night-shift workers. Report the pole number if it is painted on the fixture, otherwise give the exact location.",
    requirements: [
      "Pole number or exact location of the fixture.",
      "Ward / zone of the street.",
      "Photograph of the dark or damaged light.",
    ],
    procedure: [
      "Choose 'Streetlight' as the complaint category.",
      "Enter the pole number or the nearest landmark.",
      "Attach a photograph taken at night, if possible.",
      "Submit and track the repair status.",
    ],
    documents: ["Photograph", "Pole number / landmark"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC street lighting / ward office",
    isComplaintType: true,
  },
  {
    slug: "drainage-overflow",
    name: "Drainage overflow",
    categorySlug: "civic-services",
    summary: "Report overflowing drains, waterlogging and blocked stormwater lines.",
    description:
      "During and after monsoon, blocked stormwater drains cause waterlogging and health hazards. Report the affected stretch with a photograph so the drainage team can clear it.",
    requirements: [
      "Location of the overflowing drain or the waterlogged stretch.",
      "Photograph showing the water level or the blocked grate.",
      "Whether nearby houses or shops are affected.",
    ],
    procedure: [
      "Select 'Drainage overflow' as the category.",
      "Describe the waterlogging and the affected area.",
      "Attach the photograph and submit.",
      "Track the clearance work through the reference number.",
    ],
    documents: ["Photograph", "Affected area details"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC drainage / ward office",
    isComplaintType: true,
  },
  {
    slug: "open-manhole",
    name: "Open manhole",
    categorySlug: "civic-services",
    summary: "Report an uncovered manhole or open drain without a cover — treated as a priority hazard.",
    description:
      "Uncovered manholes are an immediate safety hazard. In this prototype, open-manhole complaints are flagged as priority complaints in the administrator dashboard.",
    requirements: [
      "Exact location with a landmark, and the ward.",
      "A photograph showing the open manhole.",
      "Whether traffic or pedestrians are directly at risk.",
    ],
    procedure: [
      "Select 'Open manhole' and describe the hazard.",
      "Add the location and a photograph.",
      "Submit — the complaint is marked as a priority in the admin queue.",
      "Track the barricade and repair updates.",
    ],
    documents: ["Photograph", "Location details"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC drainage / ward office",
    isComplaintType: true,
  },
  {
    slug: "public-cleanliness-issue",
    name: "Public cleanliness issue",
    categorySlug: "civic-services",
    summary: "Report unclean public places, overflowing bins, encroachments affecting hygiene or damaged dustbins.",
    description:
      "Public spaces around markets, bus stops, gardens and river fronts need consistent cleaning. Report unclean areas, damaged dustbins and hygiene issues with a photograph for faster action.",
    requirements: [
      "Location of the unclean area.",
      "Photograph showing the issue.",
      "Nature of the problem: waste, dust, spill, damaged bin, etc.",
    ],
    procedure: [
      "Choose 'Public cleanliness' in the complaint form.",
      "Describe the area and the problem.",
      "Attach the photograph and submit.",
      "Follow the sanitisation status updates.",
    ],
    documents: ["Photograph", "Area details"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC solid waste / ward office",
    isComplaintType: true,
  },

  /* ---------------- Public Facilities ---------------- */
  {
    slug: "community-hall-booking",
    name: "Community hall booking",
    categorySlug: "public-facilities",
    summary: "Send a booking request for an AMC community hall and track its acknowledgement.",
    description:
      "AMC community halls are booked for events such as weddings, community meetings and public programmes. In this prototype you can submit a booking request and track its acknowledgement. The actual reservation, deposit and schedule are confirmed by the AMC office and are not guaranteed here.",
    requirements: [
      "Preferred hall name or location, and the event date and time window.",
      "Expected headcount and the nature of the event.",
      "Contact details of the organiser.",
    ],
    procedure: [
      "Submit the booking request with the hall, date and purpose.",
      "Track the acknowledgement and the office remarks in your dashboard.",
      "Confirm the reservation, timing and deposit directly with the AMC office.",
      "Follow the hall condition rules published by AMC.",
    ],
    documents: ["Organiser identity proof", "Event details"],
    officialPortalUrl: AMC_SAMPARK,
    handlingMode: "demo",
    office: "AMC Community hall / ward office",
    disclaimer:
      "This is a prototype request workflow — it is not a confirmed reservation and no deposit is accepted.",
    isComplaintType: true,
  },
  {
    slug: "swimming-pools",
    name: "Swimming pools",
    categorySlug: "public-facilities",
    summary: "Information on municipal swimming pools, timings and how to enquire about a lane.",
    description:
      "Ahmedabad Municipal Corporation operates public swimming pools for residents. Timings, fees and lane availability are published by AMC at the pool and on its official channels, and can change during maintenance periods.",
    requirements: [
      "Identity proof and, where applicable, a student or senior-citizen concession proof.",
      "Confirmation of the required facility: swimming lane, coaching or timings.",
    ],
    procedure: [
      "Identify the pool you want to use from the AMC facility list.",
      "Check the published timings and fee structure at the pool or on the AMC channel.",
      "Enquire about lane allocation or coaching at the pool office.",
      "Carry identification and follow pool safety rules.",
    ],
    documents: ["Identity proof", "Concession proof, if applicable"],
    officialPortalUrl: AMC_HOME,
    handlingMode: "redirect",
    office: "AMC Sports / pool office",
    disclaimer: "Timings and fees are published by AMC and are not quoted on this page.",
  },
  {
    slug: "gymnasiums",
    name: "Gymnasiums",
    categorySlug: "public-facilities",
    summary: "Find AMC community gymnasiums, opening hours and membership enquiries.",
    description:
      "Community gymnasiums provided by AMC offer affordable fitness facilities for residents. Membership rules, timings and current charges are confirmed at the gym office or the AMC facility listing.",
    requirements: [
      "Identity proof and address proof.",
      "Medical fitness information, if requested for specific programmes.",
    ],
    procedure: [
      "Locate the gym through the AMC facility list or your ward office.",
      "Visit during working hours and ask about membership and batch timings.",
      "Complete registration at the gym office and collect the membership card.",
      "Follow the equipment and usage rules of the facility.",
    ],
    documents: ["Identity proof", "Address proof"],
    officialPortalUrl: AMC_HOME,
    handlingMode: "redirect",
    office: "AMC Sports / ward office",
    disclaimer: "Membership charges and timings are decided by AMC.",
  },
  {
    slug: "parks-and-gardens",
    name: "Parks & gardens",
    categorySlug: "public-facilities",
    summary: "Locate municipal parks and report issues such as broken equipment, lighting or waste.",
    description:
      "AMC maintains gardens and parks across the city. You can browse the information about the parks and use the complaint workflow to flag broken equipment, poor lighting or waste accumulation inside a park.",
    requirements: [
      "Name or location of the park and the ward.",
      "Photograph for any maintenance issue.",
      "Details of the specific facility that needs attention.",
    ],
    procedure: [
      "Open the park details to see the general information.",
      "Report an issue using the complaint form with the park name as the area.",
      "Attach a photograph of the damaged asset or waste.",
      "Track the maintenance status via the reference number.",
    ],
    documents: ["Photograph", "Park name and ward"],
    officialPortalUrl: AMC_HOME,
    handlingMode: "demo",
    office: "AMC Gardens / ward office",
    isComplaintType: true,
  },
];

export const serviceBySlug = new Map(serviceSeed.map((s) => [s.slug, s]));

export const complaintCategories = serviceSeed.filter((s) => s.isComplaintType);
