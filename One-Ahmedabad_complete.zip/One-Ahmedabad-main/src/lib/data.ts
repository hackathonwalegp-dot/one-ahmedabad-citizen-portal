import { and, count, desc, eq, gte, ilike, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  announcements,
  applications,
  complaintEvents,
  complaints,
  notifications,
  payments,
  properties,
  serviceCategories,
  services,
  supportTickets,
  users,
} from "@/db/schema";

/* ------------------------------ services ------------------------------ */

export async function getServiceCategories() {
  return db.select().from(serviceCategories).orderBy(serviceCategories.sortOrder);
}

export async function getServices(options?: {
  q?: string;
  category?: string;
  limit?: number;
}) {
  const { q, category, limit } = options ?? {};
  const conditions = [eq(services.isActive, true)];

  if (category && category !== "all") {
    conditions.push(eq(services.categorySlug, category));
  }

  if (q && q.trim()) {
    const term = `%${q.trim()}%`;
    conditions.push(
      or(
        ilike(services.name, term),
        ilike(services.summary, term),
        ilike(services.description, term),
        ilike(services.categorySlug, term),
      )!,
    );
  }

  const query = db
    .select({
      service: services,
      categoryName: serviceCategories.name,
      categoryIcon: serviceCategories.icon,
      accent: serviceCategories.accent,
    })
    .from(services)
    .innerJoin(serviceCategories, eq(serviceCategories.slug, services.categorySlug))
    .where(and(...conditions))
    .orderBy(serviceCategories.sortOrder, services.name);

  const rows = await (limit ? query.limit(limit) : query);
  return rows.map((row) => ({
    ...row.service,
    categoryName: row.categoryName,
    categoryIcon: row.categoryIcon,
    accent: row.accent,
  }));
}

export async function getServiceBySlug(slug: string) {
  const rows = await db
    .select({
      service: services,
      categoryName: serviceCategories.name,
      categoryIcon: serviceCategories.icon,
      accent: serviceCategories.accent,
    })
    .from(services)
    .innerJoin(serviceCategories, eq(serviceCategories.slug, services.categorySlug))
    .where(eq(services.slug, slug))
    .limit(1);
  if (!rows.length) return null;
  const row = rows[0];
  return {
    ...row.service,
    categoryName: row.categoryName,
    categoryIcon: row.categoryIcon,
    accent: row.accent,
  };
}

/* ---------------------------- announcements ---------------------------- */

export async function getPublishedAnnouncements(limit?: number) {
  const query = db
    .select()
    .from(announcements)
    .where(eq(announcements.isPublished, true))
    .orderBy(desc(announcements.publishedAt));

  return limit ? query.limit(limit) : query;
}

/* ------------------------------ complaints ----------------------------- */

export async function getCitizenComplaints(userId: number) {
  return db
    .select()
    .from(complaints)
    .where(eq(complaints.userId, userId))
    .orderBy(desc(complaints.createdAt));
}

export async function getCitizenComplaintStats(userId: number) {
  const rows = await db
    .select({ status: complaints.status, value: count() })
    .from(complaints)
    .where(eq(complaints.userId, userId))
    .groupBy(complaints.status);

  const totals = {
    total: 0,
    pending: 0,
    resolved: 0,
    rejected: 0,
    inProgress: 0,
  };

  for (const row of rows) {
    totals.total += row.value;
    if (row.status === "Resolved") totals.resolved += row.value;
    else if (row.status === "Rejected") totals.rejected += row.value;
    else if (row.status === "In Progress" || row.status === "Assigned") {
      totals.inProgress += row.value;
      totals.pending += row.value;
    } else totals.pending += row.value;
  }

  return totals;
}

export async function getComplaintEvents(complaintIds: number[]) {
  if (!complaintIds.length) return [];
  return db
    .select()
    .from(complaintEvents)
    .where(inArray(complaintEvents.complaintId, complaintIds))
    .orderBy(desc(complaintEvents.createdAt));
}

export async function getAdminStats() {
  const statusRows = await db
    .select({ status: complaints.status, value: count() })
    .from(complaints)
    .groupBy(complaints.status);

  const [totalRow] = await db.select({ value: count() }).from(complaints);
  const [userRow] = await db.select({ value: count() }).from(users);
  const [serviceRow] = await db.select({ value: count() }).from(services);
  const [announcementRow] = await db
    .select({ value: count() })
    .from(announcements)
    .where(eq(announcements.isPublished, true));

  const byStatus: Record<string, number> = {};
  for (const row of statusRows) byStatus[row.status] = row.value;

  const open = Object.entries(byStatus)
    .filter(([status]) => status !== "Resolved" && status !== "Rejected")
    .reduce((sum, [, value]) => sum + value, 0);

  return {
    total: totalRow.value,
    open,
    resolved: byStatus.Resolved ?? 0,
    rejected: byStatus.Rejected ?? 0,
    byStatus,
    citizens: userRow.value,
    services: serviceRow.value,
    announcements: announcementRow.value,
  };
}

/* ----------------------------- notifications --------------------------- */

export async function getNotifications(userId: number, limit?: number) {
  const query = db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
  return limit ? query.limit(limit) : query;
}

export async function getUnreadNotificationCount(userId: number) {
  const [row] = await db
    .select({ value: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return row.value;
}

/* -------------------------------- search ------------------------------- */

export async function searchServices(term: string, limit = 8) {
  const pattern = `%${term.trim()}%`;
  const rows = await db
    .select({
      slug: services.slug,
      name: services.name,
      summary: services.summary,
      categoryName: serviceCategories.name,
      handlingMode: services.handlingMode,
    })
    .from(services)
    .innerJoin(serviceCategories, eq(serviceCategories.slug, services.categorySlug))
    .where(
      and(
        eq(services.isActive, true),
        or(
          ilike(services.name, pattern),
          ilike(services.summary, pattern),
          ilike(services.description, pattern),
        ),
      ),
    )
    .limit(limit);

  return rows;
}

export async function getCategoryCounts() {
  const rows = await db
    .select({ slug: serviceCategories.slug, value: count() })
    .from(serviceCategories)
    .leftJoin(services, eq(services.categorySlug, serviceCategories.slug))
    .groupBy(serviceCategories.slug);
  const map: Record<string, number> = {};
  for (const row of rows) map[row.slug] = row.value;
  return map;
}



/* ------------------------------ applications --------------------------- */

export async function getCitizenApplications(userId: number) {
  return db
    .select()
    .from(applications)
    .where(eq(applications.userId, userId))
    .orderBy(desc(applications.createdAt));
}

export async function getCitizenApplicationStats(userId: number) {
  const rows = await db
    .select({ status: applications.status, value: count() })
    .from(applications)
    .where(eq(applications.userId, userId))
    .groupBy(applications.status);
  const totals = { total: 0, pending: 0, approved: 0, rejected: 0 };
  for (const row of rows) {
    totals.total += row.value;
    if (row.status === "Approved") totals.approved += row.value;
    else if (row.status === "Rejected") totals.rejected += row.value;
    else totals.pending += row.value;
  }
  return totals;
}

/* ------------------------- properties and payments --------------------- */

/** A property with the amount already paid and the outstanding balance. */
export async function getPropertySummaries(userId: number) {
  const rows = await db
    .select({
      property: properties,
      paid: sql<number>`coalesce(sum(${payments.amount}), 0)`.mapWith(Number),
    })
    .from(properties)
    .leftJoin(payments, eq(payments.propertyId, properties.id))
    .where(eq(properties.userId, userId))
    .groupBy(properties.id)
    .orderBy(desc(properties.createdAt));
  return rows.map((row) => ({
    ...row.property,
    paid: row.paid,
    outstanding: Math.max(0, row.property.assessmentAmount - row.paid),
  }));
}

export async function getCitizenPayments(userId: number) {
  return db
    .select({ payment: payments, property: properties })
    .from(payments)
    .innerJoin(properties, eq(properties.id, payments.propertyId))
    .where(eq(payments.userId, userId))
    .orderBy(desc(payments.paidAt));
}

export async function getOutstandingTotal(userId: number) {
  const list = await getPropertySummaries(userId);
  return list.reduce((sum, item) => sum + item.outstanding, 0);
}

/* ------------------------------ platform stats ------------------------- */

export async function getPlatformStats() {
  const [applicationRows, citizenRows, operatorRows, ticketRows, paymentRows] = await Promise.all([
    db.select({ status: applications.status, value: count() }).from(applications).groupBy(applications.status),
    db.select({ value: count() }).from(users).where(eq(users.role, "citizen")),
    db.select({ value: count() }).from(users).where(eq(users.role, "operator")),
    db.select({ status: supportTickets.status, value: count() }).from(supportTickets).groupBy(supportTickets.status),
    db
      .select({
        value: count(),
        total: sql<number>`coalesce(sum(${payments.amount}), 0)`.mapWith(Number),
      })
      .from(payments),
  ]);

  const applicationsByStatus: Record<string, number> = {};
  for (const row of applicationRows) applicationsByStatus[row.status] = row.value;
  const ticketsByStatus: Record<string, number> = {};
  for (const row of ticketRows) ticketsByStatus[row.status] = row.value;

  const applicationTotal = Object.values(applicationsByStatus).reduce((a, b) => a + b, 0);
  const applicationPending =
    (applicationsByStatus.Submitted ?? 0) + (applicationsByStatus["Under Review"] ?? 0);

  return {
    applicationsByStatus,
    applicationTotal,
    applicationPending,
    citizens: citizenRows[0]?.value ?? 0,
    operators: operatorRows[0]?.value ?? 0,
    ticketsOpen: ticketsByStatus.Open ?? 0,
    ticketTotal: Object.values(ticketsByStatus).reduce((a, b) => a + b, 0),
    paymentCount: paymentRows[0]?.value ?? 0,
    paymentTotal: paymentRows[0]?.total ?? 0,
  };
}

/** Complaints and applications created per month for the last `months` months. */
export async function getMonthlyActivity(months = 6) {
  const since = new Date();
  since.setDate(1);
  since.setHours(0, 0, 0, 0);
  since.setMonth(since.getMonth() - (months - 1));

  const [complaintRows, applicationRows] = await Promise.all([
    db
      .select({
        month: sql<string>`to_char(${complaints.createdAt}, 'YYYY-MM')`,
        value: count(),
      })
      .from(complaints)
      .where(gte(complaints.createdAt, since))
      .groupBy(sql`to_char(${complaints.createdAt}, 'YYYY-MM')`),
    db
      .select({
        month: sql<string>`to_char(${applications.createdAt}, 'YYYY-MM')`,
        value: count(),
      })
      .from(applications)
      .where(gte(applications.createdAt, since))
      .groupBy(sql`to_char(${applications.createdAt}, 'YYYY-MM')`),
  ]);

  const series: { key: string; label: string; complaints: number; applications: number }[] = [];
  for (let i = 0; i < months; i += 1) {
    const d = new Date(since.getFullYear(), since.getMonth() + i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    series.push({
      key,
      label: d.toLocaleDateString("en-IN", { month: "short" }),
      complaints: complaintRows.find((row) => row.month === key)?.value ?? 0,
      applications: applicationRows.find((row) => row.month === key)?.value ?? 0,
    });
  }
  return series;
}

export async function getComplaintsByService(limit = 8) {
  const rows = await db
    .select({ name: complaints.serviceName, value: count() })
    .from(complaints)
    .groupBy(complaints.serviceName)
    .orderBy(desc(count()))
    .limit(limit);
  return rows;
}

export async function getApplicationsByType() {
  return db
    .select({ name: applications.type, value: count() })
    .from(applications)
    .groupBy(applications.type)
    .orderBy(desc(count()));
}

/** Open workload per department across complaints and applications. */
export async function getDepartmentWorkload() {
  const [complaintRows, applicationRows] = await Promise.all([
    db
      .select({ department: complaints.assignedTo, status: complaints.status, value: count() })
      .from(complaints)
      .groupBy(complaints.assignedTo, complaints.status),
    db
      .select({ department: applications.assignedTo, status: applications.status, value: count() })
      .from(applications)
      .groupBy(applications.assignedTo, applications.status),
  ]);

  const map = new Map<string, { department: string; open: number; closed: number }>();
  const add = (department: string | null, status: string, value: number, closedStatuses: string[]) => {
    const key = department?.trim() || "Unassigned";
    const entry = map.get(key) ?? { department: key, open: 0, closed: 0 };
    if (closedStatuses.includes(status)) entry.closed += value;
    else entry.open += value;
    map.set(key, entry);
  };
  for (const row of complaintRows) add(row.department, row.status, row.value, ["Resolved", "Rejected"]);
  for (const row of applicationRows) add(row.department, row.status, row.value, ["Approved", "Rejected"]);
  return Array.from(map.values()).sort((a, b) => b.open - a.open);
}
