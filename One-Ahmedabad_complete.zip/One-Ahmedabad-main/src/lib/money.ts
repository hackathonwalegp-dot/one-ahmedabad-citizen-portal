export const PAYMENT_METHODS = ["UPI (demo)", "Debit card (demo)", "Net banking (demo)"] as const;

export function formatRupees(value: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
}
