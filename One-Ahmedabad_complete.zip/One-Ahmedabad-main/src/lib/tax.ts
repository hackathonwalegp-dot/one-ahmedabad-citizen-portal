import { createHash, randomInt } from "node:crypto";

/** Financial-year label such as "2026–27" (the Indian year starts in April). */
export function currentAssessmentYear(now = new Date()): string {
  const start = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  return `${start}–${String((start + 1) % 100).padStart(2, "0")}`;
}

/**
 * Deterministic, clearly illustrative assessment in rupees (2,500 – 9,950).
 * It is NOT calculated from any AMC rate card.
 */
export function demoAssessment(address: string, ward: string | null): number {
  const digest = createHash("sha256").update(`${address.toLowerCase()}|${ward ?? ""}`).digest();
  const raw = digest.readUInt16BE(0) % 7450;
  return Math.round((2500 + raw) / 50) * 50;
}

export function propertyCode(): string {
  return `PR-AMD-${randomInt(100000, 999999)}`;
}

