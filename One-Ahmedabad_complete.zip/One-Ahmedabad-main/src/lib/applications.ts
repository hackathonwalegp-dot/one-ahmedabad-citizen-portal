export const APPLICATION_STATUSES = ["Submitted", "Under Review", "Approved", "Rejected"] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

export const APPLICATION_FLOW: ApplicationStatus[] = ["Submitted", "Under Review", "Approved"];

export function isApplicationStatus(value: string): value is ApplicationStatus {
  return (APPLICATION_STATUSES as readonly string[]).includes(value);
}

export const applicationStatusDescription: Record<ApplicationStatus, string> = {
  Submitted: "The application has been received and is waiting for a clerk to pick it up.",
  "Under Review": "An officer is checking the details and the supporting document.",
  Approved: "The application was approved. In this prototype no real certificate or licence is issued.",
  Rejected: "The application was closed without approval. Please read the remarks for the reason.",
};

export type ApplicationTypeInfo = {
  name: string;
  department: string;
  summary: string;
  documents: string[];
};

export const APPLICATION_TYPES: ApplicationTypeInfo[] = [
  {
    name: "Birth Certificate",
    department: "Civil Registration",
    summary: "Request a certified copy of a birth registration.",
    documents: ["Hospital birth record or discharge slip", "Parent identity proof", "Address proof"],
  },
  {
    name: "Death Certificate",
    department: "Civil Registration",
    summary: "Request a certified copy of a death registration.",
    documents: ["Medical certificate of cause of death", "Identity proof of the applicant", "Address proof"],
  },
  {
    name: "Trade Licence",
    department: "Licensing Department",
    summary: "Start a new trade or shop licence request.",
    documents: ["Identity proof of the owner", "Premises ownership or rent proof", "Passport size photograph"],
  },
  {
    name: "Municipal Permit",
    department: "Licensing Department",
    summary: "Request a municipal permission such as a hawker or event permit.",
    documents: ["Identity proof", "Site plan or location sketch", "Purpose statement"],
  },
  {
    name: "Other Certificate",
    department: "Public Grievance Cell",
    summary: "Request any other civic certificate or document.",
    documents: ["Identity proof", "Any document that supports the request"],
  },
];

export function applicationType(name: string): ApplicationTypeInfo | undefined {
  return APPLICATION_TYPES.find((item) => item.name === name);
}

/**
 * Service directory entries that can be started inside the prototype.
 * The service detail page shows an extra button for these slugs.
 */
export const PROTOTYPE_ACTIONS: Record<string, { href: string; label: string }> = {
  "birth-registration-certificate": {
    href: "/dashboard/applications/new?type=Birth%20Certificate",
    label: "Start a prototype application",
  },
  "death-registration-certificate": {
    href: "/dashboard/applications/new?type=Death%20Certificate",
    label: "Start a prototype application",
  },
  "shops-establishment-registration": {
    href: "/dashboard/applications/new?type=Trade%20Licence",
    label: "Start a prototype application",
  },
  "hawker-registration": {
    href: "/dashboard/applications/new?type=Municipal%20Permit",
    label: "Start a prototype application",
  },
  "building-permission-information": {
    href: "/dashboard/applications/new?type=Municipal%20Permit",
    label: "Start a prototype application",
  },
  "property-tax-information": { href: "/dashboard/payments", label: "Open the demo tax simulator" },
  "property-details-and-dues": { href: "/dashboard/payments", label: "Open the demo tax simulator" },
  "tax-payment-portal": { href: "/dashboard/payments", label: "Open the demo tax simulator" },
};
