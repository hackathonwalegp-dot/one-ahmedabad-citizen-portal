import { db } from "@/db";
import { notifications } from "@/db/schema";

export async function notifyUser(
  userId: number,
  item: { title: string; body: string; type?: string; link?: string | null },
) {
  await db.insert(notifications).values({
    userId,
    title: item.title,
    body: item.body,
    type: item.type ?? "system",
    link: item.link ?? null,
  });
}
