import { randomInt } from "node:crypto";

/**
 * Generates a human friendly reference such as AMC-APP-2026-483920.
 * `exists` lets each table check collisions in its own column.
 */
export async function uniqueReference(
  prefix: string,
  exists: (candidate: string) => Promise<boolean>,
): Promise<string> {
  const year = new Date().getFullYear();
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const candidate = `${prefix}-${year}-${randomInt(100000, 999999)}`;
    if (!(await exists(candidate))) return candidate;
  }
  return `${prefix}-${year}-${Date.now().toString().slice(-6)}`;
}

/** Temporary password for accounts created by service-centre staff. */
export function temporaryPassword(): string {
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz";
  const digits = "23456789";
  let out = "";
  for (let i = 0; i < 6; i += 1) out += letters[randomInt(letters.length)];
  for (let i = 0; i < 3; i += 1) out += digits[randomInt(digits.length)];
  return out;
}
