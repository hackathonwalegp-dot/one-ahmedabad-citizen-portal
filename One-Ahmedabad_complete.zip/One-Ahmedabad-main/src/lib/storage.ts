import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024; // 5 MB

const ALLOWED_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

const DOCUMENT_TYPES: Record<string, string> = {
  ...ALLOWED_TYPES,
  "application/pdf": "pdf",
};

export const UPLOAD_ROOT = path.join(process.cwd(), "var", "uploads");

export type UploadResult = { ok: true; key: string } | { ok: false; error: string };

/**
 * Saves an uploaded image outside the public folder and returns a key that is
 * served through `/api/files/<key>`.
 */
export async function saveUpload(
  file: File,
  options?: { folder?: string; allowPdf?: boolean },
): Promise<UploadResult> {
  const extension = (options?.allowPdf ? DOCUMENT_TYPES : ALLOWED_TYPES)[file.type];
  if (!extension) {
    return {
      ok: false,
      error: options?.allowPdf
        ? "Only PDF, JPG, PNG, WEBP or GIF files are accepted."
        : "Only JPG, PNG, WEBP or GIF images are accepted.",
    };
  }
  if (file.size <= 0) {
    return { ok: false, error: "The selected file is empty." };
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return { ok: false, error: "Image size must be under 5 MB." };
  }

  const key = `${Date.now()}-${randomUUID()}.${extension}`;
  const folderName = options?.folder ?? "complaints";
  const folder = path.join(UPLOAD_ROOT, folderName);
  await mkdir(folder, { recursive: true });

  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(folder, key), buffer);

  return { ok: true, key: `${folderName}/${key}` };
}

/** Guards against path traversal when serving stored files. */
export function resolveUploadPath(key: string): string | null {
  const decoded = decodeURIComponent(key).replace(/^\/+/, "");
  if (!decoded || decoded.includes("..") || decoded.includes("\\")) return null;
  const full = path.join(UPLOAD_ROOT, decoded);
  if (!full.startsWith(UPLOAD_ROOT)) return null;
  return full;
}
