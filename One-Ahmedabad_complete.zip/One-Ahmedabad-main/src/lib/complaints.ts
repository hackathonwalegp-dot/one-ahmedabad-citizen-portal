export const COMPLAINT_STATUSES = [
  "Submitted",
  "Under Review",
  "Assigned",
  "In Progress",
  "Resolved",
  "Rejected",
] as const;

export type ComplaintStatus = (typeof COMPLAINT_STATUSES)[number];

export const STATUS_FLOW: ComplaintStatus[] = [
  "Submitted",
  "Under Review",
  "Assigned",
  "In Progress",
  "Resolved",
];

export type StatusMeta = {
  label: string;
  badge: string;
  dot: string;
  bar: string;
  description: string;
};

export const statusMeta: Record<ComplaintStatus, StatusMeta> = {
  Submitted: {
    label: "Submitted",
    badge: "bg-slate-100 text-slate-700 ring-slate-200",
    dot: "bg-slate-400",
    bar: "bg-slate-400",
    description: "Your complaint has been recorded and is queued for review.",
  },
  "Under Review": {
    label: "Under Review",
    badge: "bg-sky-50 text-sky-700 ring-sky-200",
    dot: "bg-sky-500",
    bar: "bg-sky-500",
    description: "An officer is verifying the details and location of the complaint.",
  },
  Assigned: {
    label: "Assigned",
    badge: "bg-indigo-50 text-indigo-700 ring-indigo-200",
    dot: "bg-indigo-500",
    bar: "bg-indigo-500",
    description: "The complaint has been allotted to the concerned department or ward team.",
  },
  "In Progress": {
    label: "In Progress",
    badge: "bg-amber-50 text-amber-800 ring-amber-200",
    dot: "bg-amber-500",
    bar: "bg-amber-500",
    description: "Field work has started on the complaint.",
  },
  Resolved: {
    label: "Resolved",
    badge: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    dot: "bg-emerald-500",
    bar: "bg-emerald-500",
    description: "The complaint has been completed and closed.",
  },
  Rejected: {
    label: "Rejected",
    badge: "bg-rose-50 text-rose-700 ring-rose-200",
    dot: "bg-rose-500",
    bar: "bg-rose-500",
    description: "The complaint was closed without action. Please read the remarks.",
  },
};

export const PRIORITY_COMPLAINT_SLUGS = new Set(["open-manhole"]);

export function isComplaintStatus(value: string): value is ComplaintStatus {
  return (COMPLAINT_STATUSES as readonly string[]).includes(value);
}

export function statusIndex(status: string): number {
  return COMPLAINT_STATUSES.indexOf(status as ComplaintStatus);
}

/** Extra statuses used by applications and support tickets. */
const extraStatusMeta: Record<string, StatusMeta> = {
  Approved: {
    label: "Approved",
    badge: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    dot: "bg-emerald-500",
    bar: "bg-emerald-500",
    description: "The application was approved.",
  },
  Open: {
    label: "Open",
    badge: "bg-amber-50 text-amber-800 ring-amber-200",
    dot: "bg-amber-500",
    bar: "bg-amber-500",
    description: "Waiting for a reply from the support desk.",
  },
  Answered: {
    label: "Answered",
    badge: "bg-sky-50 text-sky-700 ring-sky-200",
    dot: "bg-sky-500",
    bar: "bg-sky-500",
    description: "The support desk has replied.",
  },
  Closed: {
    label: "Closed",
    badge: "bg-slate-100 text-slate-700 ring-slate-200",
    dot: "bg-slate-400",
    bar: "bg-slate-400",
    description: "This ticket is closed.",
  },
  Success: {
    label: "Success",
    badge: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    dot: "bg-emerald-500",
    bar: "bg-emerald-500",
    description: "Simulated payment completed.",
  },
};

/** Looks up display styles for any complaint, application, ticket or payment status. */
export function getStatusMeta(status: string): StatusMeta {
  return (
    (statusMeta as Record<string, StatusMeta>)[status] ??
    extraStatusMeta[status] ??
    statusMeta.Submitted
  );
}
