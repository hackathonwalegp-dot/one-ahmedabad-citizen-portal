/**
 * AI citizen assistant — deterministic, verifiable knowledge layer.
 *
 * Rules:
 *  1. The assistant only answers from the service directory stored in the
 *     database. It never invents fees, timelines, eligibility rules or
 *     government processes.
 *  2. When a question is out of scope it says so and points to the official
 *     AMC / State portal or the service directory.
 *  3. The engine is deliberately provider-agnostic: `answerQuestion` is the
 *     rule-based fallback used when no external model is configured. A hosted
 *     model can be plugged in at the API route level (see /api/assistant).
 */

export type AssistantService = {
  slug: string;
  name: string;
  summary: string;
  categoryName: string;
  categorySlug: string;
  handlingMode: string;
  officialPortalUrl: string | null;
  isComplaintType: boolean;
  procedure: string[];
  requirements: string[];
  documents: string[];
  office: string | null;
};

export type AssistantMatch = {
  slug: string;
  name: string;
  categoryName: string;
  summary: string;
  handlingMode: string;
};

export type AssistantReply = {
  reply: string;
  matches: AssistantMatch[];
  suggestions: string[];
  source: "directory" | "faq" | "fallback";
};

type KeywordRule = {
  serviceSlug?: string;
  categorySlug?: string;
  keywords: string[];
  intent?: "complaint" | "service";
};

const KEYWORD_RULES: KeywordRule[] = [
  {
    serviceSlug: "water-leakage-complaint",
    intent: "complaint",
    keywords: ["leak", "leaking", "burst", "pipe", "seepage", "seeping", "pipe burst", "running water"],
  },
  {
    serviceSlug: "water-supply-complaint",
    intent: "complaint",
    keywords: [
      "no water",
      "water supply",
      "water not coming",
      "supply disruption",
      "low pressure",
      "dirty water",
      "muddy water",
      "contamination",
      "water problem",
      "tank empty",
    ],
  },
  {
    serviceSlug: "garbage-collection-complaint",
    intent: "complaint",
    keywords: ["garbage", "rubbish", "trash", "waste", "bin", "dustbin", "collection", "not collected", "litter"],
  },
  {
    serviceSlug: "potholes-damaged-roads",
    intent: "complaint",
    keywords: ["pothole", "pot hole", "hole in road", "broken road", "road damage", "damaged road", "road is broken", "divider"],
  },
  {
    serviceSlug: "streetlight-complaint",
    intent: "complaint",
    keywords: ["streetlight", "street light", "lamp", "lamp post", "dark street", "light not working", "no light"],
  },
  {
    serviceSlug: "drainage-overflow",
    intent: "complaint",
    keywords: ["drain", "drainage", "sewage", "overflow", "waterlog", "water logging", "flood", "blocked drain", "waterlogging"],
  },
  {
    serviceSlug: "open-manhole",
    intent: "complaint",
    keywords: ["manhole", "man hole", "open hole", "open drain", "no cover", "uncovered manhole"],
  },
  {
    serviceSlug: "public-cleanliness-issue",
    intent: "complaint",
    keywords: ["cleanliness", "unclean", "dirty", "hygiene", "sanitation", "not cleaned", "dust"],
  },
  {
    serviceSlug: "community-hall-booking",
    intent: "complaint",
    keywords: ["community hall", "hall booking", "book a hall", "banquet", "function hall", "hall"],
  },
  {
    serviceSlug: "parks-and-gardens",
    intent: "complaint",
    keywords: ["park", "garden", "garden maintenance", "broken swing", "park light"],
  },
  {
    serviceSlug: "birth-registration-certificate",
    intent: "service",
    keywords: ["birth", "birth certificate", "born", "new born", "baby registration", "janam"],
  },
  {
    serviceSlug: "death-registration-certificate",
    intent: "service",
    keywords: ["death", "death certificate", "death registration", "passed away", "mortality"],
  },
  {
    serviceSlug: "marriage-registration-information",
    intent: "service",
    keywords: ["marriage", "marriage certificate", "married", "wedding registration", "marriage registration"],
  },
  {
    serviceSlug: "property-tax-information",
    intent: "service",
    keywords: ["property tax", "tax information", "tax dues", "property dues", "tax receipt", "tax bill", "municipal tax"],
  },
  {
    serviceSlug: "professional-tax",
    intent: "service",
    keywords: ["professional tax", "occupation tax", "professional certificate"],
  },
  {
    serviceSlug: "tax-payment-portal",
    intent: "service",
    keywords: ["pay tax", "tax payment", "pay property tax", "payment portal", "pay dues", "online payment"],
  },
  {
    serviceSlug: "property-details-and-dues",
    intent: "service",
    keywords: ["property details", "7/12", "property record", "occupancy", "property search"],
  },
  {
    serviceSlug: "water-connection-information",
    intent: "service",
    keywords: ["new connection", "water connection", "connection request", "tap connection", "meter"],
  },
  {
    serviceSlug: "drainage-connection-information",
    intent: "service",
    keywords: ["drain connection", "sewer connection", "drainage line", "line clearance"],
  },
  {
    serviceSlug: "shops-establishment-registration",
    intent: "service",
    keywords: ["shop", "shops", "establishment", "trade licence", "trade license", "business licence", "shop registration", "store licence"],
  },
  {
    serviceSlug: "hawker-registration",
    intent: "service",
    keywords: ["hawker", "vendor", "vending", "street seller", "street vendor", "cart"],
  },
  {
    serviceSlug: "building-permission-information",
    intent: "service",
    keywords: ["building permission", "construction permission", "sanction plan", "building plan", "permission to build", "b.p. plan"],
  },
  {
    serviceSlug: "swimming-pools",
    intent: "service",
    keywords: ["swimming", "pool", "swimming pool", "lane"],
  },
  {
    serviceSlug: "gymnasiums",
    intent: "service",
    keywords: ["gym", "gymnasium", "fitness", "membership"],
  },
];

const COMPLAINT_INTENT_WORDS = [
  "complaint",
  "complain",
  "report",
  "issue",
  "problem",
  "broken",
  "not working",
  "missing",
  "damaged",
  "dirty",
  "flood",
  "urgent",
  "bad",
];

const FEE_WORDS = ["fee", "fees", "cost", "charges", "charge", "price", "how much", "amount"];
const TIME_WORDS = [
  "how long",
  "time taken",
  "how many days",
  "number of days",
  "timeline",
  "duration",
  "when will",
  "processing time",
  "processing period",
  "how much time",
];
const PAYMENT_WORDS = ["payment", "pay", "pay online", "money", "upi", "net banking"];
const STATUS_WORDS = ["status", "track", "tracking", "reference", "where is my", "progress", "update"];
const DOCUMENT_WORDS = ["documents", "proof", "papers", "certificate copy", "what do i need", "requirements"];
const ELIGIBILITY_WORDS = ["eligibility", "eligible", "who can apply", "criteria", "am i eligible"];

function normalise(value: string): string {
  return value.toLowerCase().replace(/\s+/g, " ").trim();
}

function includesAny(text: string, words: string[]): boolean {
  return words.some((word) => text.includes(word));
}

function findService(services: AssistantService[], slug: string) {
  return services.find((service) => service.slug === slug);
}

function matchServices(services: AssistantService[], text: string): AssistantMatch[] {
  const scored = services
    .map((service) => {
      const haystack = normalise(
        `${service.name} ${service.summary} ${service.categoryName} ${service.requirements.join(" ")}`,
      );
      let score = 0;
      if (haystack.includes(text) && text.length > 3) score += 6;
      for (const word of text.split(" ")) {
        if (word.length < 4) continue;
        if (normalise(service.name).includes(word)) score += 3;
        else if (haystack.includes(word)) score += 1;
      }
      return { service, score };
    })
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, 3).map(({ service }) => ({
    slug: service.slug,
    name: service.name,
    categoryName: service.categoryName,
    summary: service.summary,
    handlingMode: service.handlingMode,
  }));
}

function serviceBlock(service: AssistantService): string {
  const steps = service.procedure.slice(0, 4).map((step, index) => `  ${index + 1}. ${step}`).join("\n");
  const documents = service.documents.length
    ? `\n\nDocuments usually asked for: ${service.documents.join(", ")}.`
    : "";
  const office = service.office ? `\n\nResponsible desk: ${service.office}.` : "";
  const mode =
    service.handlingMode === "demo"
      ? "You can register and track this directly on One Ahmedabad."
      : service.handlingMode === "hybrid"
        ? "The procedure is explained here, but the formal application is made on the official AMC portal."
        : "This service is completed on the official AMC or State portal.";
  return `**${service.name}** (${service.categoryName})\n\n${service.summary}\n\n${mode}\n\nProcedure:\n${steps}${documents}${office}`;
}

function portalLinks(services: AssistantService[]): string {
  const links = services
    .filter((service) => service.officialPortalUrl)
    .slice(0, 2)
    .map((service) => `• ${service.name}: ${service.officialPortalUrl}`)
    .join("\n");
  return links ? `\n\nOfficial portals:\n${links}` : "";
}

/**
 * Deterministic answer builder — never fabricates civic information.
 */
export function answerQuestion(question: string, services: AssistantService[]): AssistantReply {
  const text = normalise(question);

  if (!text) {
    return {
      reply:
        "Tell me what you need help with — for example “my tap water is muddy”, “how do I get a birth certificate” or “where do I pay property tax”. I answer strictly from the One Ahmedabad service directory and always point you to the official AMC portal for the actual application.",
      matches: [],
      suggestions: [
        "How do I raise a complaint?",
        "I need a birth certificate",
        "How do I pay property tax?",
        "What documents are needed for a water connection?",
      ],
      source: "fallback",
    };
  }

  /* ---------- 1. Direct keyword rules ---------- */
  const rule = KEYWORD_RULES.find(
    (item) => item.keywords.some((keyword) => text.includes(keyword)),
  );

  if (rule?.serviceSlug) {
    const service = findService(services, rule.serviceSlug);
    if (service) {
      const isComplaint = rule.intent === "complaint" || service.isComplaintType;
      const reply = isComplaint
        ? `That sounds like **${service.name}** under ${service.categoryName}. ${
            service.summary
          }\n\nRegister it on One Ahmedabad with the location, a short description and a photograph — you get a reference number and an in-app update at every status change.\n\nWhat to write:\n• Category: ${service.name}\n• Description: what is happening, since when, and the impact\n• Area, ward and nearest landmark\n• A daytime photograph if it is safe to take one`
        : serviceBlock(service);

      return {
        reply: `${reply}${portalLinks([service])}`,
        matches: [
          {
            slug: service.slug,
            name: service.name,
            categoryName: service.categoryName,
            summary: service.summary,
            handlingMode: service.handlingMode,
          },
        ],
        suggestions: isComplaint
          ? ["How do I track a complaint?", "What documents should I attach?", "Who do I contact for help?"]
          : [
              "Where do I apply officially?",
              "What documents do I need?",
              "How long does it usually take?",
            ],
        source: "directory",
      };
    }
  }

  /* ---------- 2. Broad civic questions ---------- */
  if (includesAny(text, FEE_WORDS)) {
    return {
      reply:
        "One Ahmedabad does not quote fees, charges or deposit amounts, because only the Ahmedabad Municipal Corporation sets and publishes them — inventing a number here would be misleading.\n\nThe reliable route is the official AMC e-Sampark portal, where each service shows its government fee before you pay. On this platform you can read the procedure, the documents to carry and the responsible desk, then complete the payment yourself on the official gateway.",
      matches: [],
      suggestions: [
        "Where do I pay property tax?",
        "How do I apply for a birth certificate?",
        "What documents are needed?",
      ],
      source: "faq",
    };
  }

  if (includesAny(text, TIME_WORDS)) {
    return {
      reply:
        "I cannot give you a processing timeline — AMC publishes the applicable timelines per service, and any figure I invented could send you to the office on the wrong day.\n\nWhat I can do is point you to the exact service, the documents to carry and the desk to visit, so you go there fully prepared. Search the service directory or tell me which service you mean and I will summarise the procedure.",
      matches: [],
      suggestions: [
        "How do I register a complaint?",
        "Where do I apply for a building permission?",
        "How do I get a water connection?",
      ],
      source: "faq",
    };
  }

  if (includesAny(text, PAYMENT_WORDS)) {
    const taxService = findService(services, "tax-payment-portal");
    return {
      reply: `Payments are never processed on One Ahmedabad — there is no payment gateway here, and no money should ever be sent to this platform.\n\n${
        taxService
          ? serviceBlock(taxService)
          : "Use the official AMC e-Sampark portal to pay, verify the payee name, and download the receipt from the government portal."
      }`,
      matches: taxService
        ? [
            {
              slug: taxService.slug,
              name: taxService.name,
              categoryName: taxService.categoryName,
              summary: taxService.summary,
              handlingMode: taxService.handlingMode,
            },
          ]
        : [],
      suggestions: ["Where do I pay property tax?", "How do I check my dues?"],
      source: "faq",
    };
  }

  if (includesAny(text, STATUS_WORDS)) {
    return {
      reply:
        "You can track a complaint in two ways:\n\n1. From your citizen dashboard — every complaint you raise is listed with its live status, the administrative remarks and the full history.\n2. Without signing in — open “Track a complaint” and enter your reference number (for example AMC-2026-482193) together with the email address used at registration.\n\nStatuses move through Submitted → Under Review → Assigned → In Progress → Resolved, with Rejected used when a complaint is closed without action.",
      matches: [],
      suggestions: [
        "How do I raise a complaint?",
        "Who do I contact for help?",
        "How do I get a birth certificate?",
      ],
      source: "faq",
    };
  }

  if (includesAny(text, ELIGIBILITY_WORDS)) {
    return {
      reply:
        "Eligibility, age limits and documentation rules are decided by the issuing authority under the relevant Gujarat / AMC rules, so I will not guess them for you.\n\nWhat I can give you is the verified procedure and the document list for the exact service, plus the official portal where the authority publishes the current criteria. Tell me which service you mean — for example birth registration, hawker registration or shops and establishments registration.",
      matches: [],
      suggestions: [
        "How do I register a hawker?",
        "How do I register a shop?",
        "How do I get a death certificate?",
      ],
      source: "faq",
    };
  }

  if (includesAny(text, DOCUMENT_WORDS)) {
    const matches = matchServices(services, text);
    if (matches.length) {
      const service = findService(services, matches[0].slug);
      const docList = service?.documents.length
        ? `Documents usually asked for: ${service.documents.join(", ")}.`
        : "Open the service page for the full document checklist.";
      return {
        reply: `For **${service?.name ?? matches[0].name}**, the documents usually asked for are listed on the service page. ${docList}\n\nKeep originals plus one photocopy of each — the exact list is confirmed by the issuing office.`,
        matches,
        suggestions: [
          "What is the procedure?",
          "Where do I apply officially?",
          "How long does it take?",
        ],
        source: "directory",
      };
    }
  }

  /* ---------- 3. Complaint intent without a specific rule ---------- */
  if (includesAny(text, COMPLAINT_INTENT_WORDS)) {
    const matches = matchServices(services, text);
    const complaintTypes = services
      .filter((service) => service.isComplaintType)
      .filter((service) =>
        text.includes(normalise(service.categoryName)) ||
        text.includes(normalise(service.name)) ||
        matches.some((match) => match.slug === service.slug),
      )
      .slice(0, 2);

    return {
      reply: `For a problem like this, the right route is to register a complaint on One Ahmedabad — you get a reference number, a visible status timeline and an in-app update whenever an officer acts on it.\n\nChoose the category that matches best and include the exact location, a landmark, the date you first noticed it and a photograph if it is safe to take one. Do not use this channel for emergencies such as electrical hazards or active structural collapse — contact the emergency services directly.`,
      matches:
        complaintTypes.length > 0
          ? complaintTypes.map((service) => ({
              slug: service.slug,
              name: service.name,
              categoryName: service.categoryName,
              summary: service.summary,
              handlingMode: service.handlingMode,
            }))
          : matches,
      suggestions: [
        "How do I track a complaint?",
        "What details should I include?",
        "Who do I contact for help?",
      ],
      source: "directory",
    };
  }

  /* ---------- 4. Greeting / about ---------- */
  if (
    text.includes("hello") ||
    text.includes("hi ") ||
    text === "hi" ||
    text.includes("hey") ||
    text.includes("what is one ahmedabad") ||
    text.includes("about this platform") ||
    text.includes("who are you")
  ) {
    return {
      reply:
        "I am the One Ahmedabad citizen assistant. I help you find the right municipal service, understand the procedure from the verified service directory, register and track civic complaints, and point you to the official AMC portal for the actual application.\n\nI never guess fees, timelines or eligibility rules — if a question needs a government decision, I will say so and give you the official link instead.\n\nTry asking: “my tap water has been muddy for three days”, “how do I get a birth certificate” or “where do I pay property tax”.",
      matches: [],
      suggestions: [
        "How do I raise a complaint?",
        "Where do I pay property tax?",
        "How do I get a birth certificate?",
      ],
      source: "faq",
    };
  }

  /* ---------- 5. Directory keyword search ---------- */
  const matches = matchServices(services, text);
  if (matches.length) {
    const service = findService(services, matches[0].slug);
    return {
      reply: `Here is the closest match in the service directory:\n\n${service ? serviceBlock(service) : matches[0].summary}\n\nIf that is not quite what you meant, tell me the situation in your own words and I will narrow it down.`,
      matches,
      suggestions: [
        "What documents do I need?",
        "Where do I apply officially?",
        "How do I raise a complaint?",
      ],
      source: "directory",
    };
  }

  /* ---------- 6. Honest fallback ---------- */
  return {
    reply:
      "I could not match that to a service in the One Ahmedabad directory, and I will not guess an official process that may not exist.\n\nTry describing the situation plainly — for example “the streetlight outside my society is not working” or “I need a copy of my birth certificate” — or browse the six service categories directly. For anything about fees, timelines or eligibility, the official AMC portal is the only authoritative source.",
    matches: [],
    suggestions: [
      "How do I raise a complaint?",
      "Browse municipal services",
      "Where do I pay property tax?",
    ],
    source: "fallback",
  };
}
