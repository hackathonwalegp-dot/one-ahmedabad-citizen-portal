import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import type { User } from "@/db/schema";

export const SESSION_COOKIE = "oa_session";
const SESSION_DAYS = 14;

/* ------------------------------------------------------------------ */
/* Password hashing (scrypt — built into Node, no extra dependency)   */
/* ------------------------------------------------------------------ */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const derived = scryptSync(password, salt, 64);
  const storedKey = Buffer.from(key, "hex");
  if (storedKey.length !== derived.length) return false;
  return timingSafeEqual(derived, storedKey);
}

/* ------------------------------------------------------------------ */
/* Sessions                                                            */
/* ------------------------------------------------------------------ */

export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  return token;
}

export async function destroySession(token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.token, token));
}

export async function getSessionToken(): Promise<string | undefined> {
  const store = await cookies();
  return store.get(SESSION_COOKIE)?.value;
}

/** Returns the signed-in user (citizen or admin) or null. */
export async function getCurrentUser(): Promise<User | null> {
  const token = await getSessionToken();
  if (!token) return null;

  const rows = await db
    .select({ user: users, expiresAt: sessions.expiresAt })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);

  return rows[0]?.user ?? null;
}

export async function requireUser(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("Please sign in to continue.", 401);
  return user;
}

export async function requireAdmin(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("Please sign in to continue.", 401);
  if (user.role !== "admin") throw new AuthError("Administrator access required.", 403);
  return user;
}

export type Role = "citizen" | "admin" | "operator";

/** Administrators and service-centre operators can act on behalf of citizens. */
export function isStaff(user: Pick<User, "role">): boolean {
  return user.role === "admin" || user.role === "operator";
}

export async function requireStaff(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("Please sign in to continue.", 401);
  if (!isStaff(user)) throw new AuthError("Staff access required.", 403);
  return user;
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status = 401) {
    super(message);
    this.status = status;
  }
}

/** Serialisable shape safe to send to the browser. */
export type PublicUser = {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  role: Role;
  ward: string | null;
  address: string | null;
  createdAt: string;
};

export function toPublicUser(user: User): PublicUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    role: user.role === "admin" ? "admin" : user.role === "operator" ? "operator" : "citizen",
    ward: user.ward,
    address: user.address,
    createdAt: user.createdAt.toISOString(),
  };
}

/** Where each role lands after signing in. */
export function homeFor(role: string): string {
  if (role === "admin") return "/admin";
  if (role === "operator") return "/centre";
  return "/dashboard";
}
