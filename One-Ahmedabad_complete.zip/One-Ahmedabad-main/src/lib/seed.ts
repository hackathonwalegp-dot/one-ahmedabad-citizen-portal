import { and, count, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  announcements,
  complaints,
  serviceCategories,
  services,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { categorySeed, serviceSeed } from "@/lib/services-data";

const INITIAL_ADMIN_EMAIL = process.env.INITIAL_ADMIN_EMAIL?.trim().toLowerCase();
const INITIAL_ADMIN_PASSWORD = process.env.INITIAL_ADMIN_PASSWORD;
const INITIAL_ADMIN_NAME = process.env.INITIAL_ADMIN_NAME?.trim() || "Platform Administrator";
const INITIAL_ADMIN_PHONE = process.env.INITIAL_ADMIN_PHONE?.trim() || null;
const INITIAL_OPERATOR_EMAIL = process.env.INITIAL_OPERATOR_EMAIL?.trim().toLowerCase();
const INITIAL_OPERATOR_PASSWORD = process.env.INITIAL_OPERATOR_PASSWORD;
const INITIAL_OPERATOR_NAME = process.env.INITIAL_OPERATOR_NAME?.trim() || "Service Centre Operator";

const ANNOUNCEMENT_SEED = [
  {
    title: "Explore the service directory by category",
    body: "This prototype groups commonly requested municipal service information into clear categories. Check the relevant official AMC or Gujarat portal before starting an application or making a payment.",
    category: "Platform update",
  },
  {
    title: "How complaint tracking works in this demo",
    body: "A complaint submitted in One Ahmedabad is stored in this prototype and can be followed using its reference number. It is not automatically forwarded to AMC or another government department.",
    category: "Prototype guide",
  },
  {
    title: "Use official portals for payments and certificates",
    body: "One Ahmedabad does not collect payments or issue government certificates. Use the linked official government portal for payment, registration and certificate services.",
    category: "Citizen information",
  },
  {
    title: "One Ahmedabad is an independent civic-service concept",
    body: "This hackathon prototype is not officially connected to the Ahmedabad Municipal Corporation. Service guidance is informational and should be checked against current official instructions.",
    category: "Prototype notice",
  },
];

let seedPromise: Promise<void> | null = null;

/**
 * Idempotent bootstrap. Safe to call from any server entry point:
 * it only inserts rows that are missing, so administrator edits are preserved.
 */
export function ensureSeedData(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seed().catch((error) => {
      // Never cache a failure — allow a later request to retry.
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

async function seed(): Promise<void> {
  const [categoryCount] = await db.select({ value: count() }).from(serviceCategories);
  if (!categoryCount.value) {
    await db.insert(serviceCategories).values(categorySeed);
  }

  const [serviceCount] = await db.select({ value: count() }).from(services);
  if (!serviceCount.value) {
    await db.insert(services).values(
      serviceSeed.map((service) => ({
        slug: service.slug,
        name: service.name,
        categorySlug: service.categorySlug,
        summary: service.summary,
        description: service.description,
        requirements: service.requirements,
        procedure: service.procedure,
        documents: service.documents,
        officialPortalUrl: service.officialPortalUrl ?? null,
        handlingMode: service.handlingMode,
        isComplaintType: service.isComplaintType ?? false,
        office: service.office ?? null,
        disclaimer: service.disclaimer ?? null,
        isActive: true,
      })),
    );
  }

  // Never ship a public, predictable administrator credential. Provision the
  // first admin explicitly through environment variables on a trusted deploy.
  if (INITIAL_ADMIN_EMAIL && INITIAL_ADMIN_PASSWORD) {
    const [existingAdmin] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, INITIAL_ADMIN_EMAIL))
      .limit(1);

    if (!existingAdmin) {
      await db.insert(users).values({
        name: INITIAL_ADMIN_NAME,
        email: INITIAL_ADMIN_EMAIL,
        phone: INITIAL_ADMIN_PHONE,
        passwordHash: hashPassword(INITIAL_ADMIN_PASSWORD),
        role: "admin",
        ward: "AMC Head Office",
        address: "Ahmedabad, Gujarat",
      });
    }
  }

  // Optional first service-centre operator, provisioned the same explicit way.
  if (INITIAL_OPERATOR_EMAIL && INITIAL_OPERATOR_PASSWORD) {
    const [existingOperator] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, INITIAL_OPERATOR_EMAIL))
      .limit(1);

    if (!existingOperator) {
      await db.insert(users).values({
        name: INITIAL_OPERATOR_NAME,
        email: INITIAL_OPERATOR_EMAIL,
        passwordHash: hashPassword(INITIAL_OPERATOR_PASSWORD),
        role: "operator",
        ward: "Service Centre",
        address: "Ahmedabad, Gujarat",
      });
    }
  }

  const [announcementCount] = await db.select({ value: count() }).from(announcements);
  if (!announcementCount.value) {
    await db.insert(announcements).values(
      ANNOUNCEMENT_SEED.map((item) => ({
        title: item.title,
        body: item.body,
        category: item.category,
        isPublished: true,
        createdBy: "One Ahmedabad Prototype",
      })),
    );
  }
}

/** Creates a human friendly, collision-safe complaint reference. */
export async function generateReference(): Promise<string> {
  const year = new Date().getFullYear();
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const random = Math.floor(100000 + Math.random() * 900000);
    const reference = `AMC-${year}-${random}`;
    const existing = await db
      .select({ id: complaints.id })
      .from(complaints)
      .where(eq(complaints.reference, reference))
      .limit(1);
    if (!existing.length) return reference;
  }
  const fallback = `AMC-${year}-${Date.now().toString().slice(-6)}`;
  return fallback;
}

export async function hasAnyUser(): Promise<boolean> {
  const [row] = await db.select({ value: count() }).from(users);
  return row.value > 0;
}

export { and };
