import type { Locale } from "@/components/site/locale-provider";

type Entry = Record<Locale, string>;

/**
 * Interface labels for the signed-in areas (citizen dashboard, administrator
 * console and service centre). Service records, announcements and complaint
 * text entered by people stay in the language they were written in.
 */
export const UI_TEXT: Record<string, Entry> = {
  // citizen navigation
  "nav.overview": { en: "Overview", gu: "ઝાંખી", hi: "अवलोकन" },
  "nav.complaints": { en: "My complaints", gu: "મારી ફરિયાદો", hi: "मेरी शिकायतें" },
  "nav.newComplaint": { en: "Register complaint", gu: "ફરિયાદ નોંધાવો", hi: "शिकायत दर्ज करें" },
  "nav.applications": { en: "My applications", gu: "મારી અરજીઓ", hi: "मेरे आवेदन" },
  "nav.newApplication": { en: "Apply for certificate", gu: "પ્રમાણપત્ર માટે અરજી", hi: "प्रमाणपत्र के लिए आवेदन" },
  "nav.payments": { en: "Property tax & payments", gu: "મિલકત વેરો અને ચુકવણી", hi: "संपत्ति कर और भुगतान" },
  "nav.notifications": { en: "Notifications", gu: "સૂચનાઓ", hi: "सूचनाएँ" },
  "nav.support": { en: "Help & support", gu: "મદદ અને સહાય", hi: "सहायता" },
  "nav.profile": { en: "Profile", gu: "પ્રોફાઇલ", hi: "प्रोफ़ाइल" },
  // admin navigation
  "nav.adminComplaints": { en: "Complaints", gu: "ફરિયાદો", hi: "शिकायतें" },
  "nav.adminApplications": { en: "Applications", gu: "અરજીઓ", hi: "आवेदन" },
  "nav.adminPayments": { en: "Transactions", gu: "વ્યવહારો", hi: "लेन-देन" },
  "nav.adminCitizens": { en: "Citizens & staff", gu: "નાગરિકો અને સ્ટાફ", hi: "नागरिक और स्टाफ" },
  "nav.adminDepartments": { en: "Departments", gu: "વિભાગો", hi: "विभाग" },
  "nav.adminReports": { en: "Reports & analytics", gu: "અહેવાલ અને વિશ્લેષણ", hi: "रिपोर्ट और विश्लेषण" },
  "nav.adminSupport": { en: "Support desk", gu: "સહાય કેન્દ્ર", hi: "सहायता डेस्क" },
  "nav.adminServices": { en: "Service information", gu: "સેવા માહિતી", hi: "सेवा जानकारी" },
  "nav.adminAnnouncements": { en: "Announcements", gu: "જાહેરાતો", hi: "घोषणाएँ" },
  // service centre navigation
  "nav.centreHome": { en: "Centre desk", gu: "કેન્દ્ર ડેસ્ક", hi: "केंद्र डेस्क" },
  "nav.centreCitizens": { en: "Register citizen", gu: "નાગરિક નોંધણી", hi: "नागरिक पंजीकरण" },
  "nav.centreAssist": { en: "Assist a citizen", gu: "નાગરિકને મદદ", hi: "नागरिक की सहायता" },
  "nav.centreTrack": { en: "Search requests", gu: "વિનંતીઓ શોધો", hi: "अनुरोध खोजें" },
  // role chips and side panels
  "role.citizen": { en: "Citizen", gu: "નાગરિક", hi: "नागरिक" },
  "role.admin": { en: "Administrator", gu: "એડમિનિસ્ટ્રેટર", hi: "प्रशासक" },
  "role.operator": { en: "Service centre", gu: "સેવા કેન્દ્ર", hi: "सेवा केंद्र" },
  "side.signedInAs": { en: "Signed in as", gu: "આ રીતે લૉગ ઇન", hi: "साइन इन" },
  "side.adminConsole": { en: "Admin console", gu: "એડમિન કન્સોલ", hi: "एडमिन कंसोल" },
  "side.centreConsole": { en: "Service centre", gu: "સેવા કેન્દ્ર", hi: "सेवा केंद्र" },
  "side.citizenDashboard": { en: "Citizen dashboard", gu: "નાગરિક ડેશબોર્ડ", hi: "नागरिक डैशबोर्ड" },
  "side.guideTitle": { en: "Citizen guide", gu: "નાગરિક માર્ગદર્શિકા", hi: "नागरिक मार्गदर्शिका" },
  "side.guideBody": {
    en: "Not sure where to start? Ask the assistant which service or complaint type applies.",
    gu: "ક્યાંથી શરૂ કરવું તે નક્કી નથી? કઈ સેવા કે ફરિયાદનો પ્રકાર લાગુ પડે છે તે સહાયકને પૂછો.",
    hi: "समझ नहीं आ रहा कहाँ से शुरू करें? सहायक से पूछें कि कौन-सी सेवा या शिकायत का प्रकार लागू होता है।",
  },
  "side.guideLink": { en: "Open citizen guide →", gu: "માર્ગદર્શિકા ખોલો →", hi: "मार्गदर्शिका खोलें →" },
  // home action tiles
  "home.eyebrow": { en: "DO IT ONLINE IN THIS PROTOTYPE", gu: "આ પ્રોટોટાઇપમાં ઑનલાઇન કરો", hi: "इस प्रोटोटाइप में ऑनलाइन करें" },
  "home.title": { en: "One account. Every request.", gu: "એક ખાતું. દરેક વિનંતી.", hi: "एक खाता। हर अनुरोध।" },
  "home.body": {
    en: "Register complaints, send certificate applications, try the property-tax simulator and follow every reference number from one place.",
    gu: "ફરિયાદ નોંધાવો, પ્રમાણપત્રની અરજી મોકલો, મિલકત વેરા સિમ્યુલેટર અજમાવો અને દરેક રેફરન્સ નંબર એક જ જગ્યાએથી જુઓ.",
    hi: "शिकायत दर्ज करें, प्रमाणपत्र आवेदन भेजें, संपत्ति कर सिमुलेटर आज़माएँ और हर संदर्भ संख्या एक ही जगह देखें।",
  },
  "home.complaint": { en: "Register a complaint", gu: "ફરિયાદ નોંધાવો", hi: "शिकायत दर्ज करें" },
  "home.complaintBody": {
    en: "Water, roads, lights, garbage and drainage, with an optional photo.",
    gu: "પાણી, રસ્તા, લાઇટ, કચરો અને ગટર, વૈકલ્પિક ફોટા સાથે.",
    hi: "पानी, सड़क, बत्ती, कचरा और जल निकासी, वैकल्पिक फ़ोटो के साथ।",
  },
  "home.application": { en: "Apply for a certificate", gu: "પ્રમાણપત્ર માટે અરજી", hi: "प्रमाणपत्र के लिए आवेदन" },
  "home.applicationBody": {
    en: "Birth, death, trade licence and permit requests with a document upload.",
    gu: "જન્મ, મૃત્યુ, વેપાર લાઇસન્સ અને પરવાનગીની વિનંતીઓ, દસ્તાવેજ અપલોડ સાથે.",
    hi: "जन्म, मृत्यु, व्यापार लाइसेंस और अनुमति अनुरोध, दस्तावेज़ अपलोड के साथ।",
  },
  "home.payment": { en: "Property tax simulator", gu: "મિલકત વેરા સિમ્યુલેટર", hi: "संपत्ति कर सिमुलेटर" },
  "home.paymentBody": {
    en: "Try a demo payment and download a marked DEMO receipt. No money moves.",
    gu: "ડેમો ચુકવણી અજમાવો અને DEMO રસીદ ડાઉનલોડ કરો. કોઈ પૈસા ટ્રાન્સફર થતા નથી.",
    hi: "डेमो भुगतान आज़माएँ और DEMO रसीद डाउनलोड करें। कोई पैसा नहीं जाता।",
  },
  "home.track": { en: "Track any request", gu: "કોઈપણ વિનંતી ટ્રૅક કરો", hi: "कोई भी अनुरोध ट्रैक करें" },
  "home.trackBody": {
    en: "Use a reference number and your email to see the latest status.",
    gu: "નવીનતમ સ્થિતિ જોવા માટે રેફરન્સ નંબર અને તમારા ઇમેઇલનો ઉપયોગ કરો.",
    hi: "ताज़ा स्थिति देखने के लिए संदर्भ संख्या और अपने ईमेल का उपयोग करें।",
  },
  "home.centre": { en: "Visiting a service centre?", gu: "સેવા કેન્દ્ર પર આવ્યા છો?", hi: "सेवा केंद्र पर आए हैं?" },
  "home.centreBody": {
    en: "Operators can register a citizen and file requests on their behalf.",
    gu: "ઑપરેટર નાગરિકની નોંધણી કરી તેમના વતી વિનંતીઓ નોંધી શકે છે.",
    hi: "ऑपरेटर नागरिक का पंजीकरण कर उनकी ओर से अनुरोध दर्ज कर सकते हैं।",
  },
  "home.centreLink": { en: "Service-centre sign in", gu: "સેવા કેન્દ્ર લૉગ ઇન", hi: "सेवा केंद्र साइन इन" },
};
