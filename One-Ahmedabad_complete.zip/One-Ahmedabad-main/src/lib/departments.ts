/** Municipal departments used when assigning complaints and applications. */
export const DEPARTMENTS = [
  "Water Supply & Sewerage",
  "Roads & Buildings",
  "Street Lighting",
  "Solid Waste Management",
  "Health & Sanitation",
  "Revenue & Taxation",
  "Civil Registration",
  "Licensing Department",
  "Public Grievance Cell",
] as const;

/** Ahmedabad localities offered in forms. Free text is still accepted by the API. */
export const WARDS = [
  "Navrangpura",
  "Paldi",
  "Maninagar",
  "Vastrapur",
  "Bodakdev",
  "Chandkheda",
  "Sabarmati",
  "Naranpura",
  "Bopal",
  "Gota",
  "Isanpur",
  "Vejalpur",
  "Other Ahmedabad area",
] as const;
