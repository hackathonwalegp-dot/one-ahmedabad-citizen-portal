import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * One Ahmedabad — unified digital citizen services platform
 * -------------------------------------------------------
 * A deliberately small, readable schema. Every table maps to one domain:
 *   users / sessions  -> authentication & roles
 *   serviceCategories / services -> municipal services directory
 *   complaints / complaintEvents -> complaint lifecycle + history
 *   notifications -> in-app inbox
 *   announcements -> public news feed (admin managed)
 *   applications / applicationEvents -> certificate & permit requests + history
 *   properties / payments -> simulated property-tax assessments and receipts
 *   supportTickets -> help-desk requests with administrator replies
 */

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("citizen"), // "citizen" | "admin" | "operator" (service-centre staff)
    ward: text("ward"),
    address: text("address"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    emailUnique: uniqueIndex("users_email_unique").on(table.email),
    roleIndex: index("users_role_idx").on(table.role),
  }),
);

export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    token: text("token").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => ({
    tokenUnique: uniqueIndex("sessions_token_unique").on(table.token),
    userIndex: index("sessions_user_idx").on(table.userId),
  }),
);

export const serviceCategories = pgTable(
  "service_categories",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    icon: text("icon").notNull().default("Landmark"),
    accent: text("accent").notNull().default("blue"),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => ({
    slugUnique: uniqueIndex("service_categories_slug_unique").on(table.slug),
  }),
);

export const services = pgTable(
  "services",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    categorySlug: text("category_slug").notNull(),
    summary: text("summary").notNull(),
    description: text("description").notNull(),
    requirements: jsonb("requirements").$type<string[]>().notNull().default([]),
    procedure: jsonb("procedure").$type<string[]>().notNull().default([]),
    documents: jsonb("documents").$type<string[]>().notNull().default([]),
    officialPortalUrl: text("official_portal_url"),
    /** "demo" = fully handled inside this prototype, "redirect" = official portal link */
    handlingMode: text("handling_mode").notNull().default("redirect"),
    isComplaintType: boolean("is_complaint_type").notNull().default(false),
    office: text("office"),
    disclaimer: text("disclaimer"),
    isActive: boolean("is_active").notNull().default(true),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    slugUnique: uniqueIndex("services_slug_unique").on(table.slug),
    categoryIndex: index("services_category_idx").on(table.categorySlug),
  }),
);

export const complaints = pgTable(
  "complaints",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    serviceSlug: text("service_slug"),
    serviceName: text("service_name").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull(),
    area: text("area").notNull(),
    ward: text("ward"),
    landmark: text("landmark"),
    contactPhone: text("contact_phone"),
    photoUrl: text("photo_url"),
    /** Name of the service-centre operator when filed on behalf of a citizen. */
    filedByName: text("filed_by_name"),
    status: text("status").notNull().default("Submitted"),
    adminRemark: text("admin_remark"),
    assignedTo: text("assigned_to"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (table) => ({
    referenceUnique: uniqueIndex("complaints_reference_unique").on(table.reference),
    userIndex: index("complaints_user_idx").on(table.userId),
    statusIndex: index("complaints_status_idx").on(table.status),
  }),
);

export const complaintEvents = pgTable(
  "complaint_events",
  {
    id: serial("id").primaryKey(),
    complaintId: integer("complaint_id")
      .notNull()
      .references(() => complaints.id, { onDelete: "cascade" }),
    status: text("status").notNull(),
    note: text("note"),
    actorType: text("actor_type").notNull().default("system"), // citizen | admin | system
    actorName: text("actor_name"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    complaintIndex: index("complaint_events_complaint_idx").on(table.complaintId),
  }),
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    body: text("body").notNull(),
    type: text("type").notNull().default("system"), // complaint | status | announcement | system
    link: text("link"),
    isRead: boolean("is_read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userIndex: index("notifications_user_idx").on(table.userId),
  }),
);

export const announcements = pgTable(
  "announcements",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    category: text("category").notNull().default("General"),
    isPublished: boolean("is_published").notNull().default(true),
    publishedAt: timestamp("published_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    createdBy: text("created_by"),
  },
  (table) => ({
    publishedIndex: index("announcements_published_idx").on(table.isPublished),
  }),
);

export const applications = pgTable(
  "applications",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(), // Birth Certificate, Trade Licence, ...
    applicantName: text("applicant_name").notNull(),
    details: text("details").notNull(),
    ward: text("ward"),
    documentUrl: text("document_url"),
    documentName: text("document_name"),
    filedByName: text("filed_by_name"),
    status: text("status").notNull().default("Submitted"), // Submitted | Under Review | Approved | Rejected
    adminRemark: text("admin_remark"),
    assignedTo: text("assigned_to"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
  },
  (table) => ({
    referenceUnique: uniqueIndex("applications_reference_unique").on(table.reference),
    userIndex: index("applications_user_idx").on(table.userId),
    statusIndex: index("applications_status_idx").on(table.status),
  }),
);

export const applicationEvents = pgTable(
  "application_events",
  {
    id: serial("id").primaryKey(),
    applicationId: integer("application_id")
      .notNull()
      .references(() => applications.id, { onDelete: "cascade" }),
    status: text("status").notNull(),
    note: text("note"),
    actorType: text("actor_type").notNull().default("system"), // citizen | operator | admin | system
    actorName: text("actor_name"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    applicationIndex: index("application_events_application_idx").on(table.applicationId),
  }),
);

export const properties = pgTable(
  "properties",
  {
    id: serial("id").primaryKey(),
    propertyCode: text("property_code").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    ownerName: text("owner_name").notNull(),
    address: text("address").notNull(),
    ward: text("ward"),
    assessmentYear: text("assessment_year").notNull(),
    /** Illustrative assessment in rupees. Not a real AMC tax record. */
    assessmentAmount: integer("assessment_amount").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    codeUnique: uniqueIndex("properties_code_unique").on(table.propertyCode),
    userIndex: index("properties_user_idx").on(table.userId),
  }),
);

export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    receiptNo: text("receipt_no").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    propertyId: integer("property_id")
      .notNull()
      .references(() => properties.id, { onDelete: "cascade" }),
    /** Amount in rupees. No money is moved: this is a simulated transaction. */
    amount: integer("amount").notNull(),
    method: text("method").notNull(),
    status: text("status").notNull().default("Success"),
    paidAt: timestamp("paid_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    receiptUnique: uniqueIndex("payments_receipt_unique").on(table.receiptNo),
    userIndex: index("payments_user_idx").on(table.userId),
    propertyIndex: index("payments_property_idx").on(table.propertyId),
  }),
);

export const supportTickets = pgTable(
  "support_tickets",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    email: text("email").notNull(),
    topic: text("topic").notNull(),
    message: text("message").notNull(),
    status: text("status").notNull().default("Open"), // Open | Answered | Closed
    adminReply: text("admin_reply"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    referenceUnique: uniqueIndex("support_tickets_reference_unique").on(table.reference),
    userIndex: index("support_tickets_user_idx").on(table.userId),
  }),
);

export type User = typeof users.$inferSelect;
export type Service = typeof services.$inferSelect;
export type ServiceCategory = typeof serviceCategories.$inferSelect;
export type Complaint = typeof complaints.$inferSelect;
export type ComplaintEvent = typeof complaintEvents.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;
export type Application = typeof applications.$inferSelect;
export type ApplicationEvent = typeof applicationEvents.$inferSelect;
export type Property = typeof properties.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type SupportTicket = typeof supportTickets.$inferSelect;
