import { drizzle } from "drizzle-orm/netlify-db";
import * as schema from "./schema";

// Netlify Database configures the connection automatically — no connection string needed.
// The client is created on first use so that importing this module during `next build`
// (when no database connection is available) does not fail.
type Database = ReturnType<typeof createDb>;

const createDb = () => drizzle({ schema });

let instance: Database | undefined;

export const db = new Proxy({} as Database, {
  get(_target, property) {
    instance ??= createDb();
    const value = Reflect.get(instance, property, instance);
    return typeof value === "function" ? value.bind(instance) : value;
  },
});
