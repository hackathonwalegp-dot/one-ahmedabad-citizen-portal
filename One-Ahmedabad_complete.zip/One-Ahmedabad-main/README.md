# ONE AHMEDABAD — Civic Services Platform (with NagarSetu features)

A redesigned Ahmedabad-first citizen-service portal built on the existing Next.js application. The redesign is based on the fuller of the two supplied project archives and keeps the original API routes, database schema, authentication, citizen dashboard, complaint workflow, service directory and administrator pages.


## What was merged in from NagarSetu

This version keeps the One Ahmedabad design, Next.js app, PostgreSQL/Drizzle backend, scrypt sessions and admin tools, and adds every NagarSetu feature on top of that backend. Nothing is stored in browser localStorage any more: all records live in PostgreSQL and role checks run on the server.

| NagarSetu feature | Where it lives now |
| --- | --- |
| Citizen registration, login, dashboard | existing `/register`, `/login`, `/dashboard` (dashboard gained application and payment tiles) |
| Complaints with image evidence and timeline | existing `/dashboard/complaints/*`, `/admin/complaints/*` |
| Certificate and permit applications with document upload | `/dashboard/applications`, `/dashboard/applications/new`, `/admin/applications` (approve, reject, assign) |
| Property tax simulation, DEMO receipt | `/dashboard/payments`, `/dashboard/payments/[receipt]` (print or save as PDF), `/admin/payments` |
| Tracking by reference | `/track` now finds complaints and applications (reference plus registered email) |
| Notifications | existing inbox; now also written on applications, payments and support replies |
| Public notices | existing `/announcements` and `/admin/announcements` |
| Help and support | `/dashboard/support` (FAQ, request form, replies), `/admin/support` |
| Department assignment | department picker on complaint and application review, `/admin/departments` workload view |
| Admin analytics | `/admin/reports` (monthly requests, outcomes, categories) drawn with server-side SVG, no chart library |
| Citizen and staff management | `/admin/citizens` (search, create service-centre operators) |
| Service-centre operator role | `/centre`: register a citizen, file a complaint or application on their behalf, search any request |
| English and Gujarati | English, Gujarati and Hindi selector now also translates dashboard, admin and centre navigation and the homepage action tiles |

Roles: `citizen`, `operator` (service centre) and `admin`. Operators can read all requests and file on behalf of citizens, but only administrators can change a status.

New API routes: `/api/applications`, `/api/applications/[reference]`, `/api/properties`, `/api/payments`, `/api/support`, `/api/centre/citizens`, `/api/admin/operators`. `POST /api/complaints` also accepts `citizenId` from staff.

New tables (created by the migrations in `netlify/database/migrations`): `applications`, `application_events`, `properties`, `payments`, `support_tickets`, plus a `filed_by_name` column on `complaints`.

### First accounts

Set `INITIAL_ADMIN_*` as before. Optionally set `INITIAL_OPERATOR_EMAIL` and `INITIAL_OPERATOR_PASSWORD` to provision a first service-centre operator, or create operators later from Admin, Citizens and staff. No default demo passwords are shipped. Citizens registered at a service centre receive a one-time temporary password shown on screen.

### Known limits

- Property assessments are illustrative values generated from the address. No AMC record is read.
- Payments are simulated receipts. No gateway is connected.
- Uploaded files are stored in `var/uploads` on the server disk. Use object storage for a real deployment.
- This archive was assembled without network access, so `npm install`, `npm run typecheck` and `npm run build` still need to be run once on your machine.

## Redesign highlights

- City-specific hero inspired by the Sabarmati Riverfront and Atal Bridge.
- Government-style utility bar, navigation, prototype notice and a compact civic identity.
- Six quick-access municipal service categories, dynamically populated from the database.
- Popular service cards linked to the existing service detail routes.
- Editorial city-feature and civic-bulletin layout.
- English, Gujarati and Hindi selector. The selector remembers the visitor's choice in browser storage; the homepage, search helper, primary navigation and mobile navigation have translations for the three languages. Service record names, long descriptions and administrator-entered announcements remain in their stored language until translated content is added to the database.
- Responsive desktop and mobile layouts.
- No purple gradients, decorative AI glow effects or invented AMC contact details.


## NagarSetu AI assistant

A persistent assistant button is available across the public site and the citizen service guide page. It supports English, Gujarati and Hindi interface copy, suggested questions, service-directory links and browser voice input where the browser supports the Web Speech API. The server endpoint uses the database service directory as grounding context.

For conversational model responses, configure an OpenAI-compatible Chat Completions endpoint in `.env.local` or your Netlify environment variables:

```env
AI_ASSISTANT_API_URL=https://generativelanguage.googleapis.com/v1beta/openai/chat/completions
AI_ASSISTANT_API_KEY=your-provider-key
AI_ASSISTANT_MODEL=gemini-2.5-flash
```

The example uses a Gemini-compatible endpoint; use the endpoint and model supported by the provider you choose. Keep the key server-side only — never add it to a `NEXT_PUBLIC_` variable or commit it to Git. If no provider is configured or the provider is temporarily unavailable, the API falls back to the local rules-based service directory. The local fallback is not a generative AI model.

The assistant is deliberately restricted: it must not invent government fees, processing times, eligibility or AMC integrations, and it must not claim to submit official requests or access private records. Voice input depends on browser support and permissions.

## Run locally

1. Install Node.js 20.9 or newer and the Netlify CLI.
2. Copy `.env.example` to `.env.local` and fill in any optional values.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the development server through the Netlify CLI so Netlify Database is available locally (pending migrations are applied automatically):

   ```bash
   netlify dev
   ```

5. Open the URL printed by the CLI.

The database is Netlify Database (managed Postgres), accessed through Drizzle's `netlify-db` adapter — no connection string is needed. After changing `src/db/schema.ts`, run `npm run db:generate -- --name <describe_change>` to create a new migration in `netlify/database/migrations`.

The app's seed routine creates service categories, service records and clearly labelled prototype notices when the database is empty. The assistant API configuration is optional; see `.env.example`. To provision an initial administrator on a fresh database, set `INITIAL_ADMIN_EMAIL` and a strong `INITIAL_ADMIN_PASSWORD` before first run. No public default admin password is shipped. Citizen accounts are created through the registration page.


## Deploy to Netlify

This repository is configured for Netlify's Next.js runtime adapter (`@netlify/plugin-nextjs`). Deploy the **project folder** (the folder containing `package.json` and `netlify.toml`), not the ZIP file contents nested inside another folder.

1. Push this folder to a GitHub repository, then choose **Add new site → Import an existing project** in Netlify.
2. Set the base directory to the project root (`one-ahmedabad-nagarsetu`) if the repository contains a parent folder.
3. Netlify detects `netlify.toml`; use `npm run build` as the build command and `.next` as the publish directory.
4. Add the environment variables from `.env.example` in **Site configuration → Environment variables**. No database variable is needed — Netlify Database is provisioned automatically. Set a strong `INITIAL_ADMIN_EMAIL` and `INITIAL_ADMIN_PASSWORD` before the first deployment if you need an admin account.
5. Deploy. Netlify applies the migrations in `netlify/database/migrations` automatically before the deploy is published. Redeploy if you change environment variables.

**Important production notes:** Netlify's filesystem is not persistent. This prototype currently stores uploaded evidence/documents in `var/uploads`; those uploads can be lost on redeploy or function replacement. Before using real citizen data, move uploads to persistent object storage (for example S3-compatible storage) and configure appropriate access controls. Payments are simulated, and this is not an official AMC service. Do not enter real sensitive citizen information.

## Security note

The previous project archive included hard-coded demo citizen and administrator credentials. Those defaults have been removed from this version. If a database was already seeded from the older archive, rotate or disable those old accounts in that database before using it publicly.

## Prototype and integration notice

ONE AHMEDABAD is an independent hackathon prototype. It is not an official Ahmedabad Municipal Corporation website and is not connected to AMC systems. Payment, certificate issuance and official grievance submission must be completed on the relevant official portal. Demo complaints created in this application are stored in its own database and are not automatically forwarded to AMC.

## Visual asset

`public/images/ahmedabad-riverfront.png` is an AI-generated illustrative hero image inspired by the Sabarmati Riverfront and Atal Bridge. It is not a documentary photograph.

## Verification note

- All 124 TypeScript/TSX source files passed a TypeScript syntax-transpilation check.
- The AI provider request now always clears its 18-second timeout, including on network failures.
- The chat UI no longer displays a misleading always-online indicator; it is labelled as a service guide.
- A full Next.js production build, browser preview and database-backed end-to-end test could not be completed in the packaging environment: the npm dependency installation did not finish, so the installed dependency tree was incomplete.

Before deployment, run `npm ci`, `npm run typecheck`, and `npm run build` in an environment with npm registry access. The AI chat endpoint requires a working Netlify Database connection because it loads the seeded service directory. Without `AI_ASSISTANT_API_URL` and `AI_ASSISTANT_API_KEY`, it uses the local rules-based directory assistant, not a generative AI model.
